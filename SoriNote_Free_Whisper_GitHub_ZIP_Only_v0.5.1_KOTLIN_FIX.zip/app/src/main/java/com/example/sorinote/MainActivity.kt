package com.example.sorinote

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Bundle
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme()) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    SoriNoteScreen()
                }
            }
        }
    }
}

private data class SpeechLanguage(val tag: String, val label: String, val mlKitCode: String)
private val speechLanguages = listOf(
    SpeechLanguage("ko-KR", "한국어", TranslateLanguage.KOREAN),
    SpeechLanguage("en-US", "영어", TranslateLanguage.ENGLISH),
    SpeechLanguage("ja-JP", "일본어", TranslateLanguage.JAPANESE),
    SpeechLanguage("zh-CN", "중국어", TranslateLanguage.CHINESE),
    SpeechLanguage("fr-FR", "프랑스어", TranslateLanguage.FRENCH),
    SpeechLanguage("es-ES", "스페인어", TranslateLanguage.SPANISH),
    SpeechLanguage("de-DE", "독일어", TranslateLanguage.GERMAN),
    SpeechLanguage("it-IT", "이탈리아어", TranslateLanguage.ITALIAN),
    SpeechLanguage("pt-BR", "포르투갈어", TranslateLanguage.PORTUGUESE),
    SpeechLanguage("ru-RU", "러시아어", TranslateLanguage.RUSSIAN),
    SpeechLanguage("hi-IN", "힌디어", TranslateLanguage.HINDI),
    SpeechLanguage("ar-SA", "아랍어", TranslateLanguage.ARABIC),
    SpeechLanguage("th-TH", "태국어", TranslateLanguage.THAI),
    SpeechLanguage("vi-VN", "베트남어", TranslateLanguage.VIETNAMESE),
    SpeechLanguage("id-ID", "인도네시아어", TranslateLanguage.INDONESIAN),
    SpeechLanguage("tr-TR", "튀르키예어", TranslateLanguage.TURKISH),
    SpeechLanguage("nl-NL", "네덜란드어", TranslateLanguage.DUTCH),
    SpeechLanguage("pl-PL", "폴란드어", TranslateLanguage.POLISH),
    SpeechLanguage("uk-UA", "우크라이나어", TranslateLanguage.UKRAINIAN),
    SpeechLanguage("sv-SE", "스웨덴어", TranslateLanguage.SWEDISH),
    SpeechLanguage("cs-CZ", "체코어", TranslateLanguage.CZECH),
    SpeechLanguage("el-GR", "그리스어", TranslateLanguage.GREEK)
)

private data class SavedNote(
    val id: String,
    val title: String,
    val createdAt: String,
    val languageTag: String,
    val body: String,
    /** Optional app-private WAV kept for playback and local re-transcription. */
    val audioPath: String? = null,
    /** User-defined labels; old saved records load with an empty list. */
    val tags: List<String> = emptyList()
)

private object NoteStore {
    private const val PREFS = "sorinote_free_notes"
    private const val KEY = "notes_json"

    fun load(context: Context): List<SavedNote> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val json = org.json.JSONArray(raw)
            buildList {
                for (i in 0 until json.length()) {
                    val item = json.optJSONObject(i) ?: continue
                    val audioPath = item.optString("audioPath").takeIf { it.isNotBlank() && it != "null" }
                    val storedTags = item.optJSONArray("tags")
                    val tags = buildList<String> {
                        val seenTags = mutableSetOf<String>()
                        if (storedTags != null) {
                            for (tagIndex in 0 until storedTags.length()) {
                                val tag = storedTags.optString(tagIndex).trim().take(32)
                                val normalized = tag.lowercase(Locale.ROOT)
                                if (tag.isNotBlank() && this.size < 12 && seenTags.add(normalized)) this.add(tag)
                            }
                        }
                    }
                    add(SavedNote(
                        item.optString("id"), item.optString("title", "음성 메모"),
                        item.optString("createdAt"), item.optString("languageTag", "ko-KR"),
                        item.optString("body"), audioPath, tags
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    fun write(context: Context, notes: List<SavedNote>) {
        val arr = org.json.JSONArray()
        notes.take(250).forEach { note ->
            val item = org.json.JSONObject()
                .put("id", note.id)
                .put("title", note.title)
                .put("createdAt", note.createdAt)
                .put("languageTag", note.languageTag)
                .put("body", note.body)
            note.audioPath?.let { item.put("audioPath", it) }
            val tags = org.json.JSONArray()
            note.tags.take(12).forEach { tags.put(it.take(32)) }
            item.put("tags", tags)
            arr.put(item)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}

/** Parse a compact tag field; caps keep local metadata bounded and predictable. */
private fun parseTags(raw: String): List<String> {
    val parsed = mutableListOf<String>()
    raw.split(',', '，', ';', '；', '\n')
        .asSequence()
        .map { it.trim().removePrefix("#").trim().take(32) }
        .filter { it.isNotBlank() }
        .forEach { tag ->
            if (parsed.size < 12 && parsed.none { it.equals(tag, ignoreCase = true) }) parsed.add(tag)
        }
    return parsed
}

@Composable
private fun SoriNoteScreen() {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("녹취") }
    var language by remember { mutableStateOf(speechLanguages.first()) }
    var targetLanguage by remember { mutableStateOf(speechLanguages[1]) }
    var languageMenuOpen by remember { mutableStateOf(false) }
    var targetMenuOpen by remember { mutableStateOf(false) }
    var title by remember { mutableStateOf("") }
    var tagsText by remember { mutableStateOf("") }
    var finalText by remember { mutableStateOf("") }
    var partialText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("무료 온디바이스 음성 인식 준비") }
    var error by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var pendingAccurateStart by remember { mutableStateOf(false) }
    var accurateRecording by remember { mutableStateOf(false) }
    var accurateTranscribing by remember { mutableStateOf(false) }
    var downloadingModel by remember { mutableStateOf(false) }
    var modelProgress by remember { mutableStateOf(0) }
    var modelReady by remember { mutableStateOf(WhisperModelManager.isReady(context)) }
    var accurateStatus by remember { mutableStateOf(if (modelReady) "고정밀 오프라인 모델 설치됨" else "고정밀 모델 미설치 · 약 547 MiB 다운로드 필요") }
    var contextHint by remember { mutableStateOf(context.getSharedPreferences("sorinote_settings", Context.MODE_PRIVATE).getString("whisper_context_hint", "") ?: "") }
    var whisperAutoDetect by remember { mutableStateOf(context.getSharedPreferences("sorinote_settings", Context.MODE_PRIVATE).getBoolean("whisper_auto_detect", false)) }
    var lastDetectedLanguage by remember { mutableStateOf("") }
    var audioFileTranscribing by remember { mutableStateOf(false) }
    var busyTranslate by remember { mutableStateOf(false) }
    var translation by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var selectedNoteId by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var editingSelectedNote by remember { mutableStateOf(false) }
    var editedNoteTitle by remember { mutableStateOf("") }
    var editedNoteTags by remember { mutableStateOf("") }
    var editedNoteBody by remember { mutableStateOf("") }
    val notes = remember { mutableStateListOf<SavedNote>().apply { addAll(NoteStore.load(context)) } }
    var pendingAudioPath by remember { mutableStateOf<String?>(null) }
    val mediaPlayerState = remember { mutableStateOf<MediaPlayer?>(null) }
    var playbackPath by remember { mutableStateOf<String?>(null) }
    var playbackStatus by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayerState.value?.let { player ->
                runCatching { if (player.isPlaying) player.stop() }
                runCatching { player.release() }
            }
            mediaPlayerState.value = null
        }
    }

    fun stopPlayback(clearMessage: Boolean = true) {
        val player = mediaPlayerState.value
        mediaPlayerState.value = null
        playbackPath = null
        if (player != null) {
            runCatching { if (player.isPlaying) player.stop() }
            runCatching { player.release() }
        }
        if (clearMessage) playbackStatus = ""
    }

    fun togglePlayback(path: String?) {
        if (path.isNullOrBlank()) {
            playbackStatus = "이 기록에는 저장된 오디오가 없습니다."
            return
        }
        if (playbackPath == path && mediaPlayerState.value != null) {
            stopPlayback()
            return
        }
        val file = File(path)
        if (!file.isFile || !file.canRead()) {
            playbackStatus = "저장된 오디오 파일을 찾을 수 없습니다."
            stopPlayback(clearMessage = false)
            return
        }
        stopPlayback()
        val player = MediaPlayer()
        mediaPlayerState.value = player
        playbackPath = path
        playbackStatus = "오디오 재생 준비 중…"
        try {
            player.setDataSource(file.absolutePath)
            player.setOnPreparedListener { readyPlayer ->
                if (mediaPlayerState.value === readyPlayer) {
                    readyPlayer.start()
                    playbackStatus = "녹음 재생 중"
                } else {
                    runCatching { readyPlayer.release() }
                }
            }
            player.setOnCompletionListener { completedPlayer ->
                if (mediaPlayerState.value === completedPlayer) {
                    mediaPlayerState.value = null
                    playbackPath = null
                    playbackStatus = "재생 완료"
                }
                runCatching { completedPlayer.release() }
            }
            player.setOnErrorListener { failedPlayer, _, _ ->
                if (mediaPlayerState.value === failedPlayer) {
                    mediaPlayerState.value = null
                    playbackPath = null
                    playbackStatus = "오디오 재생에 실패했습니다."
                }
                runCatching { failedPlayer.release() }
                true
            }
            player.prepareAsync()
        } catch (e: Exception) {
            if (mediaPlayerState.value === player) {
                mediaPlayerState.value = null
                playbackPath = null
            }
            runCatching { player.release() }
            playbackStatus = "오디오 재생 오류: ${e.localizedMessage ?: "파일을 열 수 없습니다."}"
        }
    }

    fun persistAudioForHistory(source: File): File {
        val recordingsDir = File(context.filesDir, "recordings")
        if (!recordingsDir.exists() && !recordingsDir.mkdirs()) {
            throw IllegalStateException("오디오 기록 폴더를 만들 수 없습니다.")
        }
        val sourceFile = source.canonicalFile
        val destinationDir = recordingsDir.canonicalFile
        if (sourceFile.parentFile == destinationDir) return sourceFile
        val destination = File(destinationDir, "sorinote-audio-${System.currentTimeMillis()}-${UUID.randomUUID()}.wav")
        sourceFile.copyTo(destination, overwrite = false)
        return destination
    }

    fun clearPendingAudio() {
        val oldPath = pendingAudioPath
        if (!oldPath.isNullOrBlank() && notes.none { it.audioPath == oldPath }) {
            runCatching { File(oldPath).delete() }
        }
        pendingAudioPath = null
    }

    val controller = remember {
        LocalSpeechController(context.applicationContext) { state ->
            status = state.status
            finalText = state.finalText
            partialText = state.partialText
            listening = state.listening
            error = state.error.orEmpty()
        }
    }
    val audioRecorder = remember { LocalAudioRecorder(context.applicationContext) }
    DisposableEffect(controller, audioRecorder) { onDispose { controller.stop(); audioRecorder.release() } }

    fun startAccurateRecording() {
        try {
            clearPendingAudio()
            stopPlayback()
            controller.stop()
            finalText = ""
            partialText = ""
            val file = audioRecorder.start()
            accurateRecording = true
            accurateStatus = "고정밀 녹음 중 · 오디오는 이 기기에만 저장됩니다."
            error = ""
        } catch (e: Exception) {
            accurateRecording = false
            error = "녹음을 시작하지 못했습니다: ${e.localizedMessage ?: "오류"}"
        }
    }

    fun whisperLanguageCode(): String = if (whisperAutoDetect) "auto" else language.tag.substringBefore('-')

    fun applyDetectedWhisperLanguage(code: String) {
        val normalized = code.trim().lowercase(Locale.ROOT)
        val match = speechLanguages.firstOrNull { it.tag.substringBefore('-').equals(normalized, ignoreCase = true) }
        lastDetectedLanguage = match?.label ?: normalized.ifBlank { "확인 불가" }
        if (whisperAutoDetect && match != null) language = match
    }

    fun startWhisperTranscription(
        wav: File,
        importedAudio: Boolean = false,
        existingNoteId: String? = null
    ) {
        accurateTranscribing = true
        audioFileTranscribing = importedAudio
        accurateStatus = if (existingNoteId != null) "저장 기록을 고정밀로 재전사 중…"
            else if (importedAudio) "Whisper로 오디오 파일 전사 중…"
            else "고정밀 전사 중 · 오디오 길이와 기기 성능에 따라 시간이 걸립니다."
        error = ""
        stopPlayback()
        val model = WhisperModelManager.modelFile(context)
        val lang = whisperLanguageCode()
        val prompt = contextHint.trim().take(500)
        Thread({
            var result = ""
            var detectedCode = ""
            var failure: String? = null
            var retainedAudio: File? = null
            try {
                val response = WhisperNative.transcribe(
                    model.absolutePath,
                    wav.absolutePath,
                    lang,
                    prompt,
                    (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 8)
                )
                detectedCode = response.getOrNull(0).orEmpty()
                result = response.getOrNull(1).orEmpty()
                if (result.isNotBlank()) {
                    retainedAudio = try { persistAudioForHistory(wav) } catch (_: Exception) { null }
                }
            } catch (e: Throwable) {
                failure = e.localizedMessage ?: e.javaClass.simpleName
            } finally {
                val storedPath = retainedAudio?.absolutePath
                if (storedPath != wav.absolutePath && existingNoteId == null) {
                    runCatching { wav.delete() }
                } else if (result.isBlank() && existingNoteId == null) {
                    runCatching { wav.delete() }
                }
            }
            Handler(Looper.getMainLooper()).post {
                accurateTranscribing = false
                audioFileTranscribing = false
                if (result.isBlank()) {
                    accurateStatus = if (existingNoteId != null) "저장 기록 재전사 실패" else if (importedAudio) "오디오 파일 전사 실패" else "고정밀 전사 실패"
                    error = "Whisper 전사에 실패했습니다${failure?.let { ": $it" } ?: "."} 모델 파일, 오디오 형식, 기기 메모리를 확인하세요."
                } else {
                    applyDetectedWhisperLanguage(detectedCode)
                    val transcript = result.trim()
                    val retainedPath = retainedAudio?.absolutePath
                    if (existingNoteId != null) {
                        val index = notes.indexOfFirst { it.id == existingNoteId }
                        if (index >= 0) {
                            val previous = notes[index]
                            notes[index] = previous.copy(
                                body = transcript,
                                languageTag = language.tag,
                                audioPath = retainedPath ?: previous.audioPath
                            )
                            NoteStore.write(context, notes.toList())
                            selectedNoteId = existingNoteId
                            accurateStatus = "저장 기록 재전사 완료 · 이전 녹취록을 새 결과로 교체했습니다."
                            playbackStatus = ""
                            summary = ""
                            translation = ""
                        } else {
                            finalText = transcript
                            pendingAudioPath = retainedPath
                            accurateStatus = "재전사는 완료했지만 원래 저장 기록을 찾지 못했습니다. 결과를 확인한 후 저장하세요."
                        }
                    } else {
                        pendingAudioPath = retainedPath
                        finalText = transcript
                        partialText = ""
                        val detectedLabel = if (whisperAutoDetect) " · 감지 언어: $lastDetectedLanguage" else ""
                        val retentionLabel = if (retainedPath == null) " · 오디오는 보존하지 못했습니다" else " · 재생/재전사 가능"
                        accurateStatus = (if (importedAudio) "오디오 파일 전사 완료" else "고정밀 오프라인 전사 완료") + detectedLabel + retentionLabel + " · 결과를 검토한 후 저장하세요."
                    }
                }
            }
        }, if (existingNoteId != null) "sorinote-whisper-retranscribe" else if (importedAudio) "sorinote-whisper-file-transcribe" else "sorinote-whisper-transcribe").start()
    }

    fun transcribeImportedAudio(uri: Uri) {
        if (listening || accurateRecording || accurateTranscribing || downloadingModel) return
        clearPendingAudio()
        stopPlayback()
        val model = WhisperModelManager.modelFile(context)
        if (!modelReady || !WhisperModelManager.isReady(context) || !model.exists()) {
            error = "고정밀 모델이 준비되지 않았습니다. 모델 다운로드를 완료한 뒤 다시 시도하세요."
            accurateStatus = "고정밀 모델 미설치"
            return
        }
        val displayName = try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        } catch (_: Exception) { null }
        if (title.isBlank() && !displayName.isNullOrBlank()) title = displayName.substringBeforeLast('.', displayName).take(80)
        finalText = ""
        partialText = ""
        accurateTranscribing = true
        audioFileTranscribing = true
        accurateStatus = "오디오 파일 변환 준비 중…"
        error = ""
        val wav = File(context.cacheDir, "sorinote-import-${UUID.randomUUID()}.wav")
        val lang = whisperLanguageCode()
        val prompt = contextHint.trim().take(500)
        val mainHandler = Handler(Looper.getMainLooper())
        Thread({
            var result = ""
            var detectedCode = ""
            var failure: String? = null
            var retainedAudio: File? = null
            try {
                AudioFileTranscoder.convertToWav(context, uri, wav) { progress ->
                    mainHandler.post { accurateStatus = "오디오 파일 변환 중: $progress%" }
                }
                mainHandler.post { accurateStatus = "Whisper 오프라인 전사 중…" }
                val response = WhisperNative.transcribe(
                    model.absolutePath, wav.absolutePath, lang, prompt,
                    (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 8)
                )
                detectedCode = response.getOrNull(0).orEmpty()
                result = response.getOrNull(1).orEmpty()
                if (result.isNotBlank()) {
                    retainedAudio = try { persistAudioForHistory(wav) } catch (_: Exception) { null }
                }
            } catch (e: Throwable) {
                failure = e.localizedMessage ?: e.javaClass.simpleName
            } finally {
                if (retainedAudio?.absolutePath != wav.absolutePath) runCatching { wav.delete() }
            }
            mainHandler.post {
                accurateTranscribing = false
                audioFileTranscribing = false
                if (result.isBlank()) {
                    accurateStatus = "오디오 파일 전사 실패"
                    error = "파일 전사에 실패했습니다${failure?.let { ": $it" } ?: "."} 지원되지 않는 파일 형식인지 확인하세요."
                } else {
                    applyDetectedWhisperLanguage(detectedCode)
                    finalText = result.trim()
                    partialText = ""
                    pendingAudioPath = retainedAudio?.absolutePath
                    val detectedLabel = if (whisperAutoDetect) " · 감지 언어: $lastDetectedLanguage" else ""
                    val retentionLabel = if (retainedAudio == null) " · 오디오는 보존하지 못했습니다" else " · 재생/재전사 가능"
                    accurateStatus = "오디오 파일 전사 완료$detectedLabel$retentionLabel · 결과를 검토한 후 저장하세요."
                }
            }
        }, "sorinote-audio-import").start()
    }

    fun startModelDownload(onSuccess: () -> Unit) {
        if (downloadingModel || accurateTranscribing) return
        downloadingModel = true
        modelProgress = 0
        accurateStatus = "고정밀 Whisper 모델 다운로드 준비 중…"
        WhisperModelManager.download(context, { progress ->
            modelProgress = progress
            accurateStatus = "모델 다운로드 중: $progress% · 약 547 MiB"
        }) { result ->
            downloadingModel = false
            result.onSuccess {
                modelReady = true
                accurateStatus = "고정밀 모델 설치 완료"
                onSuccess()
            }.onFailure { e ->
                accurateStatus = "모델 다운로드 실패"
                error = e.localizedMessage ?: "모델 다운로드에 실패했습니다. Wi-Fi 연결과 저장 공간을 확인하세요."
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            error = ""
            if (pendingAccurateStart) {
                pendingAccurateStart = false
                startAccurateRecording()
            } else {
                clearPendingAudio()
                stopPlayback()
                controller.start(language.tag, finalText)
            }
        } else {
            pendingAccurateStart = false
            error = "마이크 권한이 필요합니다. 앱 설정에서 마이크 권한을 허용해 주세요."
        }
    }

    val openAudioLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            if (modelReady && WhisperModelManager.isReady(context)) transcribeImportedAudio(uri)
            else startModelDownload { transcribeImportedAudio(uri) }
        }
    }

    val shownTranscript = listOf(finalText.trim(), partialText.trim()).filter { it.isNotBlank() }.joinToString("\n")

    fun requestStart() {
        error = ""
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            clearPendingAudio()
            stopPlayback()
            controller.start(language.tag, finalText)
        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun requestAccurateStart() {
        error = ""
        if (downloadingModel || accurateTranscribing) return
        if (!modelReady || !WhisperModelManager.isReady(context)) {
            startModelDownload { accurateStatus = "고정밀 모델 설치 완료 · 녹음을 시작할 수 있습니다." }
            return
        }
        pendingAccurateStart = true
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            pendingAccurateStart = false
            startAccurateRecording()
        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    fun stopAndTranscribeAccurate() {
        try {
            val wav = audioRecorder.stop()
            accurateRecording = false
            if (wav == null) {
                accurateStatus = "저장된 오디오가 없습니다."
                return
            }
            startWhisperTranscription(wav, importedAudio = false)
        } catch (e: Exception) {
            accurateRecording = false
            accurateStatus = "녹음 종료 중 오류"
            error = e.localizedMessage ?: "녹음 파일을 완성하지 못했습니다."
        }
    }

    fun saveCurrentNote() {
        val body = shownTranscript.trim()
        if (body.isBlank()) {
            Toast.makeText(context, "저장할 녹취 내용이 없습니다.", Toast.LENGTH_SHORT).show()
            return
        }
        val titleText = title.trim().ifBlank { body.lineSequence().firstOrNull().orEmpty().take(32).ifBlank { "음성 메모" } }
        val createdAt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREA).format(Date())
        val note = SavedNote(UUID.randomUUID().toString(), titleText, createdAt, language.tag, body, pendingAudioPath, parseTags(tagsText))
        notes.add(0, note)
        pendingAudioPath = null
        tagsText = ""
        NoteStore.write(context, notes.toList())
        selectedNoteId = note.id
        editingSelectedNote = false
        selectedTab = "기록"
        title = ""
        summary = ""
        translation = ""
        Toast.makeText(context, "기기에 저장했습니다.", Toast.LENGTH_SHORT).show()
    }

    fun saveEditedNote(note: SavedNote) {
        val index = notes.indexOfFirst { it.id == note.id }
        if (index < 0) {
            error = "편집할 저장 기록을 찾을 수 없습니다."
            editingSelectedNote = false
            return
        }
        val body = editedNoteBody.trim()
        if (body.isBlank()) {
            error = "녹취록은 비워 둘 수 없습니다."
            return
        }
        notes[index] = note.copy(
            title = editedNoteTitle.trim().ifBlank { "음성 메모" }.take(100),
            body = body,
            tags = parseTags(editedNoteTags)
        )
        NoteStore.write(context, notes.toList())
        editingSelectedNote = false
        error = ""
        Toast.makeText(context, "녹취록을 수정했습니다.", Toast.LENGTH_SHORT).show()
    }

    fun copyText(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("소리노트", text))
        Toast.makeText(context, "복사했습니다.", Toast.LENGTH_SHORT).show()
    }

    fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, "녹취록 공유"))
    }

    fun translate(text: String, sourceTag: String) {
        if (text.isBlank()) return
        val source = speechLanguages.firstOrNull { it.tag == sourceTag } ?: speechLanguages.first()
        if (source.mlKitCode == targetLanguage.mlKitCode) {
            error = "원문 언어와 번역 언어가 같습니다. 번역 언어를 바꿔 주세요."
            return
        }
        busyTranslate = true
        error = ""
        translation = "번역 모델을 확인하는 중입니다. 처음에는 Wi-Fi로 모델을 다운로드합니다."
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(source.mlKitCode)
            .setTargetLanguage(targetLanguage.mlKitCode)
            .build()
        val translator = Translation.getClient(options)
        val conditions = DownloadConditions.Builder().requireWifi().build()
        translator.downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                translator.translate(text)
                    .addOnSuccessListener { translated ->
                        translation = translated
                        busyTranslate = false
                        translator.close()
                    }
                    .addOnFailureListener { e ->
                        error = "기기 내 번역에 실패했습니다: ${e.localizedMessage ?: "언어 모델을 확인하세요."}"
                        translation = ""
                        busyTranslate = false
                        translator.close()
                    }
            }
            .addOnFailureListener { e ->
                error = "번역 모델 다운로드에 실패했습니다. Wi-Fi 연결 후 다시 시도하세요. (${e.localizedMessage ?: "오류"})"
                translation = ""
                busyTranslate = false
                translator.close()
            }
    }

    val selectedNote = notes.firstOrNull { it.id == selectedNoteId }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("소리노트", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("무료 음성 녹취 · 기기 내 인식 · API 키 없음", style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (selectedTab == "녹취") Button(onClick = { selectedTab = "녹취" }) { Text("녹취") }
            else OutlinedButton(onClick = { selectedTab = "녹취" }) { Text("녹취") }
            if (selectedTab == "기록") Button(onClick = { selectedTab = "기록"; selectedNoteId = null }) { Text("저장 기록 (${notes.size})") }
            else OutlinedButton(onClick = { selectedTab = "기록"; selectedNoteId = null }) { Text("저장 기록 (${notes.size})") }
        }
        Divider()

        if (selectedTab == "녹취") {
            Text("인식 언어", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BoxButton(label = language.label, expanded = languageMenuOpen, onExpanded = { languageMenuOpen = it }, enabled = !listening && !accurateRecording && !accurateTranscribing) {
                    speechLanguages.forEach { item ->
                        DropdownMenuItem(text = { Text(item.label) }, onClick = { language = item; languageMenuOpen = false })
                    }
                }
                Spacer(Modifier.width(4.dp))
                if (!accurateRecording && !accurateTranscribing) {
                    if (!listening) Button(onClick = { requestStart() }) { Text(if (finalText.isBlank()) "녹취 시작" else "이어서 녹취") }
                    else Button(onClick = { controller.stop() }) { Text("녹취 종료") }
                }
            }
            Text(status, style = MaterialTheme.typography.bodySmall, color = if (listening) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Text("음성 인식은 Android 온디바이스 엔진을 사용합니다. 온라인 인식으로 자동 전환하지 않습니다.", style = MaterialTheme.typography.bodySmall)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("고정밀 오프라인 전사", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("실시간 받아쓰기보다 정확도를 높일 수 있도록 Whisper large-v3-turbo 양자화 모델을 이 기기에서 실행합니다. 첫 모델은 약 547 MiB이며, 서버 전사 API는 사용하지 않습니다.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = contextHint,
                        onValueChange = { value ->
                            contextHint = value.take(500)
                            context.getSharedPreferences("sorinote_settings", Context.MODE_PRIVATE).edit().putString("whisper_context_hint", contextHint).apply()
                        },
                        label = { Text("인식 보조 단어·고유명사 (선택)") },
                        placeholder = { Text("예: 김민수, 프로젝트 오로라, Kotlin, 회의실 A") },
                        supportingText = { Text("Whisper 녹음/파일 전사에만 적용됩니다. 최대 500자이며 정답을 보장하지 않습니다.") },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !accurateTranscribing && !downloadingModel
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = whisperAutoDetect,
                            enabled = !accurateTranscribing && !downloadingModel,
                            onCheckedChange = { value ->
                                whisperAutoDetect = value
                                context.getSharedPreferences("sorinote_settings", Context.MODE_PRIVATE).edit().putBoolean("whisper_auto_detect", value).apply()
                            }
                        )
                        Column(Modifier.weight(1f)) {
                            Text("Whisper 언어 자동 감지", fontWeight = FontWeight.Medium)
                            Text("켜면 고정밀 전사에서 언어 코드를 자동 선택합니다. 실시간 받아쓰기에는 적용되지 않습니다.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (whisperAutoDetect && lastDetectedLanguage.isNotBlank()) Text("최근 감지 언어: $lastDetectedLanguage", style = MaterialTheme.typography.labelMedium)
                    Text(accurateStatus, style = MaterialTheme.typography.bodySmall)
                    if (downloadingModel) {
                        androidx.compose.material3.LinearProgressIndicator(progress = { modelProgress / 100f }, modifier = Modifier.fillMaxWidth())
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { if (accurateRecording) stopAndTranscribeAccurate() else requestAccurateStart() },
                            enabled = !listening && !accurateTranscribing && !downloadingModel
                        ) {
                            Text(when {
                                downloadingModel -> "모델 다운로드 중…"
                                accurateTranscribing -> "고정밀 전사 중…"
                                accurateRecording -> "녹음 종료 · 전사 시작"
                                !modelReady -> "고정밀 모델 다운로드"
                                else -> "고정밀 녹음 시작"
                            })
                        }
                        OutlinedButton(
                            onClick = { openAudioLauncher.launch(arrayOf("audio/*")) },
                            enabled = !listening && !accurateRecording && !accurateTranscribing && !downloadingModel
                        ) { Text(if (audioFileTranscribing) "파일 전사 중…" else "오디오 가져오기") }
                        if (modelReady && !accurateRecording && !accurateTranscribing && !downloadingModel) {
                            Text("모델 준비됨", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    Text("파일 가져오기는 기기가 디코딩할 수 있는 오디오 파일을 PCM 16 kHz로 변환한 뒤 전사합니다. 고유명사 힌트는 결과를 도울 수 있지만 정답을 보장하지 않습니다. 자동 화자 분리와 Soniox 동급의 실시간 인식은 구현되어 있지 않습니다. 저장한 고정밀 녹음은 기록에서 다시 재생하고, 문맥 힌트를 바꿔 재전사할 수 있습니다.", style = MaterialTheme.typography.bodySmall)
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("실시간 녹취록", fontWeight = FontWeight.SemiBold)
                    Text(shownTranscript.ifBlank { if (listening) "말씀하시면 인식된 문장이 여기에 표시됩니다." else "녹취를 시작하면 텍스트가 여기에 표시됩니다." })
                }
            }
            if (error.isNotBlank()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(error, modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
            OutlinedTextField(value = title, onValueChange = { title = it.take(100) }, label = { Text("기록 제목 (선택)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(
                value = tagsText,
                onValueChange = { tagsText = it.take(400) },
                label = { Text("태그 (선택)") },
                placeholder = { Text("예: 회의, 업무, 인터뷰") },
                supportingText = { Text("쉼표 또는 세미콜론으로 구분 · 최대 12개") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { saveCurrentNote() }, enabled = shownTranscript.isNotBlank() && !listening && !accurateRecording && !accurateTranscribing) { Text("녹취록 저장") }
                OutlinedButton(onClick = { copyText(shownTranscript) }, enabled = shownTranscript.isNotBlank()) { Text("복사") }
                OutlinedButton(onClick = { shareText(shownTranscript) }, enabled = shownTranscript.isNotBlank()) { Text("공유") }
            }
            if (shownTranscript.isNotBlank() && !listening) {
                Text("기기 내 번역", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    BoxButton(label = "→ ${targetLanguage.label}", expanded = targetMenuOpen, onExpanded = { targetMenuOpen = it }) {
                        speechLanguages.forEach { item ->
                            DropdownMenuItem(text = { Text(item.label) }, onClick = { targetLanguage = item; targetMenuOpen = false })
                        }
                    }
                    Button(onClick = { translate(shownTranscript, language.tag) }, enabled = !busyTranslate) { Text(if (busyTranslate) "번역 중…" else "오프라인 번역") }
                }
                if (translation.isNotBlank()) Card { Text(translation, Modifier.padding(12.dp)) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { summary = makeLocalSummary(shownTranscript) }) { Text("핵심 문장 정리") }
                    if (summary.isNotBlank()) OutlinedButton(onClick = { copyText(summary) }) { Text("요약 복사") }
                }
                if (summary.isNotBlank()) Card { Text(summary, Modifier.padding(12.dp)) }
            }
            if (!listening && !accurateRecording && !accurateTranscribing && shownTranscript.isNotBlank()) {
                TextButton(onClick = { clearPendingAudio(); finalText = ""; partialText = ""; title = ""; tagsText = ""; translation = ""; summary = ""; error = ""; accurateStatus = "고정밀 오프라인 모델 준비" }) { Text("새 녹취 시작 전 내용 비우기") }
            }
            Spacer(Modifier.height(8.dp))
            Text("무료 사용 안내", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text("별도 API 키·유료 STT 서버가 없습니다. 인식은 기기의 오프라인 음성 엔진에 의존하므로 기기/언어 모델이 지원되지 않으면 동작하지 않을 수 있습니다. 번역 모델은 처음 한 번 Wi-Fi로 다운로드하며, 번역 자체는 기기에서 실행합니다.", style = MaterialTheme.typography.bodySmall)
        } else {
            if (selectedNote != null) {
                TextButton(onClick = { selectedNoteId = null; editingSelectedNote = false; translation = ""; summary = "" }) { Text("← 모든 기록") }
                if (editingSelectedNote) {
                    OutlinedTextField(
                        value = editedNoteTitle,
                        onValueChange = { editedNoteTitle = it.take(100) },
                        label = { Text("기록 제목") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editedNoteTags,
                        onValueChange = { editedNoteTags = it.take(400) },
                        label = { Text("태그") },
                        placeholder = { Text("회의, 업무, 인터뷰") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = editedNoteBody,
                        onValueChange = { editedNoteBody = it },
                        label = { Text("녹취록 수정") },
                        modifier = Modifier.fillMaxWidth().height(260.dp),
                        minLines = 8
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { saveEditedNote(selectedNote) }) { Text("수정 저장") }
                        OutlinedButton(onClick = { editingSelectedNote = false; error = "" }) { Text("취소") }
                    }
                } else {
                    Text(selectedNote.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(selectedNote.createdAt, style = MaterialTheme.typography.bodySmall)
                    if (selectedNote.tags.isNotEmpty()) {
                        Text(selectedNote.tags.joinToString("  ") { "#${it}" }, style = MaterialTheme.typography.labelMedium)
                    }
                    Card {
                        Text(selectedNote.body, Modifier.fillMaxWidth().padding(14.dp))
                    }
                    OutlinedButton(onClick = {
                        editedNoteTitle = selectedNote.title
                        editedNoteTags = selectedNote.tags.joinToString(", ")
                        editedNoteBody = selectedNote.body
                        editingSelectedNote = true
                        error = ""
                    }) { Text("제목·녹취록 수정") }
                }
                val savedAudio = selectedNote.audioPath?.let { File(it) }?.takeIf { it.isFile && it.canRead() }
                if (savedAudio != null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { togglePlayback(savedAudio.absolutePath) }) {
                            Text(if (playbackPath == savedAudio.absolutePath) "재생 중지" else "녹음 재생")
                        }
                        OutlinedButton(
                            onClick = {
                                language = speechLanguages.firstOrNull { it.tag == selectedNote.languageTag } ?: language
                                if (modelReady && WhisperModelManager.isReady(context)) {
                                    startWhisperTranscription(savedAudio, existingNoteId = selectedNote.id)
                                } else {
                                    startModelDownload { startWhisperTranscription(savedAudio, existingNoteId = selectedNote.id) }
                                }
                            },
                            enabled = !accurateTranscribing && !downloadingModel
                        ) { Text(if (accurateTranscribing) "재전사 중…" else "고정밀 재전사") }
                    }
                    Text("오디오는 앱 내부에 보관됩니다. 기록을 삭제하면 함께 삭제됩니다.", style = MaterialTheme.typography.bodySmall)
                } else {
                    Text("저장된 원본 오디오가 없습니다. 이전 앱 버전에서 생성한 기록은 텍스트만 보관됩니다.", style = MaterialTheme.typography.bodySmall)
                }
                if (playbackStatus.isNotBlank()) Text(playbackStatus, style = MaterialTheme.typography.bodySmall)
                if (accurateTranscribing) Text(accurateStatus, style = MaterialTheme.typography.bodySmall)
                if (!editingSelectedNote) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { copyText(selectedNote.body) }) { Text("복사") }
                    OutlinedButton(onClick = {
                        val tagLine = selectedNote.tags.takeIf { it.isNotEmpty() }?.joinToString(" ") { "#${it}" }?.plus("\n\n").orEmpty()
                        shareText(selectedNote.title + "\n" + tagLine + selectedNote.body)
                    }) { Text("공유") }
                    OutlinedButton(onClick = { summary = makeLocalSummary(selectedNote.body) }) { Text("핵심 문장 정리") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    BoxButton(label = "→ ${targetLanguage.label}", expanded = targetMenuOpen, onExpanded = { targetMenuOpen = it }) {
                        speechLanguages.forEach { item ->
                            DropdownMenuItem(text = { Text(item.label) }, onClick = { targetLanguage = item; targetMenuOpen = false })
                        }
                    }
                    Button(onClick = { translate(selectedNote.body, selectedNote.languageTag) }, enabled = !busyTranslate) { Text(if (busyTranslate) "번역 중…" else "기기 내 번역") }
                    Spacer(Modifier.width(2.dp))
                    TextButton(onClick = { confirmDelete = true }) { Text("삭제") }
                }
                if (summary.isNotBlank()) Card { Text(summary, Modifier.padding(12.dp)) }
                if (translation.isNotBlank()) Card { Text(translation, Modifier.padding(12.dp)) }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                if (confirmDelete) AlertDialog(
                    onDismissRequest = { confirmDelete = false },
                    title = { Text("기록 삭제") },
                    text = { Text("이 녹취록을 기기에서 삭제할까요?") },
                    confirmButton = { TextButton(onClick = {
                        val keep = notes.filterNot { it.id == selectedNote.id }
                        selectedNote.audioPath?.let { audioPath ->
                            if (keep.none { it.audioPath == audioPath }) runCatching { File(audioPath).delete() }
                        }
                        if (playbackPath == selectedNote.audioPath) stopPlayback()
                        notes.clear(); notes.addAll(keep); NoteStore.write(context, keep)
                        selectedNoteId = null; editingSelectedNote = false; confirmDelete = false; summary = ""; translation = ""
                    }) { Text("삭제") } },
                    dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("취소") } }
                )
            } else {
                OutlinedTextField(value = search, onValueChange = { search = it }, label = { Text("제목 또는 내용 검색") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                val filtered = notes.filter { note ->
                    note.title.contains(search, true) || note.body.contains(search, true) || note.tags.any { it.contains(search, true) }
                }
                if (filtered.isEmpty()) Text(if (notes.isEmpty()) "저장된 기록이 없습니다." else "검색 결과가 없습니다.")
                else LazyColumn(modifier = Modifier.fillMaxWidth().height(520.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered, key = { it.id }) { note ->
                        Card(onClick = { selectedNoteId = note.id; editingSelectedNote = false; translation = ""; summary = ""; error = "" }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(note.title, fontWeight = FontWeight.SemiBold)
                                Text(note.createdAt, style = MaterialTheme.typography.labelSmall)
                                if (note.tags.isNotEmpty()) Text(note.tags.joinToString("  ") { "#${it}" }, style = MaterialTheme.typography.labelSmall)
                                Text(note.body, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun BoxButton(label: String, expanded: Boolean, onExpanded: (Boolean) -> Unit, enabled: Boolean = true, menuItems: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box {
        OutlinedButton(onClick = { onExpanded(true) }, enabled = enabled) { Text(label) }
        DropdownMenu(expanded = expanded, onDismissRequest = { onExpanded(false) }) { menuItems() }
    }
}

private fun makeLocalSummary(text: String): String {
    val sentences = text.replace("\r", "\n")
        .split(Regex("(?<=[.!?。！？])\\s+|\\n+"))
        .map { it.trim() }
        .filter { it.length >= 5 }
        .distinct()
    if (sentences.isEmpty()) return "정리할 문장이 충분하지 않습니다."
    val taskPattern = Regex("해야|하기로|할 일|담당|제출|확인|까지|예정|필요|예약|공유|조치|요청|완료|진행|검토|구매|연락|todo|action|follow.?up|must|need to|deadline", RegexOption.IGNORE_CASE)
    val keywords = listOf("결정", "문제", "중요", "일정", "비용", "마감", "원인", "대안", "목표", "결론", "결정", "계획", "해야", "하기로", "담당", "까지")
    val ranked = sentences.mapIndexed { index, sentence ->
        val score = keywords.count { sentence.contains(it, true) } * 3 + (if (taskPattern.containsMatchIn(sentence)) 4 else 0) + (if (index == 0) 1 else 0)
        index to score
    }
    val keySentences = ranked.sortedWith(compareByDescending<Pair<Int, Int>> { it.second }.thenBy { it.first })
        .take(4).sortedBy { it.first }.map { sentences[it.first] }
    val tasks = sentences.filter { taskPattern.containsMatchIn(it) }.take(8)
    return buildString {
        append("핵심 문장 (자동 추출)\n")
        keySentences.forEach { append("• ").append(it).append('\n') }
        append("\n할 일 후보\n")
        if (tasks.isEmpty()) append("• 명시적인 할 일 표현을 찾지 못했습니다.")
        else tasks.forEach { append("• ").append(it).append('\n') }
        append("\n※ AI 생성 요약이 아니라 문장·키워드 기반의 로컬 정리입니다.")
    }
}
