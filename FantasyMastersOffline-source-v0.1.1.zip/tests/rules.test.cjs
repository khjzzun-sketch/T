const test = require('node:test');
const assert = require('node:assert/strict');
const FM = require('../app/src/main/assets/game/rules.js');
const cards = require('../app/src/main/assets/game/cards.js');

test('prototype database has stable unique IDs and expected card types', () => {
  const ids = cards.map(c => c.id);
  assert.equal(new Set(ids).size, ids.length);
  for (const card of cards) assert.ok(['land','unit','item','spell','enchant'].includes(card.type));
});

test('new game begins with 6 cards per player and local player active', () => {
  const deck = FM.buildStarterDeck(cards, 'forest');
  const state = FM.newGame({ cards, playerDeck: deck, rng: () => 0.2 });
  assert.equal(state.players.player.hand.length, 6);
  assert.equal(state.players.ai.hand.length, 6);
  assert.equal(state.activeId, 'player');
  assert.equal(state.players.player.deck.length, deck.length - 6);
});

test('one land may be played in a preparation phase and no more than ten can be held', () => {
  const land = cards.find(c => c.id === 'land_forest');
  const player = { hand: Array.from({length: 11}, (_, i) => ({...land, instanceId:`l${i}`})), lands: [], units: [], graveyard: [], playedLand:false, soulSpent:0 };
  const state = { status:'playing', activeId:'player', players:{ player, ai:{} }, log:[], round:1 };
  assert.equal(FM.playCard(state,'player','l0').ok, true);
  assert.equal(FM.playCard(state,'player','l1').ok, false);
  player.playedLand = false;
  player.lands = Array.from({length:10}, () => ({...land, ready:true}));
  assert.equal(FM.playCard(state,'player','l2').ok, false);
});

test('colored and generic soul payment uses only ready lands', () => {
  const p = { lands:[{souls:['forest'],ready:true},{souls:['neutral'],ready:true},{souls:['fire'],ready:false}], soulSpent:0 };
  assert.equal(FM.canPay(p,{forest:1,neutral:1}), true);
  assert.equal(FM.spendSoul(p,{forest:1,neutral:1}), true);
  assert.equal(p.lands.filter(x => x.ready).length, 0);
  assert.equal(FM.canPay(p,{forest:1}), false);
});

test('unit deployment spends the correct soul and enters field', () => {
  const unit = cards.find(c => c.id === 'unit_forest_scout');
  const p = { hand:[{...unit,instanceId:'u1'}], lands:[{souls:['forest'],ready:true}], units:[], graveyard:[], playedLand:false, soulSpent:0 };
  const state = { status:'playing',activeId:'player',players:{player:p,ai:{units:[],deck:[],name:'AI'}},log:[],round:1 };
  const result = FM.playCard(state,'player','u1');
  assert.equal(result.ok,true);
  assert.equal(p.units.length,1);
  assert.equal(p.hand.length,0);
  assert.equal(p.lands[0].ready,false);
});

test('coin attack is base plus successful coin flips times coin value', () => {
  const u = {ap:3,itemAP:0,tempAP:0,coin:{apCount:3,apValue:2}};
  const allHeads = FM._test.rollStat(u,'ap',() => 0.9);
  const allTails = FM._test.rollStat(u,'ap',() => 0.1);
  assert.equal(allHeads.value,9);
  assert.equal(allHeads.heads,3);
  assert.equal(allTails.value,3);
});

test('unblocked attack reduces opposing deck by rolled attack value', () => {
  const attacker = { id:'player', name:'A', units:[{instanceId:'a',name:'공격수',ap:3,dp:1,maxHp:2,hp:2,coin:{apCount:0,apValue:0},itemAP:0,tempAP:0,canAttack:true}], deck:[{id:'p1'}], hand:[], lands:[], graveyard:[] };
  const defender = { id:'ai', name:'B', units:[], deck:Array.from({length:10},(_,i)=>({id:`d${i}`})), hand:Array.from({length:6},(_,i)=>({id:`h${i}`})), graveyard:[], lands:[] };
  const state = { status:'playing',round:1,attackerId:'player',activeId:'ai',players:{player:attacker,ai:defender},log:[],rng:()=>0.1,prepared:{player:true,ai:true} };
  FM.resolveBattle(state);
  assert.equal(defender.deck.length,7);
  assert.equal(state.round,2);
  assert.equal(state.attackerId,'ai');
});

test('combat damage is AP minus DP; survived units return to their original HP', () => {
  const attacker = { id:'player', name:'A', units:[{instanceId:'a',name:'공격수',ap:4,dp:0,maxHp:3,hp:3,coin:{apCount:0,apValue:0},itemAP:0,tempAP:0,canAttack:true}], deck:[{id:'p1'}], hand:[], lands:[], graveyard:[] };
  const defender = { id:'ai', name:'B', units:[{instanceId:'b',name:'방어수',ap:1,dp:2,maxHp:5,hp:5,coin:{dpCount:0,dpValue:0},itemDP:0,tempDP:0,canAttack:true}], deck:[{id:'d'}], hand:Array.from({length:6},(_,i)=>({id:`h${i}`})), graveyard:[], lands:[] };
  const state = { status:'playing',round:1,attackerId:'player',activeId:'ai',players:{player:attacker,ai:defender},log:[],rng:()=>0.1,prepared:{player:true,ai:true} };
  FM.resolveBattle(state);
  assert.equal(defender.units.length,1);
  assert.equal(defender.units[0].hp,5);
});

test('damage spell destroys a target only when HP reaches zero', () => {
  const attacker = { id:'player', name:'나', deck:[{id:'p'}], hand:[{id:'s',instanceId:'s',name:'마법',type:'spell',cost:{forest:1},effect:{type:'damage',target:'enemyUnit',amount:3}}], lands:[{souls:['forest'],ready:true}], units:[], graveyard:[] };
  const aiUnit = {id:'u',instanceId:'u',name:'적 유닛',hp:2,maxHp:2,ap:1,dp:1,itemAP:0,itemDP:0,itemHP:0,tempAP:0,tempDP:0,tempHP:0,equipment:[]};
  const defender = { id:'ai',name:'AI',deck:[{id:'a'}],hand:[],lands:[],units:[aiUnit],graveyard:[] };
  const state = {status:'playing',activeId:'player',round:1,players:{player:attacker,ai:defender},log:[],rng:()=>0};
  const result = FM.playCard(state,'player','s','u');
  assert.equal(result.ok,true);
  assert.equal(defender.units.length,0);
  assert.equal(defender.graveyard.length,1);
});

test('AI completes its preparation phase and yields to the player', () => {
  const state = FM.newGame({cards,playerDeck:FM.buildStarterDeck(cards,'forest'),rng:()=>0.3});
  state.activeId = 'ai';
  FM._test.beginPhase(state,'ai');
  FM.runAIPhase(state,'ai');
  assert.equal(state.prepared.ai,true);
  assert.equal(state.activeId,'player');
});
