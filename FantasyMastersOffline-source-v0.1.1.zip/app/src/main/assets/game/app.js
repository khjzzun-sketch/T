(function () {
  'use strict';

  const STORE = 'fm_offline_v010';
  const DEMO_DECK_SIZE = 30;
  const ART = { land:'▤', unit:'♜', item:'⚔', spell:'✧', enchant:'◇' };
  const COLOR_LABEL = FM.COLOR_NAMES;
  let cards = [];
  let state = null;
  let selectedHandId = null;
  let selectedUnitId = null;
  let modalContext = null;
  let data = { extraCards: [], deckCounts: null, difficulty: 'normal', deckFaction: 'forest' };
  let logExpanded = true;

  function el(id) { return document.getElementById(id); }
  function safeRead() {
    try {
      const raw = localStorage.getItem(STORE);
      return raw ? JSON.parse(raw) : {};
    } catch (_) { return {}; }
  }
  function safeWrite() {
    try { localStorage.setItem(STORE, JSON.stringify(data)); }
    catch (_) { showDataMessage('저장 공간이 부족합니다. 카드 데이터 크기를 줄여주십시오.', true); }
  }
  function mergeCards() {
    const map = new Map((window.FM_CARDS || []).map(c => [c.id, FM.clone(c)]));
    (data.extraCards || []).forEach(c => map.set(c.id, FM.clone(c)));
    cards = Array.from(map.values());
    window.FM_ALL_CARDS = cards;
  }
  function defaultDeckCounts(faction) {
    const sample = FM.buildStarterDeck(cards, faction || 'forest');
    const counts = {};
    sample.forEach(c => counts[c.id] = (counts[c.id] || 0) + 1);
    return counts;
  }
  function currentDeckCounts() { return data.deckCounts || defaultDeckCounts('forest'); }
  function countDeck(counts) { return Object.values(counts).reduce((a, n) => a + Number(n || 0), 0); }
  function deckArray(counts) {
    const result = [];
    Object.entries(counts).forEach(([id, qty]) => {
      const card = cards.find(c => c.id === id);
      if (card) for (let i = 0; i < qty; i++) result.push(FM.clone(card));
    });
    return result;
  }
  function startMatch() {
    const deck = deckArray(currentDeckCounts());
    if (deck.length !== DEMO_DECK_SIZE) {
      alert(`대전 덱은 현재 데모 기준 ${DEMO_DECK_SIZE}장이어야 합니다. 덱 편집에서 장수를 맞춰주십시오.`);
      switchTab('deck');
      return;
    }
    const aiFaction = ({forest:'fire',fire:'water',water:'dark',dark:'metal',metal:'earth',earth:'light',light:'forest'})[data.deckFaction || 'forest'] || 'fire';
    state = FM.newGame({ cards, playerDeck: deck, aiFaction, difficulty: el('difficulty').value || data.difficulty || 'normal' });
    selectedHandId = null;
    selectedUnitId = null;
    renderAll();
  }
  function switchTab(name) {
    document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === `tab-${name}`));
    if (name === 'deck') renderDeck();
    if (name === 'library') renderLibrary();
    if (name === 'data') renderData();
  }
  function typeName(type) { return FM.TYPE_NAMES[type] || type; }
  function cardMeta(card) { return `${COLOR_LABEL[card.faction] || '무속성'} · ${typeName(card.type)}`; }
  function statsText(card) {
    if (card.type === 'unit') return `AP ${card.ap} · DP ${card.dp} · HP ${card.hp}`;
    if (card.type === 'land') return `소울 ${((card.souls || [card.faction]).map(x => COLOR_LABEL[x] || x)).join('/')}`;
    if (card.type === 'item' || card.type === 'enchant') return `AP +${card.apBonus || 0} · DP +${card.dpBonus || 0} · HP +${card.hpBonus || 0}`;
    return card.effect ? effectText(card.effect) : '특수 효과';
  }
  function effectText(effect) {
    if (effect.type === 'damage') return `피해 ${effect.amount}`;
    if (effect.type === 'heal') return `회복 ${effect.amount}`;
    if (effect.type === 'buff') return `AP +${effect.ap || 0} · DP +${effect.dp || 0} · HP +${effect.hp || 0}`;
    if (effect.type === 'draw') return `카드 ${effect.amount || 1}장 보충`;
    return '특수 효과';
  }
  function cardMarkup(card, selected, small) {
    const typeBadge = typeName(card.type);
    const artPath = typeof card.artImage === 'string' && /^cards\/[a-zA-Z0-9_-]+\.(png|jpg|jpeg|webp)$/i.test(card.artImage) ? card.artImage : null;
    const artContent = artPath ? `<img src="${escapeAttr(artPath)}" alt="" loading="lazy">` : `<span>${ART[card.type] || '✦'}</span>`;
    return `<div class="card ${selected ? 'selected' : ''} ${small ? 'small-card' : ''}" data-card-id="${escapeAttr(card.instanceId || card.id)}">
      <div class="card-art ${FM.cardArtClass(card)}">${artContent}<b class="card-type">${typeBadge}</b></div>
      <div class="card-body"><div class="card-name">${escapeHtml(card.name)}</div><div class="card-meta">${escapeHtml(cardMeta(card))}</div><div class="card-cost">${card.type === 'land' ? '설치 무료' : FM.costText(card.cost)}</div><div class="card-stats">${escapeHtml(statsText(card))}</div></div>
    </div>`;
  }
  function escapeHtml(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function escapeAttr(s) { return escapeHtml(s).replace(/`/g, '&#96;'); }
  function soulDisplay(p) {
    const ready = p.lands.filter(l => l.ready).length;
    return `${ready} / ${p.lands.length} · ${p.lands.map(l => (l.souls || [l.faction]).map(x => COLOR_LABEL[x] || x).join('/')).join(', ') || '지형 없음'}`;
  }
  function renderLands(id, p) {
    el(id).innerHTML = p.lands.length ? p.lands.map(l => `<div class="land-token ${l.ready ? '' : 'tapped'}"><b>${escapeHtml((l.souls || [l.faction]).map(x => COLOR_LABEL[x] || x).join('/'))}</b><span>${escapeHtml(l.name)}</span></div>`).join('') : '<div class="empty-state">아직 설치된 지형이 없습니다.</div>';
  }
  function renderUnits(id, p, selectable) {
    el(id).innerHTML = p.units.length ? p.units.map(u => `<button class="unit-token ${selectedUnitId === u.instanceId && selectable ? 'selected' : ''}" data-unit-id="${escapeAttr(u.instanceId)}" ${selectable ? '' : 'disabled'}><strong>${escapeHtml(u.name)}</strong><div class="stats"><span>AP ${FM.totalPower(u,'ap')}</span><span>DP ${FM.totalPower(u,'dp')}</span><span>HP ${u.hp}/${u.maxHp + (u.itemHP || 0)}</span></div><small>${u.equipment && u.equipment.length ? '장비: ' + escapeHtml(u.equipment.join(', ')) : '장비 없음'}</small></button>`).join('') : '<div class="empty-state">필드에 유닛이 없습니다.</div>';
  }
  function renderAll() {
    if (!state) return;
    const you = state.players.player, ai = state.players.ai;
    const playerPhase = state.activeId === 'player';
    const role = state.attackerId === state.activeId ? '공격' : '방어';
    el('round-label').textContent = `ROUND ${state.round}`;
    el('phase-label').textContent = playerPhase ? `나의 ${role} 준비` : `AI ${role} 준비`;
    el('turn-status').textContent = state.status === 'finished' ? (state.result === 'player' ? '승리' : '패배') : (playerPhase ? '내 차례' : 'AI 처리');
    el('ai-status').textContent = state.status === 'finished' ? (state.result === 'ai' ? '승리' : '패배') : (state.attackerId === 'ai' ? '공격 준비' : '방어 준비');
    el('player-status').textContent = state.status === 'finished' ? (state.result === 'player' ? '승리' : '패배') : (playerPhase ? `${role} 준비 단계` : 'AI 차례');
    el('ai-deck-count').textContent = ai.deck.length;
    el('ai-hand-count').textContent = ai.hand.length;
    el('player-deck-count').textContent = you.deck.length;
    el('player-hand-count').textContent = you.hand.length;
    el('hand-size').textContent = `${you.hand.length} / 6`;
    el('ai-unit-count').textContent = `${ai.units.length}장`;
    el('player-unit-count').textContent = `${you.units.length}장`;
    el('ai-soul').textContent = `소울 ${soulDisplay(ai)}`;
    el('player-soul').textContent = `소울 ${soulDisplay(you)}`;
    renderLands('ai-lands', ai); renderLands('player-lands', you);
    renderUnits('ai-units', ai, false); renderUnits('player-units', you, true);
    el('hand-cards').innerHTML = you.hand.map(c => cardMarkup(c, selectedHandId === c.instanceId, false)).join('') || '<div class="empty-state">패가 비어 있습니다.</div>';
    renderSelectedCard();
    el('play-card').disabled = !playerPhase || !selectedHandId || state.status !== 'playing';
    el('end-phase').disabled = !playerPhase || state.status !== 'playing';
    el('end-phase').textContent = playerPhase ? (state.attackerId === 'player' ? '공격 준비 완료' : '방어 준비 완료') : 'AI 진행 중';
    el('game-log').innerHTML = state.log.map(item => `<div class="log-entry">${escapeHtml(item.text)}</div>`).join('');
    el('game-log').style.display = logExpanded ? 'block' : 'none';
    if (state.status === 'finished') {
      const title = state.result === 'player' ? '승리하셨습니다.' : '패배하셨습니다.';
      el('selected-card-panel').textContent = `${title} 새 대전을 시작하거나 덱을 조정할 수 있습니다.`;
    }
  }
  function renderSelectedCard() {
    const box = el('selected-card-panel');
    const card = state.players.player.hand.find(c => c.instanceId === selectedHandId);
    if (!card) {
      box.classList.add('empty');
      box.textContent = selectedUnitId ? `선택된 아군 유닛: ${state.players.player.units.find(u => u.instanceId === selectedUnitId)?.name || '없음'}. 장비 카드를 선택해 사용하십시오.` : '사용할 카드를 선택하십시오.';
      return;
    }
    box.classList.remove('empty');
    box.innerHTML = `<strong>${escapeHtml(card.name)}</strong> · ${escapeHtml(cardMeta(card))}<br>${escapeHtml(card.text || '')}<br><span style="color:#e1c17c">${escapeHtml(statsText(card))}</span>`;
  }
  function chooseHand(instanceId) {
    selectedHandId = selectedHandId === instanceId ? null : instanceId;
    renderAll();
  }
  function chooseUnit(instanceId) {
    selectedUnitId = selectedUnitId === instanceId ? null : instanceId;
    renderAll();
  }
  function showTargetModal(title, candidates, callback) {
    modalContext = callback;
    el('target-options').innerHTML = candidates.length ? candidates.map(u => `<button class="target-option" data-target-id="${escapeAttr(u.instanceId)}"><strong>${escapeHtml(u.name)}</strong><small>AP ${FM.totalPower(u,'ap')} · DP ${FM.totalPower(u,'dp')} · HP ${u.hp}/${u.maxHp + (u.itemHP || 0)}</small></button>`).join('') : '<div class="empty-state">선택 가능한 대상이 없습니다.</div>';
    el('target-modal').classList.remove('hidden');
    el('target-modal').querySelector('h2').textContent = title;
  }
  function closeTargetModal() { el('target-modal').classList.add('hidden'); modalContext = null; }
  function playSelectedCard() {
    if (!state || state.activeId !== 'player' || !selectedHandId) return;
    const card = state.players.player.hand.find(c => c.instanceId === selectedHandId);
    if (!card) return;
    let candidates = [], title = '';
    if (card.type === 'item' || card.type === 'enchant') {
      candidates = state.players.player.units; title = '장착할 아군 유닛';
      if (!candidates.length) { alert('장착할 아군 유닛이 없습니다.'); return; }
    } else if (card.type === 'spell' && ['ownUnit','enemyUnit'].includes(card.effect?.target)) {
      candidates = card.effect.target === 'ownUnit' ? state.players.player.units : state.players.ai.units;
      title = card.effect.target === 'ownUnit' ? '효과를 받을 아군 유닛' : '마법의 대상이 될 적 유닛';
      if (!candidates.length) { alert('효과를 적용할 대상 유닛이 없습니다.'); return; }
    }
    if (candidates.length) {
      showTargetModal(title, candidates, targetId => completePlay(card, targetId));
    } else completePlay(card, null);
  }
  function completePlay(card, targetId) {
    const result = FM.playCard(state, 'player', card.instanceId, targetId);
    closeTargetModal();
    if (!result.ok) { alert(result.reason); return; }
    selectedHandId = null; selectedUnitId = null;
    renderAll();
  }
  function finishPhase() {
    if (!state || state.activeId !== 'player' || state.status !== 'playing') return;
    const result = FM.endPhase(state, 'player');
    if (!result.ok) alert(result.reason);
    selectedHandId = null; selectedUnitId = null;
    renderAll();
  }

  function renderDeck() {
    const counts = currentDeckCounts();
    const total = countDeck(counts);
    el('deck-count').textContent = total;
    el('deck-progress-bar').style.width = `${Math.min(100, total / DEMO_DECK_SIZE * 100)}%`;
    const entries = Object.entries(counts).filter(([,q]) => q > 0).map(([id,q]) => ({ card: cards.find(c => c.id === id), qty:q })).filter(x => x.card);
    el('deck-list').innerHTML = entries.length ? entries.map(({card,qty}) => `<div class="deck-item"><div class="mini-art ${FM.cardArtClass(card)}">${ART[card.type]}</div><div class="deck-item-main"><strong>${escapeHtml(card.name)}</strong><small>${escapeHtml(cardMeta(card))} · ${escapeHtml(FM.costText(card.cost))}</small></div><div class="qty-controls"><button data-deck-minus="${escapeAttr(card.id)}">−</button><b>${qty}</b><button data-deck-plus="${escapeAttr(card.id)}">+</button></div></div>`).join('') : '<div class="empty-state">덱이 비어 있습니다.</div>';
    renderDeckCatalogue();
  }
  function renderDeckCatalogue() {
    const query = (el('deck-search').value || '').trim().toLowerCase();
    const counts = currentDeckCounts();
    const visible = cards.filter(c => c.name.toLowerCase().includes(query) || (c.text || '').toLowerCase().includes(query));
    el('deck-catalogue').innerHTML = visible.map(c => `<div class="catalogue-item"><div class="mini-art ${FM.cardArtClass(c)}">${ART[c.type]}</div><div class="catalogue-main"><strong>${escapeHtml(c.name)}</strong><small>${escapeHtml(cardMeta(c))} · ${escapeHtml(statsText(c))}</small></div><div class="qty-controls"><b>${counts[c.id] || 0}</b><button data-deck-plus="${escapeAttr(c.id)}">+</button></div></div>`).join('') || '<div class="empty-state">검색 결과가 없습니다.</div>';
  }
  function adjustDeck(id, delta) {
    const counts = Object.assign({}, currentDeckCounts());
    const next = (counts[id] || 0) + delta;
    if (next < 0) return;
    if (delta > 0 && countDeck(counts) >= DEMO_DECK_SIZE) { alert(`현재 데모 덱은 ${DEMO_DECK_SIZE}장으로 제한됩니다.`); return; }
    if (next === 0) delete counts[id]; else counts[id] = next;
    data.deckCounts = counts; safeWrite(); renderDeck();
  }
  function renderLibrary() {
    const q = (el('library-search').value || '').trim().toLowerCase();
    const type = el('filter-type').value, faction = el('filter-faction').value;
    const found = cards.filter(c => (type === 'all' || c.type === type) && (faction === 'all' || c.faction === faction) && (!q || `${c.name} ${c.text || ''}`.toLowerCase().includes(q)));
    el('library-grid').innerHTML = found.map(c => `<article class="library-card"><div class="card-art ${FM.cardArtClass(c)}"><span>${ART[c.type]}</span></div><div class="card-body"><div class="card-name">${escapeHtml(c.name)}</div><div class="card-meta">${escapeHtml(cardMeta(c))} · ${escapeHtml(c.rarity || '일반')}</div><div class="card-stats">${escapeHtml(statsText(c))}</div><div class="card-desc">${escapeHtml(c.text || '')}</div></div></article>`).join('') || '<div class="empty-state">조건에 맞는 카드가 없습니다.</div>';
  }
  function validateCard(c) {
    const types = ['land','unit','item','spell','enchant'];
    const factions = ['dark','fire','water','forest','metal','earth','light','neutral'];
    if (!c || typeof c !== 'object') return '카드 객체가 아닙니다.';
    if (!/^[a-zA-Z0-9_-]{2,64}$/.test(String(c.id || ''))) return 'id는 2~64자의 영문·숫자·_- 조합이어야 합니다.';
    if (!String(c.name || '').trim()) return `${c.id}: name이 없습니다.`;
    if (!types.includes(c.type)) return `${c.id}: 지원하지 않는 type입니다.`;
    if (!factions.includes(c.faction)) return `${c.id}: faction 값이 올바르지 않습니다.`;
    if (c.type === 'land' && (!Array.isArray(c.souls) || !c.souls.length || c.souls.some(x => !factions.includes(x)))) return `${c.id}: land의 souls 배열이 올바르지 않습니다.`;
    if (c.type !== 'land' && (!c.cost || typeof c.cost !== 'object' || Object.entries(c.cost).some(([k,v]) => !factions.includes(k) || !Number.isInteger(v) || v < 0 || v > 10))) return `${c.id}: cost 데이터가 올바르지 않습니다.`;
    if (c.type === 'unit' && !['ap','dp','hp'].every(k => Number.isInteger(c[k]) && c[k] >= 0 && c[k] <= 99)) return `${c.id}: 유닛 AP/DP/HP 값이 필요합니다.`;
    if (c.type === 'spell' && (!c.effect || !['damage','heal','buff','draw','mill','drain'].includes(c.effect.type))) return `${c.id}: 지원하지 않는 spell effect입니다.`;
    if (c.coin && ['apCount','apValue','dpCount','dpValue'].some(k => c.coin[k] != null && (!Number.isInteger(c.coin[k]) || c.coin[k] < 0 || c.coin[k] > 30))) return `${c.id}: coin 데이터가 올바르지 않습니다.`;
    if (c.artImage != null && (typeof c.artImage !== 'string' || !/^cards\/[a-zA-Z0-9_-]+\.(png|jpg|jpeg|webp)$/i.test(c.artImage))) return `${c.id}: artImage는 cards/파일명.webp 형식이어야 합니다.`;
    return null;
  }
  function showDataMessage(message, error) {
    el('data-message').textContent = message;
    el('data-message').style.color = error ? '#e5a19b' : '#9fe0b8';
  }
  function importCards() {
    let parsed;
    try { parsed = JSON.parse(el('json-import').value); } catch (e) { showDataMessage(`JSON 문법 오류: ${e.message}`, true); return; }
    if (!Array.isArray(parsed) || !parsed.length) { showDataMessage('카드 객체 배열을 입력하십시오.', true); return; }
    for (const card of parsed) { const error = validateCard(card); if (error) { showDataMessage(error, true); return; } }
    const map = new Map((data.extraCards || []).map(c => [c.id, c]));
    parsed.forEach(c => map.set(c.id, FM.clone(c)));
    data.extraCards = Array.from(map.values());
    safeWrite(); mergeCards(); renderData(); renderDeck(); renderLibrary();
    showDataMessage(`${parsed.length}개 카드 데이터를 검증해 가져왔습니다. 기존 ID는 갱신되었습니다.`, false);
  }
  function exportCards() {
    el('json-import').value = JSON.stringify(cards, null, 2);
    el('json-import').focus(); el('json-import').select();
    showDataMessage('전체 카드 JSON을 입력란에 표시했습니다. 복사해 보관하십시오.', false);
  }
  function renderData() {
    el('data-card-count').textContent = cards.length;
  }

  function bindEvents() {
    document.querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => switchTab(b.dataset.tab)));
    el('new-match').addEventListener('click', startMatch);
    el('difficulty').addEventListener('change', () => { data.difficulty = el('difficulty').value; safeWrite(); });
    el('play-card').addEventListener('click', playSelectedCard);
    el('end-phase').addEventListener('click', finishPhase);
    el('clear-log').addEventListener('click', () => { logExpanded = !logExpanded; renderAll(); });
    el('hand-cards').addEventListener('click', e => { const card = e.target.closest('[data-card-id]'); if (card) chooseHand(card.dataset.cardId); });
    el('player-units').addEventListener('click', e => { const unit = e.target.closest('[data-unit-id]'); if (unit) chooseUnit(unit.dataset.unitId); });
    el('deck-list').addEventListener('click', e => {
      const minus = e.target.closest('[data-deck-minus]'), plus = e.target.closest('[data-deck-plus]');
      if (minus) adjustDeck(minus.dataset.deckMinus, -1); else if (plus) adjustDeck(plus.dataset.deckPlus, 1);
    });
    el('deck-catalogue').addEventListener('click', e => { const plus = e.target.closest('[data-deck-plus]'); if (plus) adjustDeck(plus.dataset.deckPlus, 1); });
    el('save-deck').addEventListener('click', () => { safeWrite(); alert('현재 덱 구성을 기기에 저장했습니다.'); });
    el('starter-deck').addEventListener('click', () => {
      const faction = el('starter-faction').value;
      const sample = FM.buildStarterDeck(cards, faction);
      const counts = {}; sample.forEach(c => counts[c.id] = (counts[c.id] || 0) + 1);
      data.deckCounts = counts; data.deckFaction = faction; safeWrite(); renderDeck();
    });
    el('deck-search').addEventListener('input', renderDeckCatalogue);
    ['library-search','filter-type','filter-faction'].forEach(id => el(id).addEventListener('input', renderLibrary));
    el('import-json').addEventListener('click', importCards);
    el('export-json').addEventListener('click', exportCards);
    el('close-modal').addEventListener('click', closeTargetModal);
    el('target-modal').addEventListener('click', e => {
      if (e.target.id === 'target-modal') closeTargetModal();
      const target = e.target.closest('[data-target-id]');
      if (target && modalContext) { const fn = modalContext; const id = target.dataset.targetId; closeTargetModal(); fn(id); }
    });
  }

  function init() {
    const saved = safeRead();
    data = Object.assign(data, saved);
    if (!['easy','normal','hard'].includes(data.difficulty)) data.difficulty = 'normal';
    mergeCards();
    el('difficulty').value = data.difficulty;
    bindEvents();
    startMatch();
    renderDeck(); renderLibrary(); renderData();
  }
  document.addEventListener('DOMContentLoaded', init);
})();
