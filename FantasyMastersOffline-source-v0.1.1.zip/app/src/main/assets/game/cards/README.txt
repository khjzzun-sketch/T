Place only card illustrations for which you have permission or an explicit reuse license in this folder.
Use a simple filename (letters, numbers, underscore, hyphen) and .png/.jpg/.jpeg/.webp.
Set the matching card JSON field to: "artImage": "cards/filename.webp"
The app references these files locally and does not download remote images.
No original/FAN-MADE MASTERS artwork is bundled in this prototype.
