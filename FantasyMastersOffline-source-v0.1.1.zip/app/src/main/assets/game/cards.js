(function (root) {
  'use strict';

  // Prototype cards are original test content, not restored original-game card data.
  // Full catalogue entries can be imported through the in-app JSON data manager.
  const cards = [
    { id:'land_forest', name:'고요한 숲길', type:'land', faction:'forest', souls:['forest'], rarity:'기본', text:'매 준비 단계에 숲 소울 1개를 생성합니다.' },
    { id:'land_fire', name:'잿불 언덕', type:'land', faction:'fire', souls:['fire'], rarity:'기본', text:'매 준비 단계에 불 소울 1개를 생성합니다.' },
    { id:'land_water', name:'은빛 호수', type:'land', faction:'water', souls:['water'], rarity:'기본', text:'매 준비 단계에 물 소울 1개를 생성합니다.' },
    { id:'land_dark', name:'그늘진 묘역', type:'land', faction:'dark', souls:['dark'], rarity:'기본', text:'매 준비 단계에 암흑 소울 1개를 생성합니다.' },
    { id:'land_metal', name:'고철 광맥', type:'land', faction:'metal', souls:['metal'], rarity:'기본', text:'매 준비 단계에 금속 소울 1개를 생성합니다.' },
    { id:'land_earth', name:'갈라진 황야', type:'land', faction:'earth', souls:['earth'], rarity:'기본', text:'매 준비 단계에 대지 소울 1개를 생성합니다.' },
    { id:'land_light', name:'새벽의 성소', type:'land', faction:'light', souls:['light'], rarity:'기본', text:'매 준비 단계에 빛 소울 1개를 생성합니다.' },
    { id:'land_neutral', name:'잊힌 교차로', type:'land', faction:'neutral', souls:['neutral'], rarity:'기본', text:'무속성 소울 1개를 생성합니다.' },
    { id:'land_dual', name:'쌍빛 샘', type:'land', faction:'forest', souls:['forest','light'], rarity:'실험', text:'숲 또는 빛 소울 1개를 생성합니다.' },

    { id:'unit_forest_scout', name:'숲의 척후병', type:'unit', faction:'forest', cost:{forest:1}, ap:2, dp:1, hp:3, coin:{apCount:1,apValue:1,dpCount:0,dpValue:0}, rarity:'기본', text:'빠르게 소환할 수 있는 정찰 유닛.' },
    { id:'unit_forest_guard', name:'고목 수호자', type:'unit', faction:'forest', cost:{forest:1,neutral:1}, ap:2, dp:3, hp:5, coin:{apCount:1,apValue:1,dpCount:1,dpValue:1}, rarity:'기본', text:'방어에 적합한 숲의 수호자.' },
    { id:'unit_fire_hound', name:'화염 사냥개', type:'unit', faction:'fire', cost:{fire:2}, ap:4, dp:1, hp:3, coin:{apCount:2,apValue:1,dpCount:0,dpValue:0}, rarity:'기본', text:'공격력이 높은 화염 유닛.' },
    { id:'unit_water_guard', name:'호수의 방패병', type:'unit', faction:'water', cost:{water:1,neutral:1}, ap:2, dp:4, hp:5, coin:{apCount:1,apValue:1,dpCount:2,dpValue:1}, rarity:'기본', text:'높은 방어력으로 전선을 지킵니다.' },
    { id:'unit_dark_mage', name:'황혼의 술사', type:'unit', faction:'dark', cost:{dark:2}, ap:3, dp:2, hp:4, coin:{apCount:2,apValue:1,dpCount:1,dpValue:1}, rarity:'기본', text:'암흑의 코인 공격을 사용합니다.' },
    { id:'unit_metal_sentinel', name:'강철 감시자', type:'unit', faction:'metal', cost:{metal:1,neutral:2}, ap:3, dp:4, hp:6, coin:{apCount:1,apValue:1,dpCount:2,dpValue:1}, rarity:'기본', text:'튼튼한 금속 유닛.' },
    { id:'unit_earth_golem', name:'대지 골렘', type:'unit', faction:'earth', cost:{earth:2,neutral:1}, ap:4, dp:3, hp:7, coin:{apCount:2,apValue:1,dpCount:1,dpValue:1}, rarity:'기본', text:'높은 체력을 지닌 대형 유닛.' },
    { id:'unit_light_mender', name:'여명의 치유사', type:'unit', faction:'light', cost:{light:2}, ap:2, dp:3, hp:5, coin:{apCount:1,apValue:1,dpCount:2,dpValue:1}, rarity:'기본', text:'전선을 유지하는 지원 유닛.' },
    { id:'unit_neutral_merc', name:'방랑 용병', type:'unit', faction:'neutral', cost:{neutral:2}, ap:3, dp:2, hp:4, coin:{apCount:1,apValue:1,dpCount:1,dpValue:1}, rarity:'기본', text:'어떤 속성 덱에도 넣을 수 있습니다.' },

    { id:'item_spear', name:'수호자의 창', type:'item', faction:'forest', cost:{forest:1}, apBonus:2, dpBonus:0, hpBonus:0, rarity:'기본', text:'장착 유닛의 AP +2.' },
    { id:'item_iron_shield', name:'철벽 방패', type:'item', faction:'metal', cost:{metal:1}, apBonus:0, dpBonus:2, hpBonus:2, rarity:'기본', text:'장착 유닛의 DP +2, HP +2.' },
    { id:'item_flame_charm', name:'불꽃 부적', type:'item', faction:'fire', cost:{fire:1}, apBonus:1, dpBonus:0, hpBonus:1, rarity:'기본', text:'장착 유닛의 AP +1, HP +1.' },

    { id:'spell_fire_burst', name:'불꽃 파열', type:'spell', faction:'fire', cost:{fire:1,neutral:1}, effect:{type:'damage',target:'enemyUnit',amount:3}, rarity:'기본', text:'상대 유닛 하나에 피해 3.' },
    { id:'spell_root_bind', name:'뿌리 속박', type:'spell', faction:'forest', cost:{forest:1}, effect:{type:'damage',target:'enemyUnit',amount:2}, rarity:'기본', text:'상대 유닛 하나에 피해 2.' },
    { id:'spell_mending_light', name:'새벽의 회복', type:'spell', faction:'light', cost:{light:1}, effect:{type:'heal',target:'ownUnit',amount:3}, rarity:'기본', text:'아군 유닛 하나의 체력을 3 회복.' },
    { id:'spell_dark_drain', name:'생명 흡수', type:'spell', faction:'dark', cost:{dark:1,neutral:1}, effect:{type:'damage',target:'enemyUnit',amount:2}, rarity:'기본', text:'상대 유닛 하나에 피해 2.' },
    { id:'spell_focus', name:'전장의 집중', type:'spell', faction:'neutral', cost:{neutral:1}, effect:{type:'buff',target:'ownUnit',ap:2,dp:1,hp:1}, rarity:'기본', text:'아군 유닛 하나의 AP +2, DP +1, HP +1. 이번 전투 후 효과 소멸.' },

    { id:'enchant_war_banner', name:'전장의 깃발', type:'enchant', faction:'metal', cost:{metal:1,neutral:1}, apBonus:1, dpBonus:1, hpBonus:0, rarity:'기본', text:'장착 유닛의 AP +1, DP +1.' }
  ];

  root.FM_CARDS = cards;
  if (typeof module !== 'undefined' && module.exports) module.exports = cards;
})(typeof window !== 'undefined' ? window : globalThis);
