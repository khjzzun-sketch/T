(function (root) {
  'use strict';

  const COLORS = ['dark', 'fire', 'water', 'forest', 'metal', 'earth', 'light', 'neutral'];
  const COLOR_NAMES = {
    dark: '암흑', fire: '불', water: '물', forest: '숲',
    metal: '금속', earth: '대지', light: '빛', neutral: '무속성'
  };
  const TYPE_NAMES = { land: '지형', unit: '유닛', item: '아이템', spell: '마법', enchant: '인챈트' };

  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function uid(prefix) { return (prefix || 'c') + '_' + Math.random().toString(36).slice(2, 10); }
  function sumCost(cost) { return Object.values(cost || {}).reduce((a, n) => a + (Number(n) || 0), 0); }
  function colorName(key) { return COLOR_NAMES[key] || key || '무속성'; }
  function costText(cost) {
    const entries = Object.entries(cost || {}).filter(([, n]) => n > 0);
    return entries.length ? entries.map(([k, v]) => `${colorName(k)} ${v}`).join(' · ') : '무료';
  }

  function makePlayer(id, name, deck, isAI) {
    return {
      id, name, isAI: !!isAI,
      deck: deck.map(c => ({ ...clone(c), instanceId: uid(id) })),
      hand: [], lands: [], units: [], graveyard: [],
      soulSpent: 0, playedLand: false,
      matchesWon: 0
    };
  }

  function shuffle(list, rng) {
    const a = list.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  function newGame(options) {
    const opts = options || {};
    const rng = opts.rng || Math.random;
    const cards = opts.cards || root.FM_CARDS || [];
    const playerDeck = opts.playerDeck || buildStarterDeck(cards, opts.playerFaction || 'forest');
    const aiFaction = opts.aiFaction || (opts.playerFaction === 'fire' ? 'water' : 'fire');
    const aiDeck = opts.aiDeck || buildStarterDeck(cards, aiFaction);
    const state = {
      version: 1,
      status: 'playing',
      result: null,
      round: 1,
      attackerId: 'player',
      activeId: 'player',
      prepared: { player: false, ai: false },
      players: {
        player: makePlayer('player', '나', shuffle(playerDeck, rng), false),
        ai: makePlayer('ai', 'AI 상대', shuffle(aiDeck, rng), true)
      },
      log: [],
      settings: { difficulty: opts.difficulty || 'normal', deckSize: playerDeck.length },
      rng
    };
    drawToSix(state, 'player');
    drawToSix(state, 'ai');
    beginPhase(state, state.attackerId);
    return state;
  }

  function buildStarterDeck(cards, faction) {
    const pool = cards.filter(c => c.faction === faction || c.faction === 'neutral');
    const fallback = cards.filter(c => c.faction === 'neutral' || c.faction === 'forest');
    const source = pool.length >= 6 ? pool : fallback;
    const lands = source.filter(c => c.type === 'land');
    const units = source.filter(c => c.type === 'unit');
    const others = source.filter(c => c.type === 'item' || c.type === 'spell' || c.type === 'enchant');
    const result = [];
    function addRepeated(list, wanted) {
      if (!list.length) return;
      for (let i = 0; i < wanted; i++) result.push(clone(list[i % list.length]));
    }
    addRepeated(lands, 8);
    addRepeated(units, 14);
    addRepeated(others, 8);
    return result;
  }

  function player(state, id) { return state.players[id]; }
  function opponentId(id) { return id === 'player' ? 'ai' : 'player'; }
  function addLog(state, text) {
    state.log.unshift({ id: uid('log'), round: state.round, text });
    state.log = state.log.slice(0, 35);
  }

  function checkWinner(state) {
    for (const id of ['player', 'ai']) {
      if (state.players[id].deck.length === 0) {
        state.status = 'finished';
        state.result = id === 'player' ? 'ai' : 'player';
        addLog(state, `${state.players[id].name}의 서고가 소진되었습니다. ${state.players[state.result].name} 승리!`);
        return true;
      }
    }
    return false;
  }

  function drawToSix(state, id) {
    const p = player(state, id);
    while (p.hand.length < 6 && p.deck.length > 0) {
      p.hand.push(p.deck.shift());
    }
    if (p.hand.length < 6 && p.deck.length === 0) checkWinner(state);
    return p.hand.length;
  }

  function beginPhase(state, id) {
    if (state.status !== 'playing') return;
    state.activeId = id;
    const p = player(state, id);
    p.playedLand = false;
    p.lands.forEach(land => { land.ready = true; });
    p.soulSpent = 0;
    p.units.forEach(unit => {
      unit.canAttack = true;
      unit.tempAP = 0;
      unit.tempDP = 0;
      unit.tempHP = 0;
      unit.hp = Math.min(unit.hp, unit.maxHp + (unit.itemHP || 0));
    });
    drawToSix(state, id);
    if (state.status !== 'finished') {
      addLog(state, `${p.name}의 ${id === state.attackerId ? '공격' : '방어'} 준비 단계입니다. 소울을 재충전하고 패를 보충했습니다.`);
    }
  }

  function readyLandSoul(land, requirements) {
    const choices = land.souls || [land.faction || 'neutral'];
    const unmet = requirements.find(([color, count]) => color !== 'neutral' && count > 0 && choices.includes(color));
    return unmet ? unmet[0] : choices[0] || 'neutral';
  }

  function canPay(p, cost) {
    const req = Object.entries(cost || {}).filter(([color, n]) => color !== 'neutral' && n > 0);
    const generic = Number((cost || {}).neutral || 0);
    let available = p.lands.filter(l => l.ready);
    let need = 0;
    for (const [, n] of req) need += n;
    if (available.length < need + generic) return false;
    const used = new Set();
    for (const [color, count] of req) {
      for (let i = 0; i < count; i++) {
        const idx = available.findIndex((land, j) => !used.has(j) && (land.souls || [land.faction]).includes(color));
        if (idx < 0) return false;
        used.add(idx);
      }
    }
    return available.length - used.size >= generic;
  }

  function spendSoul(p, cost) {
    if (!canPay(p, cost)) return false;
    const req = Object.entries(cost || {}).filter(([color, n]) => color !== 'neutral' && n > 0);
    const generic = Number((cost || {}).neutral || 0);
    let available = p.lands.filter(l => l.ready);
    const used = new Set();
    for (const [color, count] of req) {
      for (let i = 0; i < count; i++) {
        const idx = available.findIndex((land, j) => !used.has(j) && (land.souls || [land.faction]).includes(color));
        used.add(idx);
      }
    }
    let left = generic;
    for (let i = 0; i < available.length && left > 0; i++) {
      if (!used.has(i)) { used.add(i); left--; }
    }
    used.forEach(i => { available[i].ready = false; });
    p.soulSpent += used.size;
    return true;
  }

  function totalPower(unit, stat) {
    const base = stat === 'ap' ? unit.ap : stat === 'dp' ? unit.dp : unit.maxHp;
    const item = stat === 'ap' ? (unit.itemAP || 0) : stat === 'dp' ? (unit.itemDP || 0) : (unit.itemHP || 0);
    const temp = stat === 'ap' ? (unit.tempAP || 0) : stat === 'dp' ? (unit.tempDP || 0) : (unit.tempHP || 0);
    return base + item + temp;
  }

  function createUnit(card) {
    return {
      ...clone(card), instanceId: card.instanceId || uid('unit'),
      hp: card.hp, maxHp: card.hp,
      itemAP: 0, itemDP: 0, itemHP: 0,
      tempAP: 0, tempDP: 0, tempHP: 0,
      equipment: [], canAttack: true
    };
  }

  function findCard(p, instanceId) {
    return p.hand.find(c => c.instanceId === instanceId);
  }
  function removeHand(p, instanceId) {
    const idx = p.hand.findIndex(c => c.instanceId === instanceId);
    return idx < 0 ? null : p.hand.splice(idx, 1)[0];
  }

  function playCard(state, ownerId, instanceId, targetId) {
    if (state.status !== 'playing' || state.activeId !== ownerId) return { ok: false, reason: '현재 준비 단계가 아닙니다.' };
    const p = player(state, ownerId);
    const card = findCard(p, instanceId);
    if (!card) return { ok: false, reason: '선택한 카드가 패에 없습니다.' };
    if (card.type === 'land') {
      if (p.playedLand) return { ok: false, reason: '이번 준비 단계에 지형을 이미 설치했습니다.' };
      if (p.lands.length >= 10) return { ok: false, reason: '지형은 최대 10장까지 설치할 수 있습니다.' };
      const land = removeHand(p, instanceId);
      land.ready = true;
      p.lands.push(land);
      p.playedLand = true;
      addLog(state, `${p.name}이(가) 지형 ${card.name}을(를) 설치했습니다.`);
      return { ok: true };
    }
    if (!canPay(p, card.cost)) return { ok: false, reason: `소울이 부족합니다. 필요: ${costText(card.cost)}` };
    if (card.type === 'unit') {
      spendSoul(p, card.cost);
      removeHand(p, instanceId);
      p.units.push(createUnit(card));
      addLog(state, `${p.name}이(가) ${card.name}을(를) 소환했습니다.`);
      return { ok: true };
    }
    if (card.type === 'item' || card.type === 'enchant') {
      const target = p.units.find(u => u.instanceId === targetId) || p.units[0];
      if (!target) return { ok: false, reason: '장착할 아군 유닛이 없습니다.' };
      spendSoul(p, card.cost);
      removeHand(p, instanceId);
      target.equipment.push(card.name);
      target.itemAP += card.apBonus || 0;
      target.itemDP += card.dpBonus || 0;
      target.itemHP += card.hpBonus || 0;
      target.hp += card.hpBonus || 0;
      if (card.effect && card.effect.type === 'aura') target.aura = clone(card.effect);
      addLog(state, `${p.name}이(가) ${target.name}에게 ${card.name}을(를) 장착했습니다.`);
      return { ok: true };
    }
    if (card.type === 'spell') {
      const other = player(state, opponentId(ownerId));
      const effect = card.effect || {};
      const target = (effect.target === 'ownUnit' ? p.units : other.units).find(u => u.instanceId === targetId)
        || (effect.target === 'ownUnit' ? p.units[0] : other.units[0]);
      if ((effect.target === 'ownUnit' || effect.target === 'enemyUnit') && !target) {
        return { ok: false, reason: '효과를 적용할 대상 유닛이 없습니다.' };
      }
      spendSoul(p, card.cost);
      removeHand(p, instanceId);
      applyEffect(state, ownerId, effect, target);
      p.graveyard.push(card);
      addLog(state, `${p.name}이(가) 마법 ${card.name}을(를) 발동했습니다.`);
      checkWinner(state);
      return { ok: true };
    }
    return { ok: false, reason: '지원하지 않는 카드 종류입니다.' };
  }

  function applyEffect(state, ownerId, effect, target) {
    const owner = player(state, ownerId);
    const enemy = player(state, opponentId(ownerId));
    const amount = Number(effect.amount || 0);
    if (effect.type === 'damage' && target) {
      const targetOwner = effect.target === 'ownUnit' ? owner : enemy;
      target.hp -= amount;
      if (target.hp <= 0) destroyUnit(state, targetOwner, target);
    } else if (effect.type === 'buff' && target) {
      target.tempAP += Number(effect.ap || 0);
      target.tempDP += Number(effect.dp || 0);
      target.tempHP += Number(effect.hp || 0);
      target.hp += Number(effect.hp || 0);
    } else if (effect.type === 'heal' && target) {
      target.hp = Math.min(target.maxHp + (target.itemHP || 0), target.hp + amount);
    } else if (effect.type === 'draw') {
      const count = Math.max(0, Math.min(3, amount || 1));
      for (let i = 0; i < count && owner.deck.length && owner.hand.length < 6; i++) owner.hand.push(owner.deck.shift());
      checkWinner(state);
    } else if (effect.type === 'mill') {
      enemy.deck.splice(0, Math.min(amount, enemy.deck.length));
      checkWinner(state);
    } else if (effect.type === 'drain' && target) {
      const targetOwner = effect.target === 'ownUnit' ? owner : enemy;
      target.hp -= amount;
      if (target.hp <= 0) destroyUnit(state, targetOwner, target);
      const wounded = owner.units.slice().sort((a, b) => a.hp - b.hp)[0];
      if (wounded) wounded.hp = Math.min(wounded.maxHp + (wounded.itemHP || 0), wounded.hp + amount);
    }
  }

  function destroyUnit(state, owner, unit) {
    const idx = owner.units.findIndex(u => u.instanceId === unit.instanceId);
    if (idx >= 0) {
      const [gone] = owner.units.splice(idx, 1);
      owner.graveyard.push(gone);
      addLog(state, `${owner.name}의 ${gone.name}이(가) 파괴되었습니다.`);
    }
  }

  function flip(rng) { return rng() < 0.5 ? 0 : 1; }
  function rollStat(unit, stat, rng) {
    const coin = unit.coin || {};
    const count = Math.max(0, Number(coin[stat + 'Count'] || 0));
    const value = Number(coin[stat + 'Value'] || 0);
    let heads = 0;
    for (let i = 0; i < count; i++) heads += flip(rng);
    const base = totalPower(unit, stat);
    return { value: Math.max(0, base + heads * value), heads, count };
  }

  function chooseBlocker(attacker, defenders, rng) {
    if (!defenders.length) return null;
    const attackEstimate = totalPower(attacker, 'ap') + (attacker.coin?.apCount || 0) * (attacker.coin?.apValue || 0) * 0.5;
    let best = defenders[0], bestScore = Infinity;
    for (const defender of defenders) {
      const defenseEstimate = totalPower(defender, 'dp') + (defender.coin?.dpCount || 0) * (defender.coin?.dpValue || 0) * 0.5;
      const expectedDamage = Math.max(0, attackEstimate - defenseEstimate);
      const killPenalty = expectedDamage >= defender.hp ? -100 : 0;
      const score = Math.abs(defender.hp - expectedDamage) + killPenalty + (totalPower(defender, 'ap') * 0.1);
      if (score < bestScore) { best = defender; bestScore = score; }
    }
    return best;
  }

  function resolveBattle(state) {
    if (state.status !== 'playing') return;
    const attacker = player(state, state.attackerId);
    const defender = player(state, opponentId(state.attackerId));
    addLog(state, `제 ${state.round} 라운드 전투가 시작됩니다.`);
    const attackList = attacker.units.slice();
    for (const attackingUnit of attackList) {
      if (!attacker.units.some(u => u.instanceId === attackingUnit.instanceId)) continue;
      const blocker = chooseBlocker(attackingUnit, defender.units, state.rng || Math.random);
      const attackRoll = rollStat(attackingUnit, 'ap', state.rng || Math.random);
      if (blocker) {
        const defenseRoll = rollStat(blocker, 'dp', state.rng || Math.random);
        const damage = Math.max(0, attackRoll.value - defenseRoll.value);
        blocker.hp -= damage;
        addLog(state, `${attackingUnit.name} 공격 ${attackRoll.value} (${attackRoll.heads}/${attackRoll.count}) → ${blocker.name} 방어 ${defenseRoll.value}, 피해 ${damage}.`);
        if (blocker.hp <= 0) destroyUnit(state, defender, blocker);
      } else {
        const damage = Math.max(1, attackRoll.value);
        const removed = Math.min(damage, defender.deck.length);
        defender.deck.splice(0, removed);
        addLog(state, `${attackingUnit.name}의 직접 공격! 상대 서고 카드 ${removed}장 소각.`);
        if (checkWinner(state)) break;
      }
      attackingUnit.canAttack = false;
    }
    for (const id of ['player', 'ai']) {
      const p = player(state, id);
      p.units.forEach(u => {
        u.hp = u.maxHp + (u.itemHP || 0);
        u.tempAP = 0; u.tempDP = 0; u.tempHP = 0;
        u.canAttack = true;
      });
    }
    if (state.status === 'finished') return;
    state.round += 1;
    state.attackerId = opponentId(state.attackerId);
    state.prepared = { player: false, ai: false };
    beginPhase(state, state.attackerId);
  }

  function endPhase(state, ownerId) {
    if (state.status !== 'playing' || state.activeId !== ownerId) return { ok: false, reason: '현재 준비 단계가 아닙니다.' };
    state.prepared[ownerId] = true;
    const nextId = opponentId(ownerId);
    if (!state.prepared[nextId]) {
      addLog(state, `${player(state, ownerId).name}이(가) 준비를 마쳤습니다.`);
      beginPhase(state, nextId);
      if (player(state, nextId).isAI) runAIPhase(state, nextId);
    } else {
      resolveBattle(state);
      if (state.status === 'playing' && player(state, state.activeId).isAI) runAIPhase(state, state.activeId);
    }
    return { ok: true };
  }

  function bestSpellTarget(state, ownerId, card) {
    const effect = card.effect || {};
    const targetOwner = effect.target === 'ownUnit' ? player(state, ownerId) : player(state, opponentId(ownerId));
    if (!targetOwner.units.length) return null;
    if (effect.target === 'ownUnit') return targetOwner.units.slice().sort((a, b) => totalPower(b, 'ap') - totalPower(a, 'ap'))[0];
    return targetOwner.units.slice().sort((a, b) => a.hp - b.hp)[0];
  }

  function runAIPhase(state, ownerId) {
    const ai = player(state, ownerId);
    if (!ai || !ai.isAI || state.activeId !== ownerId || state.status !== 'playing') return;
    addLog(state, `${ai.name}이(가) 카드를 검토하고 있습니다.`);
    const land = ai.hand.find(c => c.type === 'land');
    if (land) playCard(state, ownerId, land.instanceId);

    const maxActions = state.settings.difficulty === 'easy' ? 2 : state.settings.difficulty === 'hard' ? 8 : 5;
    let actions = 0;
    let progressed = true;
    while (progressed && actions < maxActions && state.status === 'playing') {
      progressed = false;
      actions++;
      const candidates = ai.hand.filter(c => c.type !== 'land' && canPay(ai, c.cost));
      const unitCandidates = candidates.filter(c => c.type === 'unit');
      const unitCard = unitCandidates.sort((a, b) => {
        if (state.settings.difficulty === 'hard') {
          const scoreA = (a.ap + a.dp + a.hp) / Math.max(1, sumCost(a.cost));
          const scoreB = (b.ap + b.dp + b.hp) / Math.max(1, sumCost(b.cost));
          return scoreB - scoreA;
        }
        return (sumCost(a.cost) - sumCost(b.cost)) || (b.ap + b.hp - a.ap - a.hp);
      })[0];
      if (unitCard) {
        playCard(state, ownerId, unitCard.instanceId);
        progressed = true;
        continue;
      }
      const spellCard = candidates.filter(c => c.type === 'spell').map(c => ({ card: c, target: bestSpellTarget(state, ownerId, c) }))
        .filter(x => !['enemyUnit', 'ownUnit'].includes(x.card.effect?.target) || x.target)
        .sort((a, b) => Number(b.card.effect?.amount || 0) - Number(a.card.effect?.amount || 0))[0];
      if (spellCard) {
        playCard(state, ownerId, spellCard.card.instanceId, spellCard.target?.instanceId);
        progressed = true;
        continue;
      }
      const equip = candidates.filter(c => c.type === 'item' || c.type === 'enchant').sort((a, b) => ((b.apBonus || 0) + (b.dpBonus || 0) + (b.hpBonus || 0)) - ((a.apBonus || 0) + (a.dpBonus || 0) + (a.hpBonus || 0)))[0];
      if (equip && ai.units.length) {
        const target = ai.units.slice().sort((a, b) => totalPower(b, 'ap') - totalPower(a, 'ap'))[0];
        playCard(state, ownerId, equip.instanceId, target.instanceId);
        progressed = true;
      }
    }
    if (state.status === 'playing' && state.activeId === ownerId) endPhase(state, ownerId);
  }

  function cardArtClass(card) {
    const f = card.faction || 'neutral';
    return `art-${f}`;
  }

  const api = {
    COLORS, COLOR_NAMES, TYPE_NAMES, clone, uid, sumCost, costText, colorName,
    newGame, buildStarterDeck, drawToSix, canPay, spendSoul, totalPower,
    playCard, endPhase, resolveBattle, runAIPhase, checkWinner, cardArtClass,
    _test: { makePlayer, beginPhase, rollStat, chooseBlocker, createUnit, applyEffect }
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.FM = api;
})(typeof window !== 'undefined' ? window : globalThis);
