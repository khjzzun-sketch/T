# Reference material reviewed

This document records the public material used to design the prototype rules model. These sources do not constitute official game specifications, and different editions/patch eras may have different rules.

1. Gamechosun, **판타지 마스터즈**, 2002-09-14. Describes Soul Cast, attack/defense preparation, battle, six-card hand limit, deck exhaustion, land deployment, and the broad card classes.  
   https://www.gamechosun.co.kr/webzine/article/view.php?from=articlelist&no=13712
2. GGGame, **판타지 마스터즈 - 초보자를 위한 매뉴얼**, 2006-04-02. Describes AP/DP/HP, land/soul, colored and neutral soul, coin flips, and deck/life modes.  
   https://www.ggemguide.com/guides/online/964/?dpage=129
3. Fantasy Masters overview (community-maintained wiki mirror). Describes seven original attributes and the later neutral attribute, five card types, up to ten lands, unit AP/DP/HP, equipment, spells, enchants, and card archive categories.  
   https://www.namu.moe/w/%ED%8C%90%ED%83%80%EC%A7%80%20%EB%A7%88%EC%8A%A4%ED%84%B0%EC%A6%88
4. FAN-MADE MASTERS. Reference destination for community-reconstructed card sets and gameplay concepts. The website is JavaScript-driven and the current web retrieval did not provide a complete structured card export.  
   https://fanma.kr/
5. FM LUNATIC. Community card archive reference. The current public page is a JavaScript application; the current retrieval did not expose its full database or a clear reuse license.  
   https://fmlunatic.com/

## Current engine assumptions (must be confirmed before calling this a faithful restoration)

- Deck size in the prototype: 30 cards, solely a test default.
- Hand refill: draw until six at the beginning of the player's preparation phase.
- Land rule: one land per preparation phase, up to ten on the field.
- Soul rule: a land produces one selectable soul per preparation phase; dual lands can satisfy one of their listed colors.
- Battle: each attacking unit is processed against a selected/automatic blocker; AP minus DP is applied to the blocking unit's HP. Survivors recover to their maximum HP after battle. With no blocker, attack power removes cards from the defender's deck.
- Coin rule: each coin is represented as a 50% success event; successes multiply the card's configured coin value and are added to base AP/DP.
- AI: heuristic deployment and spell/equipment use. It is not an emulation of the original server AI.

The battle formula and some general structures have public support, but the precise card-level coin values, damage-to-deck details, upkeep, slot sequencing, and patch-dependent exceptions remain unverified. All such implementation assumptions are isolated in the rule engine and are candidates for correction when reliable source captures become available.
