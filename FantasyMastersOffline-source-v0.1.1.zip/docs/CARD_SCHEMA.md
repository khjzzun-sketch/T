# Card JSON schema (prototype)

The import screen accepts a JSON array. Supported values:

```json
[
  {
    "id": "sample_forest_scout",
    "name": "숲의 척후병",
    "type": "unit",
    "faction": "forest",
    "cost": { "forest": 1 },
    "ap": 2,
    "dp": 1,
    "hp": 3,
    "coin": {
      "apCount": 1,
      "apValue": 1,
      "dpCount": 0,
      "dpValue": 0
    },
    "rarity": "common",
    "text": "검증된 카드 설명을 입력"
  }
]
```

## Required common fields

- `id`: unique stable ID, 2–64 characters, ASCII letters/numbers/underscore/hyphen.
- `name`: card display name.
- `type`: `land`, `unit`, `item`, `spell`, or `enchant`.
- `faction`: `dark`, `fire`, `water`, `forest`, `metal`, `earth`, `light`, or `neutral`.

## Type-specific fields

- Land: `souls` array, each entry one of the eight factions. Current rules treat each land as one available soul per preparation phase and dual lands as able to satisfy one of their listed colors.
- Non-land: `cost` object, with non-negative integer values keyed by faction. `neutral` is currently treated as generic cost.
- Unit: integer `ap`, `dp`, `hp`; optional `coin` fields `apCount`, `apValue`, `dpCount`, `dpValue`.
- Item/Enchant: optional integer `apBonus`, `dpBonus`, `hpBonus`.
- Spell: `effect` object. Currently supported `damage`, `heal`, `buff`, `draw`, `mill` (drain not fully implemented). Targets: `ownUnit`, `enemyUnit`.

## Important

This is an implementation schema, **not a confirmed export schema from the original game or FAN-MADE MASTERS**. Translate source data into it only after checking the original card behavior. Special effects require a new explicit effect handler and test before they should be considered implemented.
