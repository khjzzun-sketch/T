# v0.1.1 — GitHub Actions path fix

## Root cause addressed
The workflow executed `node --test tests/rules.test.cjs`, but GitHub's checkout did not contain that exact path. The test file is included at the project root in this archive. This mismatch can occur when the `tests/` directory was not uploaded or when the project was uploaded inside an extra directory.

## Changes
- Keep `tests/rules.test.cjs` at the project root.
- Make Actions discover the project root from `tests/rules.test.cjs` instead of assuming the repository root.
- Validate required Gradle and game-engine files before testing/building.
- Print a repository file inventory and an explicit diagnostic when the test file is missing.
- Run the workflow on every push to `main` or `master`, avoiding path filters that can miss test-only changes.
- Add JavaScript syntax checks before Android build.
- Update Android version to 0.1.1 / versionCode 2.

## Verification
- `node --test tests/rules.test.cjs`: 10/10 passed locally.
- JavaScript syntax checks: passed locally.
- Android APK build: not run in this environment because Android SDK/Gradle are unavailable.
