# 소리노트 v0.7.0 수정 분석

## 2026-10-29 GitHub 빌드 실패 원인

제공된 GitHub Actions 로그에서 확인된 첫 Kotlin 컴파일 오류는 다음과 같습니다.

```text
MainActivity.kt:124:48 Unresolved reference 'LayoutParams'
```

실패 지점은 `ScrollView.LayoutParams(-1, -2)`였습니다. `ScrollView`는 `FrameLayout` 계열이며 해당 소스의 `ScrollView.LayoutParams` 참조는 Kotlin에서 유효하지 않습니다. 이 인자를 `ViewGroup.LayoutParams(-1, -2)`로 변경했습니다. 실제 컴파일 성공 여부는 수정 후 GitHub Actions 재실행을 통해 확인해야 합니다.

## 고정 GitHub Actions 워크플로

이전 워크플로는 `SoriNote_Free_Whisper_GitHub_ZIP_Only_v0.6.0.zip`, `versionCode = 5`, `versionName = 0.6.0-free-whisper-live`, 특정 모델 SHA-1에 고정되어 있어 다음 ZIP에서 변경이 발생하면 workflow도 같이 바꿔야 했습니다.

새 `SoriNote_android-build.yml`은 다음 방식입니다.

- `.zip` 업로드를 트리거로 실행하며, 파일명과 앱 버전은 고정하지 않습니다.
- 업로드된 ZIP의 무결성을 검사하고 내부에서 `settings.gradle(.kts)`, `app/build.gradle(.kts)`, Android manifest가 함께 있는 프로젝트 루트를 찾습니다.
- 한 커밋에서 수정된 유효 프로젝트 ZIP이 하나면 그것을 사용하고, 수동 실행 시에는 저장소 루트의 가장 최근 변경 유효 프로젝트 ZIP을 선택합니다.
- 프로젝트를 작업 폴더로 복사하지만 저장소의 `.github/workflows`를 덮어쓰지 않습니다. 따라서 ZIP 내부 workflow가 현재 고정 workflow를 교체하지 않습니다.
- 실제 `clean assembleRelease` 실행 뒤 생성된 APK를 버전 독립적인 `sorinote-android-release-apk` 아티팩트로 제공합니다.
- 영구 고정 workflow는 최초 한 번만 저장소의 `.github/workflows/android-build.yml`에 넣으면 됩니다. 이후 ZIP 업로드마다 workflow 파일을 교체하지 않습니다.

## 음성 입력·언어·지연 수정

- 언어 선택 추가: 자동 감지 / 한국어 / 영어.
- JNI에서 Whisper 언어를 `auto`로 지정하고, 첫 자동 감지 이후 같은 녹취 세션 동안 검출된 언어 코드를 재사용합니다. 새 녹취 시작 시에는 자동 감지 상태를 초기화합니다.
- 실시간 추론은 최근 최대 4초의 오디오를 처리하고, 약 0.33초 이상의 새 오디오가 들어오면 단일 네이티브 작업을 시작합니다. 첫 추론 임계값은 약 1.1초입니다. 추론 작업을 병렬로 중복 실행하지 않습니다.
- 외부 소리: 기존 AudioRecord 마이크 캡처.
- 내부 소리: Android 10+ `AudioPlaybackCaptureConfiguration`, 사용자 동의 `MediaProjection`, `mediaProjection` 유형의 전경 서비스, `USAGE_MEDIA/GAME/UNKNOWN` 캡처를 구현합니다.

## 내부 오디오의 운영체제 제약

Android는 모든 앱 오디오를 무조건 캡처하도록 허용하지 않습니다. 소스 앱의 capture policy/manifest와 오디오 usage에 따라 캡처가 차단될 수 있으며, 통화 및 보호된 오디오를 포괄적으로 캡처할 수는 없습니다. 구현은 시스템의 명시적 사용자 동의를 요청하고 제한된 AudioPlaybackCapture API를 사용합니다.

공식 문서:
- https://developer.android.com/media/platform/av-capture
- https://developer.android.com/media/grow/media-projection
- https://developer.android.com/reference/android/media/AudioPlaybackCaptureConfiguration
- https://github.com/ggml-org/whisper.cpp/blob/master/examples/stream/README.md

## 검증 경계

- 수정된 컴파일 오류의 소스 변경: 완료
- 고정 workflow / 버전 독립적 ZIP 검색: 구현 및 정적 검사 대상
- Android Kotlin/JNI/C++ 실제 CI 빌드: 이 작업 환경에서는 실행하지 않음
- APK 설치와 Android 10+ 내부 오디오 실제 캡처: 미검증
- 기기별 실시간 지연과 Soniox 대비 정확도: 실측 전 미확정
