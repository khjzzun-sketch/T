# Third-party notices

- `whisper.cpp`: https://github.com/ggml-org/whisper.cpp — MIT License. The build fetches upstream tag `v1.9.5`.
- Whisper model file `ggml-large-v3-turbo-q5_0.bin`: downloaded at first app launch from `https://huggingface.co/ggerganov/whisper.cpp/`; the upstream model page identifies the converted model set as MIT licensed. The application verifies the published SHA-1 before making it available.

No Soniox proprietary source code, model, API key, or service endpoint is included or used by this project. The user-provided Soniox package was treated only as a behavioral benchmark for live transcription UX and not as source code to copy.
