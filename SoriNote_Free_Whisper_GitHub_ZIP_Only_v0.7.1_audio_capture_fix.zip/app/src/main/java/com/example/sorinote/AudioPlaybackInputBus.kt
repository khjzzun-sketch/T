package com.example.sorinote

/** Same-process PCM bridge from the foreground playback-capture service to the active screen. */
object AudioPlaybackInputBus {
    @Volatile var onPcm: ((ShortArray, Int) -> Unit)? = null
    @Volatile var onStatus: ((String) -> Unit)? = null

    fun publish(pcm: ShortArray, count: Int) {
        val listener = onPcm ?: return
        if (count > 0) listener(pcm.copyOf(count), count)
    }

    fun reportStatus(message: String) {
        onStatus?.invoke(message)
    }
}
