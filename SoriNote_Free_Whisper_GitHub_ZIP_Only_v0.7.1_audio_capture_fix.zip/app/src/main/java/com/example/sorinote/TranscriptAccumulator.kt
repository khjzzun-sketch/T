package com.example.sorinote

/**
 * Keeps words that have fallen out of the rolling audio window and a replaceable
 * recent hypothesis. This is a best-effort rolling-window stitcher, not forced alignment.
 */
class TranscriptAccumulator {
    private val committed = ArrayList<String>()
    private var pendingNoOverlap = emptyList<String>()
    private var previousWindow = emptyList<String>()

    @Synchronized
    fun clear() {
        committed.clear()
        pendingNoOverlap = emptyList()
        previousWindow = emptyList()
    }

    @Synchronized
    fun accept(hypothesis: String): String {
        val current = hypothesis.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (current.isEmpty()) return render()
        if (previousWindow.isEmpty()) {
            previousWindow = current
            return render()
        }

        val previousNormalized = previousWindow.map(::normalize)
        val currentNormalized = current.map(::normalize)

        if (containsSequence(currentNormalized, previousNormalized)) {
            // A revised result may preserve the older hypothesis inside the new result.
            // Commit any older disjoint pending window, then replace instead of duplicating.
            if (pendingNoOverlap.isNotEmpty()) committed.addAll(pendingNoOverlap)
            pendingNoOverlap = emptyList()
            previousWindow = current
            trimCommitted()
            return render()
        }

        val overlap = longestSuffixPrefixOverlap(previousWindow, current)
        if (overlap >= 1) {
            // At the rolling-window boundary, everything before the overlapping suffix has
            // aged out. A one-word overlap is accepted to avoid dropping older transcript text.
            if (pendingNoOverlap.isNotEmpty()) committed.addAll(pendingNoOverlap)
            pendingNoOverlap = emptyList()
            committed.addAll(previousWindow.take(previousWindow.size - overlap))
            previousWindow = current
            trimCommitted()
            return render()
        }

        if (sameNormalized(previousWindow, current)) {
            // If two successive hypotheses remain disjoint, the older one has stabilized and
            // can be committed without growing duplicate copies of the active window.
            if (pendingNoOverlap.isNotEmpty()) committed.addAll(pendingNoOverlap)
            pendingNoOverlap = emptyList()
            previousWindow = current
            trimCommitted()
            return render()
        }

        // No lexical overlap: stage the older active window. On the next no-overlap result,
        // commit that staged text and stage the current window. This trades a little delay for
        // fewer dropped words when Whisper revises sentence boundaries.
        if (pendingNoOverlap.isNotEmpty()) committed.addAll(pendingNoOverlap)
        pendingNoOverlap = previousWindow
        previousWindow = current
        trimCommitted()
        return render()
    }

    @Synchronized
    fun finish(): String {
        if (pendingNoOverlap.isNotEmpty()) committed.addAll(pendingNoOverlap)
        committed.addAll(previousWindow)
        pendingNoOverlap = emptyList()
        previousWindow = emptyList()
        trimCommitted()
        return render()
    }

    @Synchronized
    fun text(): String = render()

    private fun render(): String = (committed + pendingNoOverlap + previousWindow).joinToString(" ").trim()

    private fun trimCommitted() {
        // Bound pathological no-input/noise sessions without imposing a practical transcript cap.
        if (committed.size > 250_000) committed.subList(0, committed.size - 250_000).clear()
    }

    private fun sameNormalized(a: List<String>, b: List<String>): Boolean =
        a.size == b.size && a.indices.all { normalize(a[it]) == normalize(b[it]) }

    private fun normalize(value: String): String = value
        .lowercase()
        .replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun containsSequence(haystack: List<String>, needle: List<String>): Boolean {
        if (needle.isEmpty() || needle.size > haystack.size) return false
        for (start in 0..(haystack.size - needle.size)) {
            var matches = true
            for (i in needle.indices) {
                if (haystack[start + i] != needle[i]) { matches = false; break }
            }
            if (matches) return true
        }
        return false
    }

    private fun longestSuffixPrefixOverlap(previous: List<String>, current: List<String>): Int {
        val limit = minOf(previous.size, current.size)
        for (length in limit downTo 1) {
            var equal = true
            for (i in 0 until length) {
                if (normalize(previous[previous.size - length + i]) != normalize(current[i])) {
                    equal = false
                    break
                }
            }
            if (equal) return length
        }
        return 0
    }
}
