package com.example.sorinote

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val accumulator = TranscriptAccumulator()

    private lateinit var statusView: TextView
    private lateinit var modelButton: Button
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var copyButton: Button
    private lateinit var clearButton: Button
    private lateinit var languageSpinner: Spinner
    private lateinit var sourceSpinner: Spinner
    private lateinit var transcriptView: TextView
    private lateinit var scrollView: ScrollView

    @Volatile private var recording = false
    @Volatile private var finalizing = false
    @Volatile private var modelLoaded = false
    @Volatile private var loadingModel = false
    @Volatile private var destroyed = false
    @Volatile private var playbackCapture = false
    @Volatile private var sessionEndStatus: String? = null
    private var recorder: AudioRecord? = null
    private var captureThread: Thread? = null
    private val audioLock = Any()
    private val sampleRate = 16_000
    private val ringCapacity = sampleRate * 8
    private val audioRing = FloatArray(ringCapacity)
    private var ringWriteIndex = 0
    private var totalSamplesWritten = 0L
    private var sessionLanguage = "auto"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        if (ModelManager.isReady(this)) {
            modelButton.visibility = View.GONE
            loadModel()
        } else {
            updateStatus("최초 1회 모델 다운로드가 필요합니다. Wi-Fi 사용을 권장합니다.")
            updateButtons()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val title = TextView(this).apply {
            text = "소리노트"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF161616.toInt())
        }
        statusView = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF505050.toInt())
            setPadding(0, dp(8), 0, dp(12))
        }
        modelButton = Button(this).apply {
            text = "다국어 전사 모델 다운로드 (${ModelManager.MODEL_SIZE_LABEL})"
            setOnClickListener { downloadModel() }
        }
        languageSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("언어 자동 감지", "한국어", "English")
            ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            setSelection(0)
        }
        sourceSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                listOf("외부 소리 · 마이크", "내부 소리 · 앱 재생음")
            ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            setSelection(0)
        }
        startButton = Button(this).apply {
            text = "실시간 전사 시작"
            setOnClickListener { requestMicAndStart() }
        }
        stopButton = Button(this).apply {
            text = "전사 종료"
            isEnabled = false
            setOnClickListener { stopRecording() }
        }
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(startButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
            addView(stopButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        }
        val settingsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(languageSpinner, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
            addView(sourceSpinner, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        }
        val transcriptHeader = TextView(this).apply {
            text = "전사 내용"
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF222222.toInt())
            setPadding(0, dp(14), 0, dp(6))
        }
        transcriptView = TextView(this).apply {
            text = "마이크를 켜면 전사 결과가 여기에 표시됩니다."
            textSize = 18f
            setTextColor(0xFF171717.toInt())
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(0xFFF5F6F8.toInt())
            gravity = Gravity.TOP or Gravity.START
        }
        scrollView = ScrollView(this).apply {
            isFillViewport = true
            // ScrollView uses FrameLayout.LayoutParams; ViewGroup.LayoutParams is portable here.
            addView(transcriptView, ViewGroup.LayoutParams(-1, -2))
        }
        val transcriptParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) }
        val utilityRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(copyButton().also { copyButton = it }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
            addView(clearButton().also { clearButton = it }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        }

        root.addView(title)
        root.addView(statusView)
        root.addView(modelButton, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(settingsRow, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(actionRow, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(4) })
        root.addView(transcriptHeader)
        root.addView(scrollView, transcriptParams)
        root.addView(utilityRow, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(6) })
        setContentView(root)
        updateButtons()
    }

    private fun copyButton(): Button = Button(this).apply {
        text = "전사 복사"
        setOnClickListener {
            val text = accumulator.text()
            if (text.isBlank()) {
                toast("복사할 전사 내용이 없습니다.")
                return@setOnClickListener
            }
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("소리노트 전사", text))
            toast("전사 내용을 복사했습니다.")
        }
    }

    private fun clearButton(): Button = Button(this).apply {
        text = "내용 지우기"
        setOnClickListener {
            if (recording) {
                toast("전사를 종료한 뒤 지워 주세요.")
                return@setOnClickListener
            }
            accumulator.clear()
            transcriptView.text = "마이크를 켜면 전사 결과가 여기에 표시됩니다."
        }
    }

    private fun downloadModel() {
        if (loadingModel || recording || finalizing) return
        loadingModel = true
        modelButton.isEnabled = false
        updateStatus("전사 모델 다운로드 중… (${ModelManager.MODEL_SIZE_LABEL})")
        updateButtons()
        worker.submit {
            try {
                ModelManager.download(applicationContext) { downloaded, total ->
                    val text = if (total > 0L) {
                        val percent = (downloaded * 100L / total).coerceIn(0L, 100L)
                        "모델 다운로드 중… $percent% (${formatMiB(downloaded)} / ${formatMiB(total)})"
                    } else {
                        "모델 다운로드 중… ${formatMiB(downloaded)}"
                    }
                    mainHandler.post { updateStatus(text) }
                }
                mainHandler.post {
                    if (destroyed) return@post
                    loadingModel = false
                    modelButton.visibility = View.GONE
                    updateStatus("모델 다운로드 완료. 기기 내 모델을 준비하고 있습니다…")
                    loadModel()
                }
            } catch (error: Exception) {
                mainHandler.post {
                    if (destroyed) return@post
                    loadingModel = false
                    modelButton.isEnabled = true
                    updateStatus("모델 다운로드 실패: ${error.message ?: "네트워크 또는 저장 공간을 확인해 주세요."}")
                    updateButtons()
                }
            }
        }
    }

    private fun loadModel() {
        if (loadingModel || modelLoaded) return
        loadingModel = true
        updateStatus("기기 내 음성 인식 모델을 불러오는 중…")
        updateButtons()
        worker.submit {
            val loaded = try {
                WhisperNative.loadModel(ModelManager.modelFile(applicationContext).absolutePath)
            } catch (_: Throwable) {
                false
            }
            mainHandler.post {
                if (destroyed) return@post
                loadingModel = false
                modelLoaded = loaded
                if (loaded) {
                    updateStatus("준비 완료 · 인터넷/API 요금 없이 기기에서 전사합니다.")
                    modelButton.visibility = View.GONE
                } else {
                    updateStatus("모델을 불러오지 못했습니다. 모델을 다시 다운로드해 주세요.")
                    modelButton.visibility = View.VISIBLE
                    modelButton.isEnabled = true
                }
                updateButtons()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun requestMicAndStart() {
        if (!modelLoaded) {
            toast("먼저 전사 모델을 준비해 주세요.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        if (sourceSpinner.selectedItemPosition == SOURCE_INTERNAL_AUDIO) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                toast("내부 앱 소리 캡처는 Android 10 이상에서 지원됩니다. 외부 소리/마이크를 선택해 주세요.")
                sourceSpinner.setSelection(SOURCE_MIC)
                return
            }
            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION)
        } else {
            startMicrophoneRecording()
        }
    }

    @Suppress("MissingSuperCall")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (destroyed) return
        if (requestCode == REQUEST_MIC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) requestMicAndStart()
            else toast("실시간 전사를 위해 마이크 권한이 필요합니다.")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (destroyed || requestCode != REQUEST_MEDIA_PROJECTION) return
        if (resultCode == RESULT_OK && data != null) {
            startInternalAudioRecording(resultCode, data)
        } else {
            updateStatus("내부 소리 캡처가 취소되었습니다. 외부 소리 또는 내부 소리를 선택한 뒤 다시 시작해 주세요.")
        }
    }

    private fun resetSessionAudio() {
        synchronized(audioLock) {
            ringWriteIndex = 0
            totalSamplesWritten = 0L
        }
        accumulator.clear()
        transcriptView.text = "음성을 기다리는 중…"
        sessionLanguage = when (languageSpinner.selectedItemPosition) {
            1 -> "ko"
            2 -> "en"
            else -> "auto"
        }
    }

    private fun beginInferenceSession(status: String) {
        // For automatic mode, detect language once per session and reuse it to avoid repeating
        // the language-detection pass on every rolling audio window.
        try { WhisperNative.resetLanguageDetection() } catch (_: Throwable) {}
        sessionEndStatus = null
        finalizing = false
        recording = true
        updateStatus(status)
        updateButtons()
        worker.submit { inferenceLoop() }
    }

    private fun startMicrophoneRecording() {
        if (recording || finalizing || !modelLoaded) return
        val minimumBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minimumBuffer <= 0) {
            updateStatus("이 기기에서 오디오 입력을 초기화할 수 없습니다.")
            return
        }
        val bufferSize = max(minimumBuffer * 2, sampleRate * 2)
        val newRecorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (error: Exception) {
            updateStatus("마이크 초기화 실패: ${error.message ?: "오디오 장치를 확인해 주세요."}")
            return
        }
        if (newRecorder.state != AudioRecord.STATE_INITIALIZED) {
            newRecorder.release()
            updateStatus("마이크를 초기화할 수 없습니다.")
            return
        }

        resetSessionAudio()
        recorder = newRecorder
        try {
            newRecorder.startRecording()
        } catch (error: Exception) {
            recorder = null
            newRecorder.release()
            updateStatus("녹음을 시작하지 못했습니다: ${error.message ?: "마이크를 확인해 주세요."}")
            return
        }
        playbackCapture = false
        beginInferenceSession("실시간 전사 중 · ${languageLabel()} · 외부 소리/마이크 · 기기 내 처리")

        captureThread = Thread({
            val pcm = ShortArray(2048)
            while (recording) {
                val count = try {
                    newRecorder.read(pcm, 0, pcm.size, AudioRecord.READ_BLOCKING)
                } catch (_: Exception) {
                    -1
                }
                if (count > 0 && recording) {
                    appendPcm(pcm, count)
                } else if (count < 0) {
                    mainHandler.post {
                        if (recording) {
                            sessionEndStatus = "오디오 입력이 끊어졌습니다. 전사 결과는 여기까지입니다."
                            updateStatus("오디오 입력이 끊어졌습니다. 전사를 마무리합니다…")
                            stopRecording()
                        }
                    }
                    break
                }
            }
        }, "SoriNote-AudioCapture").apply { start() }
    }

    private fun startInternalAudioRecording(resultCode: Int, resultData: Intent) {
        if (recording || finalizing || !modelLoaded || Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        resetSessionAudio()
        recorder = null
        playbackCapture = true
        AudioPlaybackInputBus.onPcm = { pcm, count ->
            if (recording) appendPcm(pcm, count)
        }
        AudioPlaybackInputBus.onStatus = { message ->
            mainHandler.post {
                if (destroyed) return@post
                if (message.startsWith("ERROR:")) {
                    val detail = message.removePrefix("ERROR:").trim()
                    sessionEndStatus = "내부 소리 캡처 실패: $detail"
                    if (recording) stopRecording()
                    updateStatus(sessionEndStatus ?: "내부 소리 캡처 실패")
                    toast("내부 소리를 캡처하지 못했습니다. 해당 앱이 오디오 캡처를 허용하는지 확인해 주세요.")
                } else {
                    updateStatus(message)
                }
            }
        }

        val serviceIntent = Intent(this, PlaybackCaptureService::class.java).apply {
            putExtra(PlaybackCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(PlaybackCaptureService.EXTRA_RESULT_DATA, resultData)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
        } catch (error: Exception) {
            AudioPlaybackInputBus.onPcm = null
            AudioPlaybackInputBus.onStatus = null
            playbackCapture = false
            updateStatus("내부 오디오 서비스 시작 실패: ${error.message ?: "설정을 확인해 주세요."}")
            return
        }
        beginInferenceSession("내부 앱 소리 캡처 준비 중 · ${languageLabel()} · 기기 내 처리")
    }

    private fun appendPcm(pcm: ShortArray, count: Int) {
        synchronized(audioLock) {
            for (i in 0 until count) {
                audioRing[ringWriteIndex] = pcm[i] / 32768.0f
                ringWriteIndex = (ringWriteIndex + 1) % ringCapacity
                totalSamplesWritten++
            }
        }
    }

    private fun containsAudibleAudio(samples: FloatArray): Boolean {
        if (samples.isEmpty()) return false
        var power = 0.0
        var peak = 0.0f
        for (sample in samples) {
            val magnitude = kotlin.math.abs(sample)
            if (magnitude > peak) peak = magnitude
            power += sample.toDouble() * sample.toDouble()
        }
        // Keep this deliberately sensitive so quiet playback is retained, while pure silence
        // does not trigger expensive decoding or make auto-language selection guess prematurely.
        return power / samples.size >= 0.000004 && peak >= 0.008f
    }

    private fun inferenceLoop() {
        val threads = max(2, min(6, Runtime.getRuntime().availableProcessors() - 1))
        val minimumFirstWindow = (sampleRate * 1.1f).toInt()
        val inferenceWindowSamples = sampleRate * 4
        var lastProcessedSampleCount = 0L
        while (recording) {
            val (samples, sampleCountAtSnapshot) = audioSnapshot(inferenceWindowSamples)
            if (samples.size < minimumFirstWindow || sampleCountAtSnapshot - lastProcessedSampleCount < sampleRate / 3) {
                try { Thread.sleep(70L) } catch (_: InterruptedException) { break }
                continue
            }
            if (!containsAudibleAudio(samples)) {
                lastProcessedSampleCount = sampleCountAtSnapshot
                continue
            }
            val text = try {
                WhisperNative.transcribe(samples, threads, sessionLanguage)
            } catch (error: Throwable) {
                mainHandler.post { updateStatus("전사 중 오류: ${error.message ?: "모델 상태를 확인해 주세요."}") }
                ""
            }
            lastProcessedSampleCount = sampleCountAtSnapshot
            if (text.isNotBlank()) {
                val display = accumulator.accept(text)
                mainHandler.post { renderTranscript(display) }
            }
            // Never queue inference jobs. Each pass processes the latest 4s window and updates
            // immediately when the single native worker becomes available again.
        }

        // Final pass over the most recent audio so that the last spoken phrase is not omitted.
        val finalSamples = audioSnapshot(sampleRate * 4).first
        if (finalSamples.size >= minimumFirstWindow && containsAudibleAudio(finalSamples)) {
            try {
                val finalText = WhisperNative.transcribe(finalSamples, threads, sessionLanguage)
                if (finalText.isNotBlank()) {
                    val display = accumulator.accept(finalText)
                    mainHandler.post { renderTranscript(display) }
                }
            } catch (_: Throwable) {
                // Preserve the transcript already visible if the final pass fails.
            }
        }
        val completed = accumulator.finish()
        val finishedStatus = sessionEndStatus ?: "전사 종료 · 기기 내 처리 완료"
        sessionEndStatus = null
        mainHandler.post {
            if (destroyed) return@post
            finalizing = false
            renderTranscript(completed)
            updateStatus(finishedStatus)
            updateButtons()
        }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        finalizing = true
        if (playbackCapture) {
            AudioPlaybackInputBus.onPcm = null
            AudioPlaybackInputBus.onStatus = null
            try { stopService(Intent(this, PlaybackCaptureService::class.java)) } catch (_: Exception) {}
            playbackCapture = false
        } else {
            try { recorder?.stop() } catch (_: Exception) {}
            try { recorder?.release() } catch (_: Exception) {}
            recorder = null
            captureThread?.interrupt()
            captureThread = null
        }
        updateStatus("전사를 마무리하고 있습니다…")
        updateButtons()
    }

    private fun audioSnapshot(maxSamples: Int): Pair<FloatArray, Long> = synchronized(audioLock) {
        val length = min(min(totalSamplesWritten, ringCapacity.toLong()).toInt(), maxSamples)
        val snapshot = FloatArray(length)
        val start = (ringWriteIndex - length + ringCapacity) % ringCapacity
        for (i in 0 until length) snapshot[i] = audioRing[(start + i) % ringCapacity]
        snapshot to totalSamplesWritten
    }

    private fun renderTranscript(text: String) {
        if (destroyed || !::transcriptView.isInitialized) return
        transcriptView.text = if (text.isBlank()) "음성을 듣고 있습니다…" else text
        copyButton.isEnabled = text.isNotBlank()
        scrollView.post { if (!destroyed) scrollView.fullScroll(View.FOCUS_DOWN) }
    }

    private fun updateStatus(text: String) {
        if (destroyed || !::statusView.isInitialized) return
        statusView.text = text
    }

    private fun updateButtons() {
        if (destroyed || !::statusView.isInitialized) return
        val modelExists = ModelManager.isReady(this)
        if (!modelExists && !loadingModel) modelButton.visibility = View.VISIBLE
        if (loadingModel && !modelExists) modelButton.visibility = View.VISIBLE
        modelButton.isEnabled = !loadingModel && !recording && !finalizing && !modelLoaded
        startButton.isEnabled = modelLoaded && !loadingModel && !recording && !finalizing
        stopButton.isEnabled = recording
        languageSpinner.isEnabled = !recording && !finalizing && !loadingModel
        sourceSpinner.isEnabled = !recording && !finalizing && !loadingModel
        copyButton.isEnabled = !accumulator.text().isBlank()
        clearButton.isEnabled = !recording && !finalizing
    }

    private fun languageLabel(): String = when (languageSpinner.selectedItemPosition) {
        1 -> "한국어"
        2 -> "English"
        else -> "언어 자동 감지"
    }

    private fun formatMiB(value: Long): String = String.format(java.util.Locale.US, "%.0f MiB", value / (1024.0 * 1024.0))
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun toast(text: String) {
        if (!destroyed && !isFinishing) Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (recording) {
            stopRecording()
            toast("전사를 마무리 중입니다.")
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (recording) stopRecording()
        AudioPlaybackInputBus.onPcm = null
        AudioPlaybackInputBus.onStatus = null
        try { stopService(Intent(this, PlaybackCaptureService::class.java)) } catch (_: Exception) {}
        destroyed = true
        worker.submit {
            try { WhisperNative.releaseModel() } catch (_: Throwable) {}
        }
        worker.shutdown()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_MIC = 3107
        private const val REQUEST_MEDIA_PROJECTION = 3108
        private const val SOURCE_MIC = 0
        private const val SOURCE_INTERNAL_AUDIO = 1
    }
}
