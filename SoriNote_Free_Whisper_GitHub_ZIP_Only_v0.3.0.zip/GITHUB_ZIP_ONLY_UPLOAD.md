# GitHub ZIP-only upload guide — SoriNote v0.4.0

## Package structure

This is the complete SoriNote Free Android source project in a flat ZIP layout. The archive root directly contains `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/workflows/build.yml`. There is no extra top-level project folder.

The downloadable archive keeps the exact prior repository ZIP filename so it can replace that archive instead of adding a second root-level ZIP. The **application source version inside the archive is v0.4.0**; the outer filename is retained only for repository compatibility.

## Uploading one ZIP file

GitHub stores an uploaded `.zip` as a single archive file; it does **not** unpack its internal files or register the workflow YAML inside it. The repository must already contain an active `.github/workflows/build.yml` that knows how to unpack a single root-level ZIP before building.

## SDK setup fix included in this ZIP

The bundled workflow configures `android-actions/setup-android@v3` to request `platform-tools` explicitly, then installs Android platform 35, build-tools 35.0.0, CMake 3.22.1 and NDK 27.0.12077973. This is intended to avoid an SDK manager failure caused by requesting the removed legacy `tools` package.

**Important:** the workflow in this ZIP is not the same file as the workflow already stored in your GitHub repository. Uploading the ZIP alone will not replace the repository's `.github/workflows/build.yml`. The existing workflow must be updated as an actual repository file for the SDK fix to affect a run. A ZIP upload alone cannot perform that replacement under the user's current workflow.

## Obtaining the APK

1. Ensure the actual repository workflow is already registered and handles ZIP unpacking.
2. Upload this ZIP at the repository root.
3. Open the relevant GitHub Actions run. If successful, download the `sorinote-free-whisper-debug-apk` artifact.

This package has not been built with an installed Android SDK/NDK in the authoring environment. The resulting APK and device behavior have not yet been verified.

For the current repository, replace the existing root ZIP instead of adding another differently named ZIP if the repository workflow still expects a single ZIP. The workflow included in this archive is more tolerant and selects the highest versioned SoriNote ZIP, but that newer behavior applies only after the repository workflow itself has been updated.

## Official references

- GitHub file uploads: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- GitHub Actions workflow syntax: https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax
- Soniox listing: https://play.google.com/store/apps/details?id=com.soniox.sonioxmobileapp
- Soniox model documentation: https://soniox.com/docs/stt/models
