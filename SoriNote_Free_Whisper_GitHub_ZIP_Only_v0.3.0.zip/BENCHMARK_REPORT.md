# SoriNote v0.4.0 — Benchmark basis and change log

## Source APK

- Filename supplied: `APKPure_1.01.5806_apkpure.com.apk`
- Identified package: `com.apkpure.aegon`
- Version: `1.01.5806`
- Assessment: APKPure marketplace/store application, not Soniox's speech-to-text app. It cannot substantiate Soniox's speech engine, transcription UI, or recognition quality.
- Method: static package/manifest review only; the APK was not installed or executed.

## Public reference used instead

- Soniox Android listing: https://play.google.com/store/apps/details?id=com.soniox.sonioxmobileapp
- Soniox STT model documentation: https://soniox.com/docs/stt/models

These describe public user-facing capabilities and model behavior; they do not expose Soniox's source code or prove how its internal implementation works.

## Additions in this release

- Import an audio file through Android's document picker and transcribe locally; delete the converted temporary WAV after processing completes.
- Convert decoder-supported audio to mono PCM16/16 kHz WAV with streaming averaging during resampling.
- Add an optional, saved 500-character vocabulary/context prompt for Whisper.
- Add Whisper automatic language detection and display its detected language.
- Use Whisper beam search with beam size 5 as a quality-first decoding option.
- Expand language selection to 22 language options.
- Verify downloaded model SHA-1 before replacement and attempt rollback on installation failure.
- Keep the APK build ZIP-only workflow's Android SDK package request explicit (`platform-tools`) and retain separate exact SDK/NDK installation.

## Claims deliberately not made

- The supplied APK is not Soniox and no Soniox internals were reverse engineered.
- No claim of matching Soniox's transcription accuracy, speaker separation, real-time latency, or summarization quality.
- No WER/CER benchmark has yet been run on paired reference recordings.
- No Android Gradle build, APK installation, or physical-device validation was run in the source-authoring environment.

## Feature gap versus Soniox public description

| Feature | SoriNote v0.4.0 | Difference / limit |
| --- | --- | --- |
| Live transcription | Android on-device SpeechRecognizer | Not Soniox's hosted real-time model; language and availability depend on the device. |
| Audio-file transcription | Local Whisper after decode | Supported codecs depend on Android MediaCodec; no server transcription. |
| Context/vocabulary hint | One free-form prompt up to 500 characters | Not the same as Soniox structured context or guaranteed biasing. |
| Language identification | Whisper `auto` mode | Mixed-language switching was not tested. UI language choices currently list 22 languages. |
| Speaker separation | Not implemented | Native Whisper segments are not diarized. |
| Translation | On-device ML Kit after transcription | Not streaming real-time translation. |
| Summary | Rule-based key-sentence/task extraction | Not generative AI meeting-summary quality. |
| Export/share | Copy and share transcript text | Does not claim Soniox's full export/tagging feature set. |

Soniox's public model document currently describes `stt-rt-v5` and `stt-async-v5` with improvements for context, language identification, noisy speech, structured data, and speaker separation. Those hosted capabilities should not be assumed to exist in this offline app.
