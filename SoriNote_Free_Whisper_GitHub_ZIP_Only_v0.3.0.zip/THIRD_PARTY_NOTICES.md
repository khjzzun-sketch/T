# Third-party notices

## whisper.cpp

SoriNote's optional high-accuracy local transcription engine is built from the upstream `ggml-org/whisper.cpp` project (tag `v1.9.5`) during the Android build. Repository: https://github.com/ggml-org/whisper.cpp. The project is distributed under the MIT License; consult the upstream repository's `LICENSE` file for the full terms. This ZIP does not include copies of its source or model weights; CMake retrieves the pinned release during build.

## Whisper large-v3-turbo quantized model

The app offers an optional user-initiated download of `ggml-large-v3-turbo-q5_0.bin` from the public `ggerganov/whisper.cpp` Hugging Face repository. Model weights are not committed to this GitHub project. Model page: https://huggingface.co/ggerganov/whisper.cpp. Review the upstream model/repository terms before redistribution. The app verifies the downloaded file's SHA-1 against the upstream `whisper.cpp/models/README.md` listing before use.

## Google ML Kit Translation

The current app still uses the Google ML Kit Translation SDK for optional on-device translation. See https://developers.google.com/ml-kit/language/translation/android and its terms. Translation model data is downloaded by the SDK on demand; this is separate from speech recognition.
