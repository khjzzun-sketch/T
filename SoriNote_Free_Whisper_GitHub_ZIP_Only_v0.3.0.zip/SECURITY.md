# Security and privacy notes

- No Soniox API key, paid speech API, backend server, or cloud STT endpoint is included.
- Real-time recognition uses Android `createOnDeviceSpeechRecognizer` and does not fall back to the generic network recognizer. Android service behavior must still be reviewed on-device; only a true on-device service should be enabled in system settings.
- The high-accuracy path records mono 16 kHz PCM audio into the app's private files directory and runs whisper.cpp locally. The app does not upload that WAV file or the transcript.
- First model download is user-initiated and downloads the public 547 MiB quantized Whisper model from Hugging Face over HTTPS. SHA-1 is checked against the upstream model listing before the file is accepted. Do not commit model weights into GitHub.
- Translation uses the ML Kit Translation SDK and may download language model data. It is a separate feature from speech recognition.
- App-private text/audio is removed if the app is uninstalled or app data is cleared. Exported text may leave the device only when the user explicitly uses Android's share action.
- Native inference can use significant CPU, memory, storage and battery. Accuracy, performance, and thermal behavior have not yet been measured on target phones.
- Inspect `THIRD_PARTY_NOTICES.md` for upstream source/model notices.
