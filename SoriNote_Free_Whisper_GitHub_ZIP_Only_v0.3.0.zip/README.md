# 소리노트 무료 (SoriNote Free) — Android 프로젝트 v0.3.0

> **ZIP 파일 하나만 GitHub에 업로드하는 환경을 고려한 패키지입니다.** 이 ZIP 내부에는 프로젝트 파일이 별도 상위 폴더 없이 바로 들어 있습니다. 다만 GitHub는 업로드된 ZIP을 저장소 파일로 보관할 뿐, 자동으로 풀거나 ZIP 내부의 Actions 워크플로를 활성화하지 않습니다. 자세한 내용은 `GITHUB_ZIP_ONLY_UPLOAD.md`를 읽어 주세요.

Soniox 앱의 공개된 사용 흐름을 참고해 독립적으로 만든 무료 Android 녹취 앱입니다. **Soniox API, API 키, 유료 STT 서버, 자체 백엔드는 사용하지 않습니다.**

## 인식 모드

### 1. 실시간 간편 받아쓰기
- Android `SpeechRecognizer.createOnDeviceSpeechRecognizer()`로 기기 내 실시간 받아쓰기를 시도합니다.
- Android 기기의 서비스가 제공되지 않으면 온라인 엔진으로 몰래 전환하지 않고 오류를 표시합니다.
- 정확도와 언어 지원은 OS·기기·설치된 오프라인 엔진에 따라 달라집니다.

### 2. 고정밀 오프라인 전사 (Whisper)
- `whisper.cpp` + multilingual `large-v3-turbo-q5_0` 모델을 이용해 녹음 종료 후 이 기기에서 전사합니다.
- 모델 다운로드는 버튼을 눌렀을 때만 시작하며 크기는 약 547 MiB입니다. Wi-Fi와 충분한 저장 공간을 권장합니다.
- 모델 다운로드 후 전사 자체는 서버 API 없이 로컬에서 실행됩니다. 오디오/녹취 텍스트를 이 앱의 코드가 서버로 업로드하지 않습니다.
- 모델과 네이티브 엔진은 GitHub 저장소에 넣지 않고, 앱 첫 사용자가 모델을 기기에 다운로드합니다. CMake는 빌드할 때 `whisper.cpp` v1.9.5 소스를 공식 GitHub 태그에서 가져옵니다.
- 고정밀 모드는 앱 화면에서 녹음을 마친 후 전사하는 방식이며 실시간 부분 인식을 제공하지 않습니다. 화면이 꺼진 상태의 장시간 백그라운드 녹음은 현재 목표 범위에 포함되지 않습니다. 언어·잡음·화자·전문 용어에 따라 인식률이 달라지며 Soniox와 같은 결과를 보장하지 않습니다.
- 모델이 약 547 MiB이므로 설치 여유 공간 외에도 추가 저장 공간과 메모리가 필요합니다. 장시간 오디오에서는 속도와 메모리 소비가 증가합니다.

## 다른 기능
- 녹취록 로컬 저장, 검색, 열람, 복사, 공유, 삭제
- Google ML Kit Translation을 통한 선택적 기기 내 번역 (번역 언어 모델의 최초 다운로드 필요)
- 핵심 문장·할 일 후보 규칙 기반 추출 (생성형 AI 요약은 아님)

## Android Studio 빌드

필수 구성요소: JDK 17, Android SDK Platform 35, Android NDK 27.0.12077973, CMake 3.22.1, 인터넷 연결(Gradle/의존성/`whisper.cpp` 소스 다운로드용).

1. 이 ZIP을 압축 해제합니다. **안에 `settings.gradle.kts`, `build.gradle.kts`, `app/`가 바로 보여야 정상입니다.** 별도 최상위 프로젝트 폴더 없이 GitHub 저장소 루트에 올릴 수 있도록 ZIP을 구성했습니다.
2. Android Studio에서 압축 해제한 폴더를 엽니다.
3. Gradle Sync를 실행하고 `Build > Build APK(s)`를 선택합니다.
4. 첫 네이티브 빌드는 `whisper.cpp` 소스를 받아 컴파일하므로 평소보다 오래 걸릴 수 있습니다.

## GitHub에 ZIP 파일 하나만 업로드할 수 있는 경우

이 패키지는 그 환경을 고려해 만들었습니다. ZIP 최상위에는 `settings.gradle.kts`, `build.gradle.kts`, `app/`, `.github/workflows/` 등이 바로 들어 있으며 `sorinote_free/` 같은 여분의 상위 폴더는 없습니다.

- ZIP을 GitHub 저장소에 **파일 하나로 업로드**하면 GitHub에는 ZIP 파일 자체가 저장됩니다. GitHub는 파일 업로드 시 ZIP 내부 내용을 자동으로 풀지 않습니다.
- 그래서 ZIP 내부의 `.github/workflows/android-build.yml`은 업로드된 ZIP 파일 속에만 존재하는 상태이며, GitHub Actions가 이를 워크플로로 인식하지 않습니다.
- 아래 워크플로는 ZIP만 커밋된 경우에도 압축 파일을 풀고 빌드하도록 수정했습니다. 단, 이 기능은 **해당 워크플로가 저장소의 `.github/workflows/` 경로에 이미 등록되어 있어야만** 작동합니다.
- 새 저장소에 ZIP 파일 하나만 처음 올린 상태라면 GitHub Actions가 자동 빌드하도록 만들 수 없습니다. GitHub 규칙상 워크플로 YAML 파일을 저장소의 `.github/workflows/` 경로에 별도로 커밋해야 최초로 등록됩니다. ZIP 하나만 업로드한다는 제약으로는 이 초기 등록 단계를 우회할 수 없습니다.

## GitHub Actions에서 APK 받기

1. 저장소에 이 프로젝트의 파일들이 직접 올라가 있거나, 이전에 등록한 `Build Android APK` 워크플로가 ZIP 업로드를 처리할 수 있어야 합니다.
2. `main`/`master` 브랜치에 ZIP을 커밋하면, 워크플로가 이미 활성화된 저장소에서는 자동으로 실행됩니다. 또는 `Actions` 탭에서 `Build Android APK`를 실행합니다.
3. 실행이 성공하면 workflow run 하단의 `sorinote-free-whisper-debug-apk` artifact를 받습니다.
4. Android에서 APK를 설치하려면 artifact 안의 `app-debug.apk`를 꺼내 설치합니다. Debug APK이므로 공개 배포용 서명 APK와는 다릅니다.

워크플로 설정은 제공되어 있지만 이 작업 환경에는 Android SDK/NDK와 Gradle 빌드 실행 환경이 없어 실제 Android 빌드 및 기기 검증은 완료하지 못했습니다. **빌드 성공 여부는 실제 GitHub Actions 실행 결과로 확인해야 합니다.**

## 개인정보

- 음성 인식 모드는 둘 다 앱에서 직접 호출하는 STT 서버가 없습니다. 실시간 Android 인식은 `createOnDeviceSpeechRecognizer`로만 생성됩니다.
- 고정밀 모드는 PCM16/16kHz 오디오를 로컬 WAV로 기록하고 Whisper를 로컬 네이티브 라이브러리로 실행합니다.
- Whisper 모델은 사용자가 눌러 다운로드합니다. 전사 음성은 외부로 전송하지 않습니다.
- 번역 기능은 ML Kit 모델을 필요할 때 다운로드합니다.
- 녹취록/오디오는 앱 내부 저장소에 들어가며 앱 삭제나 데이터 삭제 시 사라집니다.

## 참고 문서

- Soniox current STT models: https://soniox.com/docs/stt/models
- Android on-device SpeechRecognizer API: https://developer.android.com/reference/android/speech/SpeechRecognizer
- whisper.cpp: https://github.com/ggml-org/whisper.cpp
- whisper.cpp model sizes/checksums: https://github.com/ggml-org/whisper.cpp/blob/master/models/README.md
- ML Kit on-device translation: https://developers.google.com/ml-kit/language/translation/android
- Third-party notices: `THIRD_PARTY_NOTICES.md`
