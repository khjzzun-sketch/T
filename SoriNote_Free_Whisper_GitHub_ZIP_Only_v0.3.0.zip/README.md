# 소리노트 무료 (SoriNote Free) — Android 프로젝트 v0.4.0

> **ZIP 파일 하나만 GitHub에 업로드하는 환경을 고려한 패키지입니다.** 저장소의 기존 ZIP을 대체하도록 다운로드 파일 이름은 이전 이름을 유지했지만, 앱 소스 내부 버전은 v0.4.0입니다. ZIP 최상위에 `settings.gradle.kts`, `build.gradle.kts`, `app/`, `.github/`가 바로 들어 있습니다. GitHub는 ZIP 업로드만으로 내부 파일을 풀거나 그 안의 워크플로를 등록하지 않습니다. 자세한 내용은 `GITHUB_ZIP_ONLY_UPLOAD.md`를 읽어 주세요.

Soniox 앱의 공개된 기능 설명과 사용 흐름을 참고해 독립적으로 만든 무료 Android 녹취 앱입니다. **Soniox API, API 키, 유료 STT 서버, 자체 백엔드는 사용하지 않습니다.** 사용자가 제공한 `APKPure_1.01.5806_apkpure.com.apk`는 Soniox 앱이 아니라 APKPure 스토어 앱으로 확인되어, 그 APK에서는 음성 인식 기능을 벤치마킹하지 않았습니다. 비교 기준은 Soniox의 공개 앱 설명과 공식 STT 문서입니다.

## 인식 모드

### 1. 실시간 간편 받아쓰기
- Android `SpeechRecognizer.createOnDeviceSpeechRecognizer()`로 기기 내 실시간 받아쓰기를 시도합니다.
- Android 기기의 서비스가 제공되지 않으면 온라인 엔진으로 몰래 전환하지 않고 오류를 표시합니다.
- 정확도와 언어 지원은 OS·기기·설치된 오프라인 엔진에 따라 달라집니다.

### 2. 고정밀 오프라인 전사 (Whisper)
- `whisper.cpp` + 다국어 `large-v3-turbo-q5_0` 모델을 이용해 이 기기에서 전사합니다.
- 품질 우선 설정으로 beam search(beam size 5)를 적용했습니다. greedy 방식보다 느릴 수 있으며, 모든 오디오에서 정확도가 반드시 향상된다는 보장은 없습니다.
- 모델 다운로드는 필요할 때 사용자가 시작합니다. 크기는 약 547 MiB이며 Wi-Fi와 충분한 저장 공간이 권장됩니다.
- 모델 다운로드 후 전사 자체는 서버 API 없이 로컬에서 실행됩니다. 앱 코드가 음성이나 전사 텍스트를 STT 서버에 업로드하지 않습니다.
- CMake는 빌드할 때 `whisper.cpp` v1.9.5 소스를 공식 GitHub 태그에서 가져옵니다. 큰 모델 가중치는 ZIP에 포함하지 않습니다.
- 고정밀 모드는 녹음 또는 파일 선택 후 처리하는 방식이며, 실시간 부분 인식을 제공하지 않습니다. 장시간 화면 꺼짐 백그라운드 녹음, 화자 분리, Soniox와 동등한 결과는 보장하지 않습니다.

## v0.4.0 추가·개선
- **오디오 파일 가져오기:** Android 시스템 파일 선택기에서 오디오를 고른 뒤 전사합니다. 기기가 디코딩할 수 있는 형식만 지원되며, 실제 지원 형식은 기기와 파일 코덱에 따라 달라집니다.
- **오디오 변환 경로:** Android 디코더를 이용해 입력 오디오를 모노 PCM 16 kHz WAV로 변환합니다. 다운샘플링 시 단순히 임의 샘플을 버리는 대신 구간 평균 방식으로 고주파 앨리어싱을 줄입니다.
- **고유명사·전문 용어 힌트:** 최대 500자의 문맥 힌트를 Whisper의 초기 프롬프트로 전달합니다. 이름, 프로젝트 명칭, 기술 용어에 도움이 될 수 있지만 오인식을 완전히 없애지는 않습니다.
- **언어 자동 감지:** Whisper 고정밀 전사에 `auto` 언어 모드를 제공하고, 감지된 언어를 표시합니다. 실시간 Android 받아쓰기에 적용되는 설정은 아닙니다.
- **번역 언어 선택 확장:** 22개 언어를 목록에 추가했습니다. 실제 인식과 번역 가능 여부는 엔진·모델 지원에 따릅니다.
- **모델 교체 보호:** 다운로드 완료 후 SHA-1을 검증하고, 검증된 파일만 설치 대상으로 교체합니다. 실패 시 기존 모델을 복구하려고 시도합니다.
- **Android SDK 설치 workflow 수정:** ZIP 내부의 workflow는 `platform-tools`만 명시적으로 요청하고 필요한 플랫폼·빌드 도구·CMake·NDK를 별도 설치합니다. 기존 GitHub 저장소에 이미 있는 workflow 파일은 ZIP 업로드만으로 교체되지 않습니다.

## 다른 기능
- 녹취록 로컬 저장, 검색, 열람, 복사, 공유, 삭제
- Google ML Kit Translation을 통한 선택적 기기 내 번역 (번역 언어 모델의 최초 다운로드 필요)
- 핵심 문장·할 일 후보 규칙 기반 추출 (생성형 AI 요약은 아님)

## Android Studio 빌드

필수 구성요소: JDK 17, Android SDK Platform 35, Android NDK 27.0.12077973, CMake 3.22.1, 인터넷 연결(Gradle/의존성/`whisper.cpp` 소스 다운로드용).

1. ZIP을 압축 해제합니다. **안에 `settings.gradle.kts`, `build.gradle.kts`, `app/`가 바로 보여야 정상입니다.**
2. Android Studio에서 압축 해제한 폴더를 엽니다.
3. Gradle Sync를 실행하고 `Build > Build APK(s)`를 선택합니다.
4. 첫 네이티브 빌드는 `whisper.cpp` 소스를 받아 컴파일하므로 시간이 더 걸릴 수 있습니다.

## GitHub Actions로 APK 만들기

- 저장소에 이 프로젝트의 파일이 직접 올라가 있거나, `Build Android APK` 워크플로가 ZIP을 풀어 빌드하도록 **저장소 내 `.github/workflows/build.yml`에 이미 등록**되어 있어야 합니다.
- `main`/`master`에 ZIP을 업로드하면 이미 등록된 워크플로가 실행될 수 있습니다. 실행이 성공하면 `sorinote-free-whisper-debug-apk` artifact를 받습니다.
- ZIP 내부의 `.github/workflows/build.yml`은 ZIP 파일 내부에 들어 있을 뿐이므로 저장소의 현재 workflow를 바꾸지 않습니다. 저장소의 workflow가 여전히 `setup-android`의 기본 `tools` 패키지를 요청하면 그 workflow를 별도로 고쳐야 합니다.
- 이 패키지는 실제 Android SDK/NDK 환경에서 빌드 또는 실기기 검증을 완료하지 않았습니다. 성공한 APK가 생성되었는지는 GitHub Actions 결과로 확인해야 합니다.

## 개인정보

- 음성 인식 모드는 앱 코드에서 직접 호출하는 STT 서버를 사용하지 않습니다. 실시간 모드는 Android 온디바이스 API, 고정밀 모드는 로컬 Whisper 엔진을 사용합니다.
- 모델과 번역 언어 모델은 기능을 사용할 때 다운로드됩니다. 네트워크 다운로드 중에는 모델 파일 요청이 발생합니다.
- 문맥 힌트는 앱의 기기 내 설정에 저장됩니다. 녹취록은 앱 내부 저장소에 저장됩니다. 삭제/앱 데이터 초기화 전까지 기기에 남을 수 있습니다.
- 이 프로젝트의 공개 모델 및 라이브러리 라이선스는 `THIRD_PARTY_NOTICES.md`를 확인하세요.

## 참고 문서

- Soniox Play Store listing: https://play.google.com/store/apps/details?id=com.soniox.sonioxmobileapp
- Soniox STT model documentation: https://soniox.com/docs/stt/models
- Android on-device SpeechRecognizer API: https://developer.android.com/reference/android/speech/SpeechRecognizer
- whisper.cpp: https://github.com/ggml-org/whisper.cpp
- whisper.cpp model sizes/checksums: https://github.com/ggml-org/whisper.cpp/blob/master/models/README.md
- ML Kit on-device translation: https://developers.google.com/ml-kit/language/translation/android
- Third-party notices: `THIRD_PARTY_NOTICES.md`
