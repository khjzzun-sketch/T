#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <cstdint>
#include <fstream>
#include <string>
#include <vector>
#include "whisper.h"

#define LOG_TAG "SoriNoteWhisper"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::string to_utf8(JNIEnv* env, jstring value) {
    if (value == nullptr) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

static void throw_java(JNIEnv* env, const char* message) {
    jclass cls = env->FindClass("java/lang/IllegalStateException");
    if (cls) env->ThrowNew(cls, message);
}

static uint16_t u16(const unsigned char* p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static uint32_t u32(const unsigned char* p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

// SoriNote records a canonical WAV: RIFF/WAVE, PCM16, mono, 16 kHz.
static bool read_pcm_wav(const std::string& path, std::vector<float>& samples, std::string& error) {
    std::ifstream in(path, std::ios::binary);
    if (!in) { error = "녹음 파일을 열 수 없습니다."; return false; }
    unsigned char header[12];
    in.read(reinterpret_cast<char*>(header), 12);
    if (in.gcount() != 12 || std::string(reinterpret_cast<char*>(header), 4) != "RIFF" ||
        std::string(reinterpret_cast<char*>(header + 8), 4) != "WAVE") {
        error = "지원하지 않는 WAV 형식입니다."; return false;
    }
    uint16_t audio_format = 0, channels = 0, bits = 0;
    uint32_t sample_rate = 0, data_size = 0;
    bool have_fmt = false, have_data = false;
    while (in && (!have_fmt || !have_data)) {
        unsigned char chunk_header[8];
        in.read(reinterpret_cast<char*>(chunk_header), 8);
        if (in.gcount() != 8) break;
        const uint32_t size = u32(chunk_header + 4);
        const std::string name(reinterpret_cast<char*>(chunk_header), 4);
        if (name == "fmt ") {
            if (size < 16) { error = "WAV 헤더가 올바르지 않습니다."; return false; }
            unsigned char fmt[16]; in.read(reinterpret_cast<char*>(fmt), 16);
            if (in.gcount() != 16) { error = "WAV 포맷을 읽을 수 없습니다."; return false; }
            audio_format = u16(fmt); channels = u16(fmt + 2); sample_rate = u32(fmt + 4); bits = u16(fmt + 14);
            in.seekg(static_cast<std::streamoff>(size - 16 + (size % 2)), std::ios::cur);
            have_fmt = true;
        } else if (name == "data") {
            data_size = size;
            const auto pos = in.tellg();
            in.seekg(0, std::ios::end);
            const auto end = in.tellg();
            if (pos < 0 || end < pos || static_cast<uint64_t>(end - pos) < data_size) {
                error = "WAV 데이터가 잘렸습니다."; return false;
            }
            in.seekg(pos);
            if ((data_size % 2U) != 0U) { error = "PCM16 WAV 데이터 길이가 올바르지 않습니다."; return false; }
            samples.resize(data_size / 2);
            // Convert incrementally to avoid holding a second full-sized PCM byte array in memory.
            std::vector<unsigned char> pcm_chunk(1024 * 1024);
            size_t sample_index = 0;
            uint32_t remaining = data_size;
            while (remaining > 0) {
                uint32_t want = std::min<uint32_t>(remaining, static_cast<uint32_t>(pcm_chunk.size()));
                want &= ~1U;
                in.read(reinterpret_cast<char*>(pcm_chunk.data()), want);
                if (static_cast<uint32_t>(in.gcount()) != want) { error = "WAV 오디오를 전부 읽지 못했습니다."; return false; }
                for (uint32_t offset = 0; offset < want; offset += 2) {
                    const int16_t value = static_cast<int16_t>(u16(pcm_chunk.data() + offset));
                    samples[sample_index++] = static_cast<float>(value) / 32768.0f;
                }
                remaining -= want;
            }
            have_data = true;
        } else {
            in.seekg(static_cast<std::streamoff>(size + (size % 2)), std::ios::cur);
        }
    }
    if (!have_fmt || !have_data) { error = "WAV 헤더 또는 오디오 데이터가 없습니다."; return false; }
    if (audio_format != 1 || channels != 1 || bits != 16 || sample_rate != 16000) {
        error = "현재 고정밀 엔진은 PCM 16-bit / mono / 16 kHz WAV만 지원합니다."; return false;
    }
    if (samples.empty()) { error = "녹음된 음성이 비어 있습니다."; return false; }
    return true;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_sorinote_WhisperNative_transcribe(
        JNIEnv* env, jobject /* thiz */, jstring model_path, jstring wav_path,
        jstring language, jint threads) {
    const std::string model = to_utf8(env, model_path);
    const std::string wav = to_utf8(env, wav_path);
    std::string lang = to_utf8(env, language);
    if (model.empty() || wav.empty()) { throw_java(env, "모델 경로 또는 오디오 경로가 비어 있습니다."); return nullptr; }
    if (lang.empty()) lang = "ko";
    std::vector<float> samples;
    std::string error;
    if (!read_pcm_wav(wav, samples, error)) { throw_java(env, error.c_str()); return nullptr; }

    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false; // CPU-first for portable Android reliability; no cloud inference.
    whisper_context* ctx = whisper_init_from_file_with_params(model.c_str(), cp);
    if (!ctx) { throw_java(env, "Whisper 모델을 로드하지 못했습니다. 파일 크기와 저장 공간을 확인하세요."); return nullptr; }

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.n_threads = std::max(2, std::min((int)threads, 8));
    params.language = lang.c_str();
    params.translate = false;
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.no_context = false;
    params.single_segment = false;
    params.suppress_blank = true;
    params.suppress_non_speech_tokens = true;
    const int rc = whisper_full(ctx, params, samples.data(), (int)samples.size());
    if (rc != 0) {
        whisper_free(ctx);
        throw_java(env, "고정밀 전사 중 오류가 발생했습니다. 메모리 부족일 수 있습니다.");
        return nullptr;
    }
    std::string result;
    const int count = whisper_full_n_segments(ctx);
    for (int i = 0; i < count; ++i) {
        const char* segment = whisper_full_get_segment_text(ctx, i);
        if (segment) {
            if (!result.empty()) result += "\n";
            result += segment;
        }
    }
    whisper_free(ctx);
    if (result.empty()) result = "음성을 인식하지 못했습니다.";
    return env->NewStringUTF(result.c_str());
}
