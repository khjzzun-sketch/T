package com.example.sorinote

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Records 16 kHz mono PCM16 WAV locally for the high-accuracy offline Whisper pass. */
internal class LocalAudioRecorder(private val context: Context) {
    companion object {
        private const val SAMPLE_RATE = 16_000
        private const val CHANNEL = AudioFormat.CHANNEL_IN_MONO
        private const val ENCODING = AudioFormat.ENCODING_PCM_16BIT
    }

    @Volatile private var recording = false
    @Volatile private var recordFailure: String? = null
    private var audioRecord: AudioRecord? = null
    private var writer: Thread? = null
    private var currentFile: File? = null

    @Synchronized fun start(): File {
        check(!recording) { "이미 녹음 중입니다." }
        val minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL, ENCODING)
        if (minBuffer <= 0) throw IOException("이 기기에서 16 kHz 녹음을 시작하지 못했습니다.")
        val bufferBytes = maxOf(minBuffer, 16 * 1024)
        val recorder = AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, CHANNEL, ENCODING, bufferBytes)
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            throw IOException("마이크 초기화에 실패했습니다.")
        }
        val dir = File(context.filesDir, "recordings").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val file = File(dir, "sorinote-$stamp.wav")
        currentFile = file
        recordFailure = null
        recording = true
        audioRecord = recorder
        recorder.startRecording()
        writer = Thread({
            var bytesWritten = 0L
            try {
                BufferedOutputStream(FileOutputStream(file)).use { output ->
                    output.write(wavHeader(0))
                    val samples = ShortArray(bufferBytes / 2)
                    val bytes = ByteArray(samples.size * 2)
                    while (recording) {
                        val n = recorder.read(samples, 0, samples.size, AudioRecord.READ_BLOCKING)
                        if (n > 0) {
                            var j = 0
                            for (i in 0 until n) {
                                val value = samples[i].toInt()
                                bytes[j++] = (value and 0xff).toByte()
                                bytes[j++] = ((value shr 8) and 0xff).toByte()
                            }
                            output.write(bytes, 0, j)
                            bytesWritten += j
                        } else if (n < 0) {
                            if (recording) recordFailure = "오디오 녹음 오류 코드: $n"
                            break
                        }
                    }
                    output.flush()
                }
                patchHeader(file, bytesWritten.toInt())
            } catch (e: Exception) {
                recordFailure = e.localizedMessage ?: "녹음 파일을 저장하지 못했습니다."
            } finally {
                try { recorder.release() } catch (_: Exception) { }
                if (audioRecord === recorder) audioRecord = null
            }
        }, "sorinote-audio-recorder")
        writer?.start()
        return file
    }

    @Synchronized fun stop(): File? {
        if (!recording && writer == null) return currentFile
        recording = false
        try { audioRecord?.stop() } catch (_: Exception) { }
        try { writer?.join(15_000) } catch (e: InterruptedException) { Thread.currentThread().interrupt() }
        writer = null
        audioRecord = null
        recordFailure?.let { message ->
            // A failed recording cannot be replayed from the UI; remove any partial private file.
            currentFile?.delete()
            throw IOException(message)
        }
        return currentFile?.takeIf { it.exists() && it.length() > 44L }
    }

    @Synchronized fun release() {
        try { stop() } catch (_: Exception) { }
    }

    private fun wavHeader(dataBytes: Int): ByteArray {
        val header = ByteArray(44)
        fun putText(offset: Int, text: String) { text.toByteArray(Charsets.US_ASCII).copyInto(header, offset) }
        fun put16(offset: Int, value: Int) { header[offset] = (value and 0xff).toByte(); header[offset + 1] = ((value shr 8) and 0xff).toByte() }
        fun put32(offset: Int, value: Int) { for (i in 0..3) header[offset + i] = ((value shr (8 * i)) and 0xff).toByte() }
        putText(0, "RIFF"); put32(4, dataBytes + 36); putText(8, "WAVE")
        putText(12, "fmt "); put32(16, 16); put16(20, 1); put16(22, 1)
        put32(24, SAMPLE_RATE); put32(28, SAMPLE_RATE * 2); put16(32, 2); put16(34, 16)
        putText(36, "data"); put32(40, dataBytes)
        return header
    }

    private fun patchHeader(file: File, dataBytes: Int) {
        RandomAccessFile(file, "rw").use { raf ->
            raf.seek(4); writeLeInt(raf, dataBytes + 36)
            raf.seek(40); writeLeInt(raf, dataBytes)
        }
    }

    private fun writeLeInt(raf: RandomAccessFile, value: Int) {
        for (i in 0..3) raf.write((value shr (8 * i)) and 0xff)
    }
}
