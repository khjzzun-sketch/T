package com.example.sorinote

/** On-device Whisper inference. Native library is compiled from upstream whisper.cpp. */
internal object WhisperNative {
    init { System.loadLibrary("sorinote_whisper") }
    external fun transcribe(modelPath: String, wavPath: String, language: String, initialPrompt: String, threads: Int): Array<String>
}
