package com.example.sorinote

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

internal object WhisperModelManager {
    const val MODEL_NAME = "ggml-large-v3-turbo-q5_0.bin"
    const val EXPECTED_SHA1 = "e050f7970618a659205450ad97eb95a18d69c9ee"
    private const val MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin?download=true"
    private val mainHandler = Handler(Looper.getMainLooper())

    fun modelFile(context: Context): File = File(File(context.filesDir, "models"), MODEL_NAME)
    fun isReady(context: Context): Boolean = modelFile(context).let { it.exists() && it.length() > 500L * 1024L * 1024L }

    fun download(context: Context, onProgress: (Int) -> Unit, onDone: (Result<File>) -> Unit) {
        Thread({
            val target = modelFile(context)
            val temp = File(target.parentFile, target.name + ".download")
            try {
                target.parentFile?.mkdirs()
                temp.delete()
                val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 25_000
                    readTimeout = 60_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "SoriNote-Free-Android/0.4")
                }
                try {
                    val code = connection.responseCode
                    if (code !in 200..299) throw IOException("모델 서버 응답: HTTP $code")
                    val total = connection.contentLengthLong
                    val digest = MessageDigest.getInstance("SHA-1")
                    var copied = 0L
                    var lastProgress = -1
                    BufferedInputStream(connection.inputStream).use { input ->
                        FileOutputStream(temp).use { output ->
                            val buffer = ByteArray(1024 * 256)
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                output.write(buffer, 0, n)
                                digest.update(buffer, 0, n)
                                copied += n
                                if (total > 0) {
                                    val progress = ((copied * 100L) / total).toInt().coerceIn(0, 100)
                                    if (progress != lastProgress) {
                                        lastProgress = progress
                                        mainHandler.post { onProgress(progress) }
                                    }
                                }
                            }
                            output.fd.sync()
                        }
                    }
                    val hash = digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
                    if (!hash.equals(EXPECTED_SHA1, ignoreCase = true)) {
                        throw IOException("모델 검증 실패(SHA-1 불일치). 다운로드 파일을 삭제했습니다.")
                    }
                    val backup = File(target.parentFile, target.name + ".verified-backup")
                    backup.delete()
                    if (target.exists() && !target.renameTo(backup)) {
                        throw IOException("기존 모델을 안전하게 교체하지 못했습니다.")
                    }
                    if (!temp.renameTo(target)) {
                        if (backup.exists()) backup.renameTo(target)
                        throw IOException("검증된 모델 파일을 설치 위치로 옮기지 못했습니다.")
                    }
                    backup.delete()
                    mainHandler.post { onProgress(100); onDone(Result.success(target)) }
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                temp.delete()
                mainHandler.post { onDone(Result.failure(e)) }
            }
        }, "sorinote-model-download").start()
    }
}
