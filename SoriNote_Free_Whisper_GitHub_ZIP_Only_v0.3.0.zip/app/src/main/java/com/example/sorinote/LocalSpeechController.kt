package com.example.sorinote

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

internal data class SpeechUiState(
    val status: String = "대기 중",
    val finalText: String = "",
    val partialText: String = "",
    val listening: Boolean = false,
    val error: String? = null
)

/** Uses Android's on-device SpeechRecognizer only. It deliberately does not fall back to a network recognizer. */
internal class LocalSpeechController(
    context: Context,
    private val onState: (SpeechUiState) -> Unit
) : RecognitionListener {
    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var active = false
    private var languageTag = "ko-KR"
    private var finalText = ""
    private var partialText = ""
    private var restartDelayMs = 350L

    private val restartRunnable = Runnable { beginListening() }

    fun start(language: String, startingText: String = "") {
        stop(notify = false)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || !SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)) {
            publish(SpeechUiState(
                status = "온디바이스 음성 인식을 사용할 수 없음",
                finalText = startingText,
                error = "이 기기에서 Android 온디바이스 음성 인식 서비스를 사용할 수 없습니다. 설정에서 오프라인 음성 인식 언어를 설치하거나 지원하는 음성 인식 서비스를 활성화한 뒤 다시 시도하세요. 온라인 인식으로 자동 전환하지 않았습니다."
            ))
            return
        }
        languageTag = language
        finalText = startingText.trim()
        partialText = ""
        restartDelayMs = 350L
        try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(appContext).also {
                it.setRecognitionListener(this)
            }
            active = true
            publish(SpeechUiState(status = "오프라인 인식 시작 중", finalText = finalText, listening = true))
            beginListening()
        } catch (e: Exception) {
            active = false
            destroyRecognizer()
            publish(SpeechUiState(
                status = "인식 시작 실패",
                finalText = finalText,
                error = e.message ?: "온디바이스 음성 인식을 시작하지 못했습니다."
            ))
        }
    }

    private fun beginListening() {
        if (!active) return
        val r = recognizer ?: return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
            }
            r.startListening(intent)
        } catch (e: Exception) {
            active = false
            publish(SpeechUiState(
                status = "인식 시작 실패",
                finalText = finalText,
                error = e.message ?: "음성 인식 요청을 시작하지 못했습니다."
            ))
        }
    }

    fun stop() = stop(notify = true)

    private fun stop(notify: Boolean) {
        active = false
        handler.removeCallbacks(restartRunnable)
        destroyRecognizer()
        if (notify) {
            publish(SpeechUiState(status = "녹취 종료", finalText = finalText, partialText = partialText, listening = false))
        }
    }

    private fun destroyRecognizer() {
        val r = recognizer
        recognizer = null
        try { r?.cancel() } catch (_: Exception) { }
        try { r?.destroy() } catch (_: Exception) { }
    }

    private fun appendFinal(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        val current = finalText.trimEnd()
        if (current.endsWith(clean)) return
        // Avoid repeated overlap where an OEM engine repeats the end of the previous segment.
        val currentWords = current.split(Regex("\\s+")).filter { it.isNotBlank() }
        val nextWords = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
        var overlap = minOf(8, currentWords.size, nextWords.size)
        while (overlap > 0 && currentWords.takeLast(overlap).joinToString(" ") != nextWords.take(overlap).joinToString(" ")) overlap--
        val remainder = nextWords.drop(overlap).joinToString(" ")
        if (remainder.isNotBlank()) {
            finalText = if (current.isBlank()) remainder else "$current\n$remainder"
        }
    }

    private fun scheduleRestart(delay: Long = restartDelayMs) {
        if (!active) return
        handler.removeCallbacks(restartRunnable)
        handler.postDelayed(restartRunnable, delay)
    }

    private fun publish(state: SpeechUiState) = onState(state)

    override fun onReadyForSpeech(params: Bundle?) {
        if (active) publish(SpeechUiState("듣는 중 · 기기 내 처리", finalText, partialText, true))
    }
    override fun onBeginningOfSpeech() {
        if (active) publish(SpeechUiState("음성 인식 중 · 기기 내 처리", finalText, partialText, true))
    }
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() {
        if (active) publish(SpeechUiState("문장 처리 중", finalText, partialText, true))
    }
    override fun onError(error: Int) {
        if (!active) return
        when (error) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                partialText = ""
                publish(SpeechUiState("계속 듣는 중 · 기기 내 처리", finalText, "", true))
                scheduleRestart(250L)
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_SERVER -> {
                publish(SpeechUiState("음성 엔진 재시도 중", finalText, partialText, true))
                scheduleRestart(900L)
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                active = false
                publish(SpeechUiState("마이크 권한 필요", finalText, partialText, false, "설정에서 마이크 권한을 허용하세요."))
            }
            else -> {
                active = false
                publish(SpeechUiState("음성 인식 오류", finalText, partialText, false, errorMessage(error)))
            }
        }
    }
    override fun onResults(results: Bundle?) {
        if (!active) return
        val result = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
        appendFinal(result)
        partialText = ""
        restartDelayMs = 350L
        publish(SpeechUiState("듣는 중 · 기기 내 처리", finalText, "", true))
        scheduleRestart(250L)
    }
    override fun onPartialResults(partialResults: Bundle?) {
        if (!active) return
        partialText = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
        publish(SpeechUiState("음성 인식 중 · 기기 내 처리", finalText, partialText, true))
    }
    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    private fun errorMessage(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "오디오 입력에 문제가 있습니다. 다른 앱이 마이크를 사용 중인지 확인하세요."
        SpeechRecognizer.ERROR_CLIENT -> "음성 인식 서비스가 요청을 종료했습니다. 다시 시작해 주세요."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "온디바이스 음성 엔진 오류입니다. 온라인 서비스로 전환하지 않았습니다. 언어 모델과 기기 지원 여부를 확인하세요."
        SpeechRecognizer.ERROR_SERVER -> "기기 내 음성 인식 서비스에서 오류가 발생했습니다."
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED -> "선택한 언어가 이 기기의 오프라인 인식에서 지원되지 않습니다."
        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> "선택한 언어 모델이 설치되어 있지 않습니다. 언어 설정에서 모델을 다운로드하세요."
        else -> "음성 인식 오류 코드: $code"
    }
}
