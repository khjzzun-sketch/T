package com.example.sorinote

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.nio.ByteOrder

/**
 * Decodes a user-selected local audio file and writes canonical PCM16/mono/16 kHz WAV for whisper.cpp.
 * Uses Android's platform media decoders; no audio is uploaded by this component.
 */
internal object AudioFileTranscoder {
    private const val TARGET_RATE = 16_000
    private const val MAX_WAV_DATA_BYTES = Int.MAX_VALUE.toLong() - 44L

    fun convertToWav(
        context: Context,
        source: Uri,
        destination: File,
        onProgress: (Int) -> Unit = {}
    ): File {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var decoderStarted = false
        var outputBytes = 0L
        try {
            extractor.setDataSource(context, source, null)
            var audioTrack = -1
            var audioFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val candidate = extractor.getTrackFormat(i)
                val mime = candidate.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrack = i
                    audioFormat = candidate
                    break
                }
            }
            val inputFormat = audioFormat ?: throw IOException("선택한 파일에서 오디오 트랙을 찾지 못했습니다.")
            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: throw IOException("오디오 형식을 확인할 수 없습니다.")
            val durationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION)) inputFormat.getLong(MediaFormat.KEY_DURATION) else 0L
            extractor.selectTrack(audioTrack)
            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()
            decoderStarted = true

            destination.parentFile?.mkdirs()
            destination.delete()
            var inputDone = false
            var outputDone = false
            var sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 0
            var channels = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 0
            var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
            // Streaming box-filter resampler. It averages the input samples that overlap each
            // 16 kHz output interval instead of dropping arbitrary samples (which can alias).
            var outputWeightRemaining = 0L
            var weightedSampleSum = 0.0
            var lastProgress = -1

            BufferedOutputStream(FileOutputStream(destination), 128 * 1024).use { output ->
                output.write(wavHeader(0))
                val info = MediaCodec.BufferInfo()
                while (!outputDone) {
                    if (!inputDone) {
                        val inputIndex = decoder.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val inputBuffer = decoder.getInputBuffer(inputIndex)
                                ?: throw IOException("오디오 디코더 입력 버퍼를 사용할 수 없습니다.")
                            inputBuffer.clear()
                            val size = extractor.readSampleData(inputBuffer, 0)
                            if (size < 0) {
                                decoder.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                val pts = extractor.sampleTime.coerceAtLeast(0L)
                                decoder.queueInputBuffer(inputIndex, 0, size, pts, 0)
                                extractor.advance()
                            }
                        }
                    }

                    when (val outputIndex = decoder.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val decodedFormat = decoder.outputFormat
                            if (decodedFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = decodedFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (decodedFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = decodedFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            if (decodedFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = decodedFormat.getInteger(MediaFormat.KEY_PCM_ENCODING)
                            if (sampleRate <= 0 || channels <= 0) throw IOException("디코딩된 오디오의 샘플레이트/채널을 확인할 수 없습니다.")
                            if (pcmEncoding != AudioFormat.ENCODING_PCM_16BIT && pcmEncoding != AudioFormat.ENCODING_PCM_FLOAT) {
                                throw IOException("이 기기의 디코더가 지원하지 않는 PCM 형식을 반환했습니다.")
                            }
                        }
                        else -> if (outputIndex >= 0) {
                            val buffer = decoder.getOutputBuffer(outputIndex)
                            if (buffer != null && info.size > 0 && (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                                if (sampleRate <= 0 || channels <= 0) throw IOException("오디오 샘플 형식을 확인할 수 없습니다.")
                                if (outputWeightRemaining == 0L) outputWeightRemaining = sampleRate.toLong()
                                val pcm = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
                                pcm.position(info.offset)
                                pcm.limit(info.offset + info.size)
                                val bytesPerSample = if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
                                val frameBytes = channels * bytesPerSample
                                while (pcm.remaining() >= frameBytes) {
                                    var sum = 0.0
                                    repeat(channels) {
                                        sum += if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                            pcm.float.toDouble().coerceIn(-1.0, 1.0)
                                        } else {
                                            pcm.short.toInt() / 32768.0
                                        }
                                    }
                                    val mono = (sum / channels).coerceIn(-1.0, 1.0)
                                    var inputWeightRemaining = TARGET_RATE.toLong()
                                    while (inputWeightRemaining > 0L) {
                                        val overlap = minOf(inputWeightRemaining, outputWeightRemaining)
                                        weightedSampleSum += mono * overlap.toDouble()
                                        inputWeightRemaining -= overlap
                                        outputWeightRemaining -= overlap
                                        if (outputWeightRemaining == 0L) {
                                            if (outputBytes + 2L > MAX_WAV_DATA_BYTES) {
                                                throw IOException("변환 결과가 WAV 파일의 최대 크기를 초과합니다. 더 짧은 오디오를 선택해 주세요.")
                                            }
                                            val averaged = (weightedSampleSum / sampleRate.toDouble()).coerceIn(-1.0, 1.0)
                                            val sample = (averaged * 32767.0).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                                            output.write(sample and 0xff)
                                            output.write((sample shr 8) and 0xff)
                                            outputBytes += 2L
                                            weightedSampleSum = 0.0
                                            outputWeightRemaining = sampleRate.toLong()
                                        }
                                    }
                                }
                                if (durationUs > 0L) {
                                    val estimate = (outputBytes * 1_000_000L / (TARGET_RATE * 2L) * 100L / durationUs).toInt().coerceIn(0, 99)
                                    if (estimate != lastProgress) {
                                        lastProgress = estimate
                                        onProgress(estimate)
                                    }
                                }
                            }
                            outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                            decoder.releaseOutputBuffer(outputIndex, false)
                        }
                    }
                }
                output.flush()
            }

            if (outputBytes < 2L) throw IOException("선택한 오디오에서 음성 데이터를 읽지 못했습니다.")
            RandomAccessFile(destination, "rw").use { file ->
                file.seek(4L); writeLeInt(file, (outputBytes + 36L).toInt())
                file.seek(40L); writeLeInt(file, outputBytes.toInt())
                file.fd.sync()
            }
            onProgress(100)
            return destination
        } catch (e: Exception) {
            destination.delete()
            if (e is IOException) throw e
            throw IOException("오디오 파일을 읽거나 변환하지 못했습니다: ${e.localizedMessage ?: e.javaClass.simpleName}", e)
        } finally {
            try { if (decoderStarted) decoder?.stop() } catch (_: Exception) { }
            try { decoder?.release() } catch (_: Exception) { }
            try { extractor.release() } catch (_: Exception) { }
        }
    }

    private fun wavHeader(dataBytes: Int): ByteArray {
        val header = ByteArray(44)
        fun text(offset: Int, value: String) { value.toByteArray(Charsets.US_ASCII).copyInto(header, offset) }
        fun u16(offset: Int, value: Int) {
            header[offset] = (value and 0xff).toByte()
            header[offset + 1] = ((value ushr 8) and 0xff).toByte()
        }
        fun u32(offset: Int, value: Int) {
            for (i in 0..3) header[offset + i] = ((value ushr (8 * i)) and 0xff).toByte()
        }
        text(0, "RIFF"); u32(4, dataBytes + 36); text(8, "WAVE")
        text(12, "fmt "); u32(16, 16); u16(20, 1); u16(22, 1)
        u32(24, TARGET_RATE); u32(28, TARGET_RATE * 2); u16(32, 2); u16(34, 16)
        text(36, "data"); u32(40, dataBytes)
        return header
    }

    private fun writeLeInt(file: RandomAccessFile, value: Int) {
        for (i in 0..3) file.write((value ushr (8 * i)) and 0xff)
    }
}
