# GitHub ZIP-only upload guide

## What this package is

This is the complete SoriNote Free Android source project in a flat ZIP layout. After extracting it, the archive root immediately contains `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/workflows/android-build.yml`. There is no extra top-level project directory.

## If your only available upload operation is “upload this ZIP as one file”

You can upload this ZIP to a GitHub repository as an archive for storage and later download. GitHub will store it as a `.zip` file; it will **not** unpack the contents. Therefore, the workflow YAML inside the ZIP is not registered as a GitHub Actions workflow just because the archive was uploaded.

The included `android-build.yml` has been adapted to build from one root-level project ZIP if the workflow is already active in the repository. This helps on a repository where that workflow has previously been registered and remains present in `.github/workflows/`.

## Important first-use limitation

For a new or empty repository, uploading this ZIP alone cannot activate GitHub Actions. GitHub discovers workflows only when YAML files are committed under `.github/workflows/` in the repository itself. The archive cannot make GitHub extract and register its own workflow. So one of these is required to build an APK:

1. register the workflow once as a real file at `.github/workflows/android-build.yml`, or
2. use an environment that extracts the archive and commits its contents as repository files.

If neither is possible, the ZIP can still be stored on GitHub, but automated APK building from that repository cannot start from the ZIP alone. This is a GitHub platform limitation, not a missing setting inside the ZIP.

Official documentation:
- https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax


## 2026-10-29 build fix note

The workflow bundled in this ZIP now explicitly requests only `platform-tools` from `android-actions/setup-android@v3`, avoiding the legacy default request for the removed SDK package `tools`. It then installs the exact Android platform, build-tools, CMake, and NDK versions used by the project.

**Important:** uploading this ZIP as a file to an existing GitHub repository does not replace the repository's existing `.github/workflows/build.yml`. The repository currently has its own workflow file, and that file must be updated separately for this fix to affect Actions. GitHub does not automatically unpack ZIP uploads or merge files from inside them.
