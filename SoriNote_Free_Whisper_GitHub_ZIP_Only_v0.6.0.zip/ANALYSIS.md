# v0.6.0 design/acceptance notes

## Requirements applied

- Keep only model setup, live Korean transcription, copy and clear.
- Avoid paid cloud transcription APIs, account setup, usage credits and API keys.
- Do transcription on-device through whisper.cpp; network permission is used for the one-time model download only.
- Use `large-v3-turbo-q5_0` for the quality/latency compromise on modern arm64 phones; do not bundle the 547 MiB model in the APK.
- Pin the native dependency to the upstream `v1.9.5` tag, compile native C++ with Release optimization even in the Debug APK for usable inference speed, and explicitly install Android SDK packages in CI.
- Make the GitHub workflow consume a versioned ZIP uploaded to the repository root, because a ZIP's embedded workflow is not automatically activated by GitHub.

## Important limitations

- The first inference starts once two seconds of audio are captured; later inference uses a rolling audio window. This is not the Soniox proprietary streaming model. Results may be revised as the window advances and latency depends on device temperature, load, microphone environment and utterance complexity.
- Static checks cannot substitute for `assembleDebug` or device acceptance. GitHub Actions must produce the APK artifact before it is called build-verified.
- The transcript stitcher uses lexical overlap rather than forced alignment. Long recordings with heavily revised recognition may still need transcript review.
