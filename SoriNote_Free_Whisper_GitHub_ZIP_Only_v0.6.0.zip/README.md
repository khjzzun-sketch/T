# 소리노트 v0.6.0 — 무료·무제한 온디바이스 실시간 전사

## 목표

- Android에서 마이크 입력을 받아 한국어 텍스트를 빠르게 화면에 표시
- Whisper 계열 음성 인식 모델로 전사
- 로그인/API 키/유료 전사 API 없이 사용
- 전사 오디오를 서버로 전송하지 않고 기기에서 처리
- 기능은 모델 준비, 실시간 전사, 전사 복사/초기화로 제한

## 실제 사용 시 주의사항

- 최초 1회 Hugging Face에서 약 **547 MiB**의 `large-v3-turbo-q5_0` 모델을 다운로드합니다. 모바일 데이터를 아끼려면 Wi-Fi에서 진행하세요.
- 모델은 앱 내부 저장소에 저장되며, 다운로드 시 SHA-1을 확인합니다. 이후 음성 전사는 인터넷/API가 필요하지 않습니다.
- 첫 전사 시도는 약 2초의 오디오가 쌓이면 시작합니다. 이후 Whisper의 롤링 오디오 창을 재전사하며, 추론 시작 간격은 1.25초를 목표로 하되 한 번의 추론이 더 오래 걸리면 실제 갱신 간격도 길어집니다. 따라서 모든 기기에서 지연이 일정하거나 Soniox와 완전히 같은 정확도가 보장되지는 않습니다. 빠른 음성, 고유명사, 소음 환경에서는 결과를 확인·수정해야 합니다.
- 이 빌드는 `arm64-v8a` 대상입니다. 64비트 Android 휴대전화용이며 x86 에뮬레이터는 포함하지 않습니다.
- 앱을 종료하면 현재 화면의 전사본은 별도 파일로 자동 보관하지 않습니다. 필요한 텍스트는 전사 복사 버튼으로 복사하세요.

## GitHub에 ZIP을 올려 APK 받기

GitHub는 저장소에 올린 ZIP 안의 workflow를 자동 실행하지 않습니다. 따라서 다음 두 항목이 필요합니다.

1. `SoriNote_Free_Whisper_GitHub_ZIP_Only_v0.6.0.zip` 파일을 저장소 **루트**에 업로드합니다.
2. 이 ZIP 안의 `.github/workflows/android-build.yml`을 저장소의 `.github/workflows/android-build.yml`로도 반영합니다. 가장 쉬운 방법은 별도 제공된 `SoriNote_android-build_v0.6.0.yml` 파일의 내용을 해당 경로에 저장하는 것입니다.
3. `.github/workflows/build.yml` 등 동일 프로젝트를 중복 빌드하는 이전 workflow가 활성화되어 있다면 하나만 남깁니다.
4. GitHub 저장소의 **Actions → SoriNote Android APK**를 열어 실행 결과를 확인합니다.
5. 성공한 실행의 **Artifacts**에서 `sorinote-v0.6.0-free-whisper-live-arm64-debug-apk`를 내려받아 ZIP을 풀고 `app-debug.apk`를 설치합니다. Android에서 알 수 없는 앱 설치를 허용해야 할 수 있습니다.

워크플로는 빌드 전에 ZIP 무결성/루트 구조/버전/모델 해시/네이티브 버전을 확인하고, `assembleDebug`, APK ZIP 무결성, 패키지 ID를 검사한 뒤 APK artifact를 올립니다. `sdkmanager`에는 `platform-tools`만 명시하므로 제거된 `tools` 패키지를 요청하지 않습니다.

## 기술 구조

- UI / 마이크 캡처: Kotlin + Android `AudioRecord` (16 kHz, mono, PCM16)
- 음성 인식: Android NDK/JNI + `whisper.cpp` v1.9.5 (Debug APK에서도 네이티브 C++은 Release 최적화로 빌드)
- 기본 모델: `ggml-large-v3-turbo-q5_0.bin` (약 547 MiB, 최초 실행 시 다운로드)
- 언어: 한국어 고정
- 오디오 버퍼: 최대 최근 12초를 반복 전사하고, 겹치는 문장 조각을 합쳐 긴 전사 내용을 화면에 유지
- 외부 서비스: 모델 최초 다운로드에만 HTTPS 사용. 음성 전사 중 서버 API 호출 없음

## 빌드/검증 범위

로컬 작업 환경에는 Android SDK/NDK/Gradle 실행 환경이 없으므로 이 산출물만으로 Kotlin/C++ 컴파일 또는 실기기 전사가 통과했다고 주장하지 않습니다. ZIP/XML/YAML/셸 구문 등 정적 검사는 별도로 수행하며, 실제 컴파일 성공은 GitHub Actions의 `assembleDebug` 결과로 판정해야 합니다.

## License notes

앱 소스는 MIT License로 제공됩니다. `whisper.cpp` 및 해당 ggml 변환 모델은 upstream의 MIT 라이선스와 공지 조건을 따릅니다. 업스트림 소스는 빌드 시 v1.9.5 태그에서 가져오며, 음성 모델은 앱 첫 실행 때 별도 다운로드합니다.
