package com.example.sorinote

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale

object ModelManager {
    const val MODEL_NAME = "ggml-large-v3-turbo-q5_0.bin"
    const val MODEL_SIZE_LABEL = "약 547 MiB"
    private const val MODEL_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin?download=true"
    private const val EXPECTED_SHA1 = "e050f7970618a659205450ad97eb95a18d69c9ee"
    private const val MINIMUM_FILE_BYTES = 500_000_000L

    fun modelFile(context: Context): File = File(File(context.filesDir, "models"), MODEL_NAME)
    private fun markerFile(context: Context): File = File(modelFile(context).absolutePath + ".verified")

    fun isReady(context: Context): Boolean {
        val model = modelFile(context)
        return model.isFile && model.length() >= MINIMUM_FILE_BYTES && markerFile(context).isFile
    }

    @Throws(Exception::class)
    fun download(
        context: Context,
        onProgress: (downloaded: Long, total: Long) -> Unit
    ) {
        val destination = modelFile(context)
        destination.parentFile?.mkdirs()
        val part = File(destination.absolutePath + ".part")
        part.delete()
        markerFile(context).delete()

        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("User-Agent", "SoriNote-Android/0.6.0")
        }

        try {
            connection.connect()
            val code = connection.responseCode
            if (code !in 200..299) throw IOException("모델 다운로드 HTTP 오류: $code")
            val total = connection.contentLengthLong
            val digest = MessageDigest.getInstance("SHA-1")
            var downloaded = 0L
            connection.inputStream.use { input ->
                FileOutputStream(part).use { output ->
                    val buffer = ByteArray(256 * 1024)
                    var count: Int
                    var lastCallback = 0L
                    while (input.read(buffer).also { count = it } != -1) {
                        output.write(buffer, 0, count)
                        digest.update(buffer, 0, count)
                        downloaded += count
                        val now = System.currentTimeMillis()
                        if (now - lastCallback >= 350L) {
                            onProgress(downloaded, total)
                            lastCallback = now
                        }
                    }
                    output.fd.sync()
                }
            }
            val actualSha1 = digest.digest().joinToString("") { "%02x".format(Locale.US, it) }
            if (actualSha1 != EXPECTED_SHA1) {
                part.delete()
                throw IOException("모델 무결성 검사 실패(SHA-1 불일치). 다시 다운로드해 주세요.")
            }
            if (destination.exists() && !destination.delete()) {
                throw IOException("기존 모델 파일을 교체할 수 없습니다.")
            }
            if (!part.renameTo(destination)) throw IOException("모델 파일 저장에 실패했습니다.")
            markerFile(context).writeText(EXPECTED_SHA1, Charsets.US_ASCII)
            onProgress(destination.length(), destination.length())
        } catch (error: Exception) {
            part.delete()
            throw error
        } finally {
            connection.disconnect()
        }
    }
}
