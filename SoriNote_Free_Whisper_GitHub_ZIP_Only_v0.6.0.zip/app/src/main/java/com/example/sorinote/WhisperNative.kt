package com.example.sorinote

/** Thin JNI interface to the on-device whisper.cpp engine. */
object WhisperNative {
    init {
        System.loadLibrary("sorinote-whisper")
    }

    external fun loadModel(modelPath: String): Boolean
    external fun transcribe(samples: FloatArray, threads: Int, language: String): String
    external fun releaseModel()
}
