package com.example.sorinote

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val accumulator = TranscriptAccumulator()

    private lateinit var statusView: TextView
    private lateinit var modelButton: Button
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var copyButton: Button
    private lateinit var clearButton: Button
    private lateinit var transcriptView: TextView
    private lateinit var scrollView: ScrollView

    @Volatile private var recording = false
    @Volatile private var finalizing = false
    @Volatile private var modelLoaded = false
    @Volatile private var loadingModel = false
    @Volatile private var destroyed = false
    private var recorder: AudioRecord? = null
    private var captureThread: Thread? = null
    private val audioLock = Any()
    private val sampleRate = 16_000
    private val ringCapacity = sampleRate * 12
    private val audioRing = FloatArray(ringCapacity)
    private var ringWriteIndex = 0
    private var totalSamplesWritten = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()
        if (ModelManager.isReady(this)) {
            modelButton.visibility = View.GONE
            loadModel()
        } else {
            updateStatus("최초 1회 모델 다운로드가 필요합니다. Wi-Fi 사용을 권장합니다.")
            updateButtons()
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val title = TextView(this).apply {
            text = "소리노트"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF161616.toInt())
        }
        statusView = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF505050.toInt())
            setPadding(0, dp(8), 0, dp(12))
        }
        modelButton = Button(this).apply {
            text = "한국어 전사 모델 다운로드 (${ModelManager.MODEL_SIZE_LABEL})"
            setOnClickListener { downloadModel() }
        }
        startButton = Button(this).apply {
            text = "실시간 전사 시작"
            setOnClickListener { requestMicAndStart() }
        }
        stopButton = Button(this).apply {
            text = "전사 종료"
            isEnabled = false
            setOnClickListener { stopRecording() }
        }
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(startButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
            addView(stopButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        }
        val transcriptHeader = TextView(this).apply {
            text = "전사 내용"
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFF222222.toInt())
            setPadding(0, dp(14), 0, dp(6))
        }
        transcriptView = TextView(this).apply {
            text = "마이크를 켜면 전사 결과가 여기에 표시됩니다."
            textSize = 18f
            setTextColor(0xFF171717.toInt())
            setTextIsSelectable(true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(0xFFF5F6F8.toInt())
            gravity = Gravity.TOP or Gravity.START
        }
        scrollView = ScrollView(this).apply {
            isFillViewport = true
            addView(transcriptView, ScrollView.LayoutParams(-1, -2))
        }
        val transcriptParams = LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) }
        val utilityRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(copyButton().also { copyButton = it }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(5) })
            addView(clearButton().also { clearButton = it }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(5) })
        }

        root.addView(title)
        root.addView(statusView)
        root.addView(modelButton, LinearLayout.LayoutParams(-1, dp(54)))
        root.addView(actionRow, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(4) })
        root.addView(transcriptHeader)
        root.addView(scrollView, transcriptParams)
        root.addView(utilityRow, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(6) })
        setContentView(root)
        updateButtons()
    }

    private fun copyButton(): Button = Button(this).apply {
        text = "전사 복사"
        setOnClickListener {
            val text = accumulator.text()
            if (text.isBlank()) {
                toast("복사할 전사 내용이 없습니다.")
                return@setOnClickListener
            }
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("소리노트 전사", text))
            toast("전사 내용을 복사했습니다.")
        }
    }

    private fun clearButton(): Button = Button(this).apply {
        text = "내용 지우기"
        setOnClickListener {
            if (recording) {
                toast("전사를 종료한 뒤 지워 주세요.")
                return@setOnClickListener
            }
            accumulator.clear()
            transcriptView.text = "마이크를 켜면 전사 결과가 여기에 표시됩니다."
        }
    }

    private fun downloadModel() {
        if (loadingModel || recording || finalizing) return
        loadingModel = true
        modelButton.isEnabled = false
        updateStatus("전사 모델 다운로드 중… (${ModelManager.MODEL_SIZE_LABEL})")
        updateButtons()
        worker.submit {
            try {
                ModelManager.download(applicationContext) { downloaded, total ->
                    val text = if (total > 0L) {
                        val percent = (downloaded * 100L / total).coerceIn(0L, 100L)
                        "모델 다운로드 중… $percent% (${formatMiB(downloaded)} / ${formatMiB(total)})"
                    } else {
                        "모델 다운로드 중… ${formatMiB(downloaded)}"
                    }
                    mainHandler.post { updateStatus(text) }
                }
                mainHandler.post {
                    if (destroyed) return@post
                    loadingModel = false
                    modelButton.visibility = View.GONE
                    updateStatus("모델 다운로드 완료. 기기 내 모델을 준비하고 있습니다…")
                    loadModel()
                }
            } catch (error: Exception) {
                mainHandler.post {
                    if (destroyed) return@post
                    loadingModel = false
                    modelButton.isEnabled = true
                    updateStatus("모델 다운로드 실패: ${error.message ?: "네트워크 또는 저장 공간을 확인해 주세요."}")
                    updateButtons()
                }
            }
        }
    }

    private fun loadModel() {
        if (loadingModel || modelLoaded) return
        loadingModel = true
        updateStatus("기기 내 음성 인식 모델을 불러오는 중…")
        updateButtons()
        worker.submit {
            val loaded = try {
                WhisperNative.loadModel(ModelManager.modelFile(applicationContext).absolutePath)
            } catch (_: Throwable) {
                false
            }
            mainHandler.post {
                if (destroyed) return@post
                loadingModel = false
                modelLoaded = loaded
                if (loaded) {
                    updateStatus("준비 완료 · 인터넷/API 요금 없이 기기에서 전사합니다.")
                    modelButton.visibility = View.GONE
                } else {
                    updateStatus("모델을 불러오지 못했습니다. 모델을 다시 다운로드해 주세요.")
                    modelButton.visibility = View.VISIBLE
                    modelButton.isEnabled = true
                }
                updateButtons()
            }
        }
    }

    private fun requestMicAndStart() {
        if (!modelLoaded) {
            toast("먼저 전사 모델을 준비해 주세요.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        startRecording()
    }

    @Suppress("MissingSuperCall")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (destroyed) return
        if (requestCode == REQUEST_MIC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startRecording()
            else toast("실시간 전사를 위해 마이크 권한이 필요합니다.")
        }
    }

    private fun startRecording() {
        if (recording || finalizing || !modelLoaded) return
        val minimumBuffer = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minimumBuffer <= 0) {
            updateStatus("이 기기에서 오디오 입력을 초기화할 수 없습니다.")
            return
        }
        val bufferSize = max(minimumBuffer * 2, sampleRate * 2)
        val newRecorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            )
        } catch (error: Exception) {
            updateStatus("마이크 초기화 실패: ${error.message ?: "오디오 장치를 확인해 주세요."}")
            return
        }
        if (newRecorder.state != AudioRecord.STATE_INITIALIZED) {
            newRecorder.release()
            updateStatus("마이크를 초기화할 수 없습니다.")
            return
        }

        synchronized(audioLock) {
            ringWriteIndex = 0
            totalSamplesWritten = 0L
        }
        accumulator.clear()
        transcriptView.text = "듣고 있습니다…"
        recorder = newRecorder
        try {
            newRecorder.startRecording()
        } catch (error: Exception) {
            recorder = null
            newRecorder.release()
            updateStatus("녹음을 시작하지 못했습니다: ${error.message ?: "마이크를 확인해 주세요."}")
            return
        }
        recording = true
        finalizing = false
        updateStatus("실시간 전사 중 · 한국어 · 기기 내 처리")
        updateButtons()

        captureThread = Thread({
            val pcm = ShortArray(2048)
            while (recording) {
                val count = try {
                    newRecorder.read(pcm, 0, pcm.size, AudioRecord.READ_BLOCKING)
                } catch (_: Exception) {
                    -1
                }
                if (count > 0 && recording) {
                    synchronized(audioLock) {
                        for (i in 0 until count) {
                            audioRing[ringWriteIndex] = pcm[i] / 32768.0f
                            ringWriteIndex = (ringWriteIndex + 1) % ringCapacity
                            totalSamplesWritten++
                        }
                    }
                } else if (count < 0) {
                    mainHandler.post {
                        if (recording) {
                            updateStatus("오디오 입력이 끊어졌습니다. 전사를 마무리합니다…")
                            stopRecording()
                        }
                    }
                    break
                }
            }
        }, "SoriNote-AudioCapture").apply { start() }

        worker.submit { inferenceLoop() }
    }

    private fun inferenceLoop() {
        val threads = max(2, min(6, Runtime.getRuntime().availableProcessors() - 2))
        while (recording) {
            val cycleStartedAt = System.currentTimeMillis()
            val samples = audioSnapshot()
            // Start with a short first window for earlier feedback; later windows grow to 12 seconds.
            if (samples.size < sampleRate * 2) {
                try { Thread.sleep(250L) } catch (_: InterruptedException) { break }
                continue
            }
            val text = try {
                WhisperNative.transcribe(samples, threads, "ko")
            } catch (error: Throwable) {
                mainHandler.post { updateStatus("전사 중 오류: ${error.message ?: "모델 상태를 확인해 주세요."}") }
                ""
            }
            if (text.isNotBlank()) {
                val display = accumulator.accept(text)
                mainHandler.post { renderTranscript(display) }
            }
            // Aim for 1.25 s between inference starts. If inference itself takes longer,
            // leave only a short cooldown rather than queueing overlapping native calls.
            val elapsed = System.currentTimeMillis() - cycleStartedAt
            val pause = max(150L, 1_250L - elapsed)
            try { Thread.sleep(pause) } catch (_: InterruptedException) { break }
        }

        // Final pass over the most recent audio so that the last spoken phrase is not omitted.
        val finalSamples = audioSnapshot()
        if (finalSamples.size >= sampleRate * 2) {
            try {
                val finalText = WhisperNative.transcribe(finalSamples, threads, "ko")
                if (finalText.isNotBlank()) {
                    val display = accumulator.accept(finalText)
                    mainHandler.post { renderTranscript(display) }
                }
            } catch (_: Throwable) {
                // Preserve the transcript already visible if the final pass fails.
            }
        }
        val completed = accumulator.finish()
        mainHandler.post {
            if (destroyed) return@post
            finalizing = false
            renderTranscript(completed)
            updateStatus("전사 종료 · 기기 내 처리 완료")
            updateButtons()
        }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        finalizing = true
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        try {
            recorder?.release()
        } catch (_: Exception) {
        }
        recorder = null
        captureThread?.interrupt()
        captureThread = null
        updateStatus("전사를 마무리하고 있습니다…")
        updateButtons()
    }

    private fun audioSnapshot(): FloatArray = synchronized(audioLock) {
        val length = min(totalSamplesWritten, ringCapacity.toLong()).toInt()
        val snapshot = FloatArray(length)
        val start = (ringWriteIndex - length + ringCapacity) % ringCapacity
        for (i in 0 until length) snapshot[i] = audioRing[(start + i) % ringCapacity]
        snapshot
    }

    private fun renderTranscript(text: String) {
        if (destroyed || !::transcriptView.isInitialized) return
        transcriptView.text = if (text.isBlank()) "음성을 듣고 있습니다…" else text
        copyButton.isEnabled = text.isNotBlank()
        scrollView.post { if (!destroyed) scrollView.fullScroll(View.FOCUS_DOWN) }
    }

    private fun updateStatus(text: String) {
        if (destroyed || !::statusView.isInitialized) return
        statusView.text = text
    }

    private fun updateButtons() {
        if (destroyed || !::statusView.isInitialized) return
        val modelExists = ModelManager.isReady(this)
        if (!modelExists && !loadingModel) modelButton.visibility = View.VISIBLE
        if (loadingModel && !modelExists) modelButton.visibility = View.VISIBLE
        modelButton.isEnabled = !loadingModel && !recording && !finalizing && !modelLoaded
        startButton.isEnabled = modelLoaded && !loadingModel && !recording && !finalizing
        stopButton.isEnabled = recording
        copyButton.isEnabled = !accumulator.text().isBlank()
        clearButton.isEnabled = !recording && !finalizing
    }

    private fun formatMiB(value: Long): String = String.format(java.util.Locale.US, "%.0f MiB", value / (1024.0 * 1024.0))
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun toast(text: String) {
        if (!destroyed && !isFinishing) Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (recording) {
            stopRecording()
            toast("전사를 마무리 중입니다.")
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        if (recording) stopRecording()
        destroyed = true
        worker.submit {
            try { WhisperNative.releaseModel() } catch (_: Throwable) {}
        }
        worker.shutdown()
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_MIC = 3107
    }
}
