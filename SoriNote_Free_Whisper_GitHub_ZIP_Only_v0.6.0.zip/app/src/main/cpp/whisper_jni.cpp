#include <jni.h>
#include <android/log.h>
#include <whisper.h>

#include <algorithm>
#include <mutex>
#include <string>
#include <vector>

#define LOG_TAG "SoriNoteWhisper"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

namespace {
std::mutex g_mutex;
whisper_context *g_context = nullptr;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_sorinote_WhisperNative_loadModel(JNIEnv *env, jobject /*thiz*/, jstring model_path) {
    if (model_path == nullptr) return JNI_FALSE;
    const char *path_chars = env->GetStringUTFChars(model_path, nullptr);
    if (path_chars == nullptr) return JNI_FALSE;
    const std::string path(path_chars);
    env->ReleaseStringUTFChars(model_path, path_chars);

    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_context != nullptr) {
        whisper_free(g_context);
        g_context = nullptr;
    }
    whisper_context_params context_params = whisper_context_default_params();
    g_context = whisper_init_from_file_with_params(path.c_str(), context_params);
    if (g_context == nullptr) {
        LOGE("Could not load model from %s", path.c_str());
        return JNI_FALSE;
    }
    LOGI("Model loaded");
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_sorinote_WhisperNative_transcribe(
        JNIEnv *env, jobject /*thiz*/, jfloatArray samples_array, jint requested_threads, jstring language_string) {
    if (samples_array == nullptr) return env->NewStringUTF("");
    const jsize sample_count = env->GetArrayLength(samples_array);
    if (sample_count < 16000) return env->NewStringUTF("");

    std::vector<float> samples(static_cast<size_t>(sample_count));
    env->GetFloatArrayRegion(samples_array, 0, sample_count, samples.data());
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return env->NewStringUTF("");
    }

    std::string language = "ko";
    if (language_string != nullptr) {
        const char *language_chars = env->GetStringUTFChars(language_string, nullptr);
        if (language_chars != nullptr) {
            language.assign(language_chars);
            env->ReleaseStringUTFChars(language_string, language_chars);
        }
    }

    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_context == nullptr) return env->NewStringUTF("");

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.n_threads = std::max(2, std::min(6, static_cast<int>(requested_threads)));
    params.language = language.c_str();
    params.translate = false;
    params.no_context = true;
    params.no_timestamps = true;
    params.single_segment = false;
    params.print_special = false;
    params.print_progress = false;
    params.print_realtime = false;
    params.print_timestamps = false;
    params.token_timestamps = false;
    params.temperature = 0.0f;
    params.temperature_inc = 0.0f;

    const int result = whisper_full(g_context, params, samples.data(), static_cast<int>(samples.size()));
    if (result != 0) {
        LOGE("whisper_full failed: %d", result);
        return env->NewStringUTF("");
    }

    std::string transcript;
    const int segment_count = whisper_full_n_segments(g_context);
    for (int index = 0; index < segment_count; ++index) {
        const char *segment = whisper_full_get_segment_text(g_context, index);
        if (segment != nullptr) transcript += segment;
    }
    const auto first = transcript.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) transcript.clear();
    else {
        const auto last = transcript.find_last_not_of(" \t\r\n");
        transcript = transcript.substr(first, last - first + 1);
    }
    return env->NewStringUTF(transcript.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_sorinote_WhisperNative_releaseModel(JNIEnv * /*env*/, jobject /*thiz*/) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_context != nullptr) {
        whisper_free(g_context);
        g_context = nullptr;
    }
    LOGI("Model released");
}
