package com.example.sorinote

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.AudioPlaybackCaptureConfiguration
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

/** Captures only system-authorized, capturable playback audio after explicit user consent. */
class PlaybackCaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "sorinote_internal_audio"
        private const val NOTIFICATION_ID = 4207
        private const val SAMPLE_RATE = 16_000
    }

    @Volatile private var capturing = false
    private var projection: MediaProjection? = null
    private var audioRecord: AudioRecord? = null
    private var captureThread: Thread? = null
    private val stopped = AtomicBoolean(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            fail("Android 10 이상이 필요합니다.")
            stopSelf(startId)
            return START_NOT_STICKY
        }
        if (intent == null) {
            fail("캡처 동의를 찾을 수 없습니다.")
            stopSelf(startId)
            return START_NOT_STICKY
        }
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        @Suppress("DEPRECATION")
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        }
        if (resultCode != Activity.RESULT_OK || resultData == null) {
            fail("Android 내부 오디오 캡처 동의가 없습니다.")
            stopSelf(startId)
            return START_NOT_STICKY
        }

        try {
            createNotificationChannel()
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            startCapture(resultCode, resultData)
        } catch (error: Throwable) {
            fail(error.message ?: error.javaClass.simpleName)
            stopCaptureResources(stopProjection = true)
            stopSelf(startId)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, resultData: Intent) {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val activeProjection = manager.getMediaProjection(resultCode, resultData)
            ?: throw IllegalStateException("Android가 내부 오디오 캡처 세션을 만들지 못했습니다.")
        projection = activeProjection
        activeProjection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCaptureResources(stopProjection = false)
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))

        val config = AudioPlaybackCaptureConfiguration.Builder(activeProjection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minimum = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        if (minimum <= 0) throw IllegalStateException("내부 오디오 입력 버퍼를 초기화하지 못했습니다.")
        val newRecorder = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(max(minimum * 2, SAMPLE_RATE * 2))
            .setAudioPlaybackCaptureConfig(config)
            .build()
        if (newRecorder.state != AudioRecord.STATE_INITIALIZED) {
            newRecorder.release()
            throw IllegalStateException("이 기기에서 내부 오디오 캡처를 초기화하지 못했습니다.")
        }
        audioRecord = newRecorder
        newRecorder.startRecording()
        stopped.set(false)
        capturing = true
        AudioPlaybackInputBus.reportStatus("내부 앱 재생음 캡처 중 · 실시간 전사 · 기기 내 처리")

        captureThread = Thread({
            val pcm = ShortArray(2048)
            while (capturing) {
                val count = try {
                    newRecorder.read(pcm, 0, pcm.size, AudioRecord.READ_BLOCKING)
                } catch (_: Throwable) {
                    -1
                }
                if (count > 0 && capturing) {
                    AudioPlaybackInputBus.publish(pcm, count)
                } else if (count < 0 && capturing) {
                    fail("내부 오디오 읽기가 중단되었습니다(코드 $count).")
                    stopSelf()
                    break
                }
            }
        }, "SoriNote-PlaybackCapture").apply { start() }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "소리노트 내부 오디오 전사", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "앱 재생음을 사용자가 요청한 동안 전사합니다."
                }
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("소리노트 내부 오디오 전사")
                .setContentText("허용된 앱 재생음을 기기 내에서 전사 중입니다.")
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("소리노트 내부 오디오 전사")
                .setContentText("앱 재생음을 기기 내에서 전사 중입니다.")
                .setOngoing(true)
                .build()
        }
    }

    private fun fail(message: String) {
        AudioPlaybackInputBus.reportStatus("ERROR: $message")
    }

    private fun stopCaptureResources(stopProjection: Boolean) {
        if (!stopped.compareAndSet(false, true)) return
        capturing = false
        val thread = captureThread
        captureThread = null
        thread?.interrupt()
        val localRecorder = audioRecord
        audioRecord = null
        try { localRecorder?.stop() } catch (_: Throwable) {}
        try { localRecorder?.release() } catch (_: Throwable) {}
        val localProjection = projection
        projection = null
        if (stopProjection) {
            try { localProjection?.stop() } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        stopCaptureResources(stopProjection = true)
        super.onDestroy()
    }
}
