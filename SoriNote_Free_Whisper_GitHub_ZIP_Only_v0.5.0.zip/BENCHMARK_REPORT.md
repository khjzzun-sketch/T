# Soniox 3.9.0 APK/XAPK 정적 벤치마킹 보고서

작성일: 2026-10-29  
대상: `Soniox+-+Speech+to+Text+AI_3.9.0_APKPure.xapk`  
분석 방식: 설치·실행·네트워크 접속 없이 XAPK 컨테이너, split APK 목록, manifest 메타데이터, DEX/React Native 번들 문자열을 정적으로 확인했다.

## 1. XAPK 구성 확인

XAPK manifest에서 확인한 정보:

- 앱 이름: Soniox
- package: `com.soniox.sonioxmobileapp`
- version name/code: `3.9.0` / `249`
- min SDK / target SDK: `30` / `36`
- split: base APK, `config.en`, `config.xxhdpi`, `config.arm64_v8a`
- base APK에는 약 11.7 MB의 `assets/index.android.bundle` 및 여러 DEX 파일이 포함되어 있다.
- arm64 split에는 React Native/Hermes와 오디오 처리 관련 native libraries가 포함되어 있다.

이 앱은 APKPure 스토어 앱이 아니다. 이전에 업로드된 `APKPure_1.01.5806_apkpure.com.apk`와 다른 파일이다.

## 2. 기능 흐름 확인

바이너리 번들에 나타난 UI 문구/경로 및 Soniox 공개 도움말을 교차 참고한 기능 목록이다. 정적 문자열만으로 모든 동작이 실제 실행 중 어떻게 작동하는지 입증되는 것은 아니다.

- 실시간 음성 전사 및 실시간 번역
- 연결이 안 되는 동안 오프라인으로 녹음하고 이후 처리할 수 있는 흐름
- 저장 기록/히스토리, 녹음 재생 및 녹취록 검토
- 이름/주제 등의 문맥 힌트와 언어 힌트
- 화자 분리와 화자 이름 편집
- 저장된 오디오가 기기에 남아 있을 때 설정을 변경해 재전사
- 기록 이름 변경, 태그, 공유/내보내기
- 요약·분석·질문 등 AI 작업

번들에는 `transcriptions`, `stt`, `tags`, `llm` 관련 API 경로 문자열과 Soniox의 모바일 백엔드 도메인 문자열도 포함되어 있다. 따라서 이 앱을 기능적으로 동일하게 재현하는 것은 단순한 로컬 UI 복제보다 훨씬 큰 서버·계정·정책 작업을 포함한다. 이 분석은 실제 요청을 보내거나 서버 동작을 시험하지 않았다.

## 3. 소리노트에 반영한 기능 및 구분

| 벤치마킹 항목 | 이번 수정 | 범위/한계 |
|---|---|---|
| 저장 녹취록·히스토리 | 로컬 텍스트 기록과 제목/본문 편집 | 앱 내부 저장소에만 저장 |
| 태그 및 검색 | 기록마다 최대 12개 태그 추가/편집; 제목·본문·태그를 함께 검색 | 자유 태그이며 계정 간 동기화 없음 |
| 오디오 재생 | 고정밀 녹취와 가져온 오디오를 앱 내부 WAV로 보관하고 기록 화면에서 재생 | 기존 기록(오디오 경로가 없는 기록)은 텍스트만 재생성 가능 |
| 재전사 | 보관된 오디오를 현재 언어/문맥 힌트로 다시 Whisper 처리하고 기존 텍스트 교체 | 새 처리도 기기에서 실행; 이전 결과의 AI 작업/화자 정보는 없음 |
| 문맥/고유명사 힌트 | 최대 500자 Whisper initial prompt 유지 | 언어 힌트와 같지 않으며 결과를 보장하지 않음 |
| 언어 식별 | Whisper 자동 감지 및 22개 인식/번역 언어 목록 | Soniox의 다국어 서버 스트리밍과 동일하지 않음 |
| 실시간 전사 | Android 온디바이스 SpeechRecognizer | 기기별 언어 모델·서비스 지원 차이, Soniox 동급을 보장하지 않음 |
| 요약/할 일 | 로컬 문장·키워드 기반 추출 | 생성형 AI 요약/질의응답이 아님 |
| 번역 | ML Kit 모델을 다운로드한 뒤 기기에서 텍스트 번역 | 전사 후 번역; 실시간 대화 통역이 아님 |
| 화자 분리/이름 변경 | 자동 구현하지 않음 | 소스 엔진이 화자 식별을 반환하지 않아 가짜 화자 라벨을 만들지 않음 |
| 공유/내보내기 | Android 공유 메뉴로 텍스트 공유 | Soniox 클라우드 동기화나 공개 링크 기능 없음 |

## 4. 인식 모델 선택

소리노트의 고정밀 모드는 `whisper.cpp`와 `large-v3-turbo-q5_0` 다국어 모델을 사용한다. 공식 모델 목록은 모델 크기를 약 547 MiB, SHA-1을 `e050f7970618a659205450ad97eb95a18d69c9ee`로 표시한다. 모델 다운로드 후 SHA-1 검증을 수행한다.

이는 무료·로컬 실행을 우선한 설계이지 Soniox와의 품질 동등성 증명이 아니다. Whisper는 자동 화자 분리, 서버 측 후처리, 실시간 번역을 이 구성만으로 제공하지 않는다. 한국어/영어 혼합, 고유명사, 소음, 마이크 거리 등으로 나눠 실제 녹음 샘플을 비교해야 한다.

## 5. 이번 소스 확인 지문

- XAPK SHA-256: `8d1ae350875440b41c96e0a3309f8583bbb3ebb00407fa8ca67dea2b36183f35`
- 확인한 package/version은 XAPK manifest의 `com.soniox.sonioxmobileapp` / `3.9.0` / code `249`와 일치한다.

## 6. 검증 상태

- XAPK 컨테이너 무결성/분할 APK 목록: 확인
- package/version/min SDK/target SDK: manifest.json에서 확인
- React Native/Hermes 구성: 번들 및 native-library 목록에서 확인
- 소리노트 ZIP 구조, SDK workflow, 메타데이터, Kotlin/C++ 인터페이스: 정적 재검수 대상
- 실제 Android SDK/NDK 빌드, APK 실행, 휴대전화 오디오 품질 테스트: 이 실행 환경에서는 미수행
