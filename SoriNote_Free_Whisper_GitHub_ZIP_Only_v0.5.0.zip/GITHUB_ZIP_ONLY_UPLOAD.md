# GitHub 단일 ZIP 업로드 안내 — SoriNote v0.5.0

## 이번 ZIP

- 파일명: `SoriNote_Free_Whisper_GitHub_ZIP_Only_v0.5.0.zip`
- ZIP 최상위: `settings.gradle.kts`, `build.gradle.kts`, `app/`, `.github/` 및 문서가 바로 들어 있다. 별도 중첩 폴더는 없다.
- Actions 빌드는 프로젝트 파일을 직접 업로드하지 못하는 상황을 위해 저장소 루트의 버전 지정 ZIP을 찾아 풀어 빌드한다.

## ZIP만 업로드할 때

1. 저장소 `https://github.com/khjzzun-sketch/T`의 `main` 브랜치 루트에 새 v0.5.0 ZIP 파일 하나를 업로드한다.
2. 현재 저장소 workflow는 `SoriNote_Free_Whisper_GitHub_ZIP_Only_v*.zip` 중 버전이 가장 높은 파일을 선택한다. 이전 ZIP을 별도로 지우지 않아도 v0.5.0을 선택하게 설계되어 있다.
3. **ZIP은 GitHub에서 자동으로 풀리지 않는다.** 저장소에 이미 존재하는 `.github/workflows/build.yml`이 먼저 실행되고, 그 안의 스크립트가 ZIP을 풀어 빌드한다. 현재 원격 workflow는 v3 + `packages: platform-tools`를 사용하므로 `tools` 패키지를 요청하지 않는다. ZIP 내부의 v4 workflow는 저장소 파일을 영구 교체하지 않는다.
4. 빌드가 성공하면 Actions 실행의 `sorinote-free-whisper-debug-apk` artifact를 받는다.

## Android SDK 패키지 설치 오류 관련

- XAPK 검수 후 ZIP 내부 workflow는 `android-actions/setup-android@v4`를 사용하고, deprecated SDK package `tools`를 요청하지 않도록 바꿨다.
- 저장소에서 현재 읽은 workflow는 `setup-android@v3`에 `packages: platform-tools`를 명시한다. 이 설정은 `tools`를 요청하지 않는다. 제공된 오류는 이전 실행에 적용된 workflow/커밋이 지금 조회한 파일과 다를 가능성이 있다. ZIP 업로드 후 **새로 시작한** Actions 실행의 첫 SDK 설정 단계를 확인한다.
- ZIP 안의 `.github/workflows/build.yml`은 저장소의 원격 workflow를 자동으로 갱신하지 않는다. 원격 workflow를 바꾸려면 저장소의 해당 파일을 직접 수정해야 한다.
- 이 프로젝트 ZIP에는 Android 빌드 결과물 APK가 포함되어 있지 않다. GitHub Actions가 실제 빌드해야 한다.
