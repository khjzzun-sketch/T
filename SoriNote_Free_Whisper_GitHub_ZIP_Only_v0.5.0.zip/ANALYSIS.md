# 기술 분석 및 수정 이력 — SoriNote v0.5.0

## 대상 소스

- 원본 참조: `Soniox+-+Speech+to+Text+AI_3.9.0_APKPure.xapk`
- 확인 package/version: `com.soniox.sonioxmobileapp`, Soniox 3.9.0 (versionCode 249), min SDK 30, target SDK 36
- 분석 방식: 설치하거나 네트워크 요청을 재현하지 않는 정적 분석

## Soniox 기능 중 확인한 참고 항목

XAPK의 React Native 번들과 공개 Soniox 도움말에서 다음 흐름을 확인했다: 실시간 전사/번역, 오프라인 녹음 후 추후 처리, 저장 기록과 오디오 재생, 문맥 및 언어 힌트, 화자 분리/이름 관리, 저장 오디오 재전사, 태그/공유, 요약·분석·질문 작업.

Soniox의 모바일 앱은 서버/계정 기능에 의존하는 부분이 있다. 소리노트는 비용 없이 기기에서 실행할 수 있는 오픈소스 기반 앱을 목표로 하므로 Soniox 서버 API, 계정 체계, 유료 크레딧, 클라우드 기록 동기화는 복제하지 않는다.

## v0.5.0 변경 사항

1. **저장 녹취록에 오디오 경로 추가:** `SavedNote.audioPath`를 선택 필드로 추가했다. 기존 JSON 기록에 필드가 없어도 로드할 수 있게 기본값을 null로 처리한다.
2. **오디오 보존:** 고정밀 녹음은 앱 내부 `files/recordings`에 남긴다. 가져온 파일은 16 kHz mono PCM16 WAV로 변환한 다음 기기 내부 기록 폴더로 복사한다.
3. **재생:** 저장 기록에서 `MediaPlayer`로 보관된 WAV를 재생/중지하고, 화면 종료·재생 종료·오류 시 플레이어를 해제한다.
4. **재전사:** 저장 오디오를 현재 선택 언어 및 문맥 힌트로 Whisper 재처리하고 기존 녹취록 텍스트를 교체한다. 실패한 재전사는 기존 오디오를 삭제하지 않는다.
5. **기록 수정:** 저장한 기록의 제목과 본문을 로컬에서 편집할 수 있다.
6. **오디오 정리:** 기록을 삭제하면 다른 기록에서 참조하지 않는 해당 오디오도 삭제한다. 미저장 녹취가 새 기록으로 대체되거나 명시적으로 지워질 때 미저장 오디오를 정리한다.
7. **태그/검색:** Soniox의 기록 정리 흐름을 참고해 로컬 자유 태그를 기록마다 최대 12개 저장·편집한다. 태그가 없는 기존 JSON 기록도 그대로 읽으며 태그로도 검색한다.
8. **SDK/CI:** ZIP 내부 workflow는 `android-actions/setup-android@v4`를 사용하고 `tools` 패키지를 요청하지 않는다. Android platform 35, build-tools 35.0.0, CMake 3.22.1, NDK 27.0.12077973을 별도 설치하도록 했다.
9. **버전/호환성:** Android min SDK 30, versionCode 5, versionName `0.5.0-free-whisper-soniox-benchmark`.

## 빌드 재검수

- CMake는 `whisper.cpp` v1.9.5 태그를 고정해서 빌드 소스를 가져온다.
- JNI에서 사용하는 주요 API(`suppress_nst`, `whisper_full_lang_id`, `use_gpu`, `carry_initial_prompt`)가 v1.9.5의 공개 헤더에 존재함을 확인했다.
- workflow는 ZIP 무결성을 먼저 검사하고, 버전 문자열 기준 가장 높은 `SoriNote_Free_Whisper_GitHub_ZIP_Only_v*.zip`을 선택한다.
- **중요:** ZIP 안의 `.github/workflows/build.yml`은 저장소의 이미 등록된 workflow를 자동으로 커밋/교체하지 않는다. 현재 원격 workflow를 다시 읽어 확인한 결과 `setup-android@v3`와 `packages: platform-tools`가 설정돼 있어 `tools`를 요청하지 않는다. 공유된 `Failed to find package tools` 로그는 이 설정이 적용되기 전 실행에서 나온 것일 가능성이 있다. 새 ZIP 업로드로 새 실행을 시작해 실제 로그를 확인해야 한다. ZIP에 넣은 v4 설정 자체가 곧바로 저장소에 반영되는 것은 아니다.
- 실제 Android SDK/NDK 환경에서 Gradle assembleDebug, APK 설치, 기기 오디오 테스트는 이 실행 환경에서 수행하지 못했다. 따라서 정적 검사 완료를 빌드 성공으로 표현하지 않는다.

## 한계 및 비회귀 규칙

- 자동 화자 분리/화자 식별자를 임의로 생성하지 않는다. 적용 모델이 해당 기능을 지원하지 않기 때문이다.
- 로컬 문장 추출 요약을 생성형 AI 요약이라고 표시하지 않는다.
- ML Kit 번역은 언어 모델 최초 다운로드 이후 텍스트를 기기 내에서 번역한다. Soniox의 실시간 번역과 동일하지 않다.
- Whisper `large-v3-turbo-q5_0` 모델은 첫 다운로드에 약 547 MiB의 네트워크/저장 공간이 필요하다. 이후 전사는 로컬에서 처리한다.
- 이전 버전에서 저장한 기록은 audioPath가 없으므로 재생/재전사 버튼이 표시되지 않는다.
