# 소리노트 무료 (SoriNote Free) — Android 프로젝트 v0.5.0

> GitHub에 ZIP 하나만 업로드할 수 있는 환경을 위한 프로젝트다. ZIP 최상위에 `settings.gradle.kts`, `build.gradle.kts`, `app/`, `.github/`가 바로 들어 있다. ZIP은 GitHub에 올렸다고 자동으로 압축 해제되지 않으므로 저장소에 ZIP을 풀어 빌드하는 workflow가 먼저 등록되어 있어야 한다.

## Soniox 3.9.0 XAPK 정적 벤치마킹

이번에 제공된 `Soniox+-+Speech+to+Text+AI_3.9.0_APKPure.xapk`는 Soniox 앱으로 확인됐다. manifest의 패키지는 `com.soniox.sonioxmobileapp`, versionName `3.9.0`, versionCode `249`, min SDK `30`, target SDK `36`이다. base APK의 React Native 번들과 arm64 native libraries를 정적으로 점검했다. 앱을 설치·실행하거나 API 서버에 연결하지는 않았다.

Soniox의 공개 도움말 및 XAPK 번들에서 참고한 흐름은 실시간 전사/번역, 기록 및 오디오 재생, 언어·문맥 힌트, 화자 분리/이름 관리, 저장 오디오 재전사, 태그/공유, 요약·AI 작업이다. 소리노트는 이 중 무료 로컬 처리로 구현 가능한 기능을 우선하며, Soniox 서버·계정·크레딧 체계를 복제하지 않는다.

## 인식 방식

### 1. 실시간 간편 받아쓰기
- Android 온디바이스 `SpeechRecognizer`를 사용한다.
- 기기 내 인식 서비스가 없거나 해당 언어 모델이 미설치된 경우 오류를 표시한다. 온라인 STT로 조용히 전환하지 않는다.
- OS·기기·설치된 오프라인 언어 모델에 따라 결과와 지원 언어가 달라진다.

### 2. 고정밀 오프라인 전사
- `whisper.cpp` 및 multilingual `large-v3-turbo-q5_0` 양자화 모델을 기기에서 실행한다.
- 품질 우선 beam search(beam size 5)를 사용한다. 속도/메모리 사용량이 늘 수 있고 모든 녹음에서 인식률이 향상된다는 보장은 없다.
- 첫 모델 다운로드는 약 547 MiB다. 모델 SHA-1 검증 후 사용한다.
- 문맥 힌트(최대 500자)와 언어 자동 감지를 지원한다. 힌트는 결과를 보장하지 않는다.
- 고정밀 모드는 녹음/파일 처리 후 전사한다. Soniox 동급 실시간 정제, 자동 화자 분리, 실시간 통역을 제공하지 않는다.

## v0.5.0 변경 사항

- **Soniox 기록 흐름 참고:** 고정밀 녹음 및 가져온 오디오를 전사한 뒤 앱 내부의 WAV로 보관할 수 있도록 수정했다.
- **저장 기록 재생:** 기록 화면에서 저장된 오디오를 재생/중지한다.
- **고정밀 재전사:** 저장 기록의 오디오에 현재 문맥 힌트와 언어 설정을 적용해 다시 전사하고 본문을 갱신한다.
- **기록 편집·태그:** 제목/녹취록을 수정하고 기록마다 최대 12개 태그를 저장·검색할 수 있다. 기존 기록 JSON에 태그가 없어도 호환된다.
- **파일 가져오기:** 기기가 디코딩할 수 있는 오디오를 모노 PCM 16 kHz WAV로 변환해 전사한다. 외부 파일 지원은 Android MediaCodec/기기 코덱에 의존한다.
- **기록 삭제:** 텍스트 기록을 지울 때 다른 기록이 참조하지 않는 연결 오디오도 함께 삭제한다.
- **SDK workflow 수정:** ZIP 안의 workflow는 `android-actions/setup-android@v4`를 사용하며 `tools` 패키지를 요청하지 않고 Android SDK 플랫폼·빌드 도구·CMake·NDK를 별도로 설치한다.

## Soniox와 다른 점

| 기능 | 소리노트 상태 |
|---|---|
| 실시간 전사 | Android 온디바이스 SpeechRecognizer. 서비스/언어 지원에 따라 다름 |
| 고정밀 전사 | Whisper 오프라인 모델로 녹음/파일 처리 후 전사 |
| 저장 기록·오디오 재생 | 고정밀 오디오가 보관된 기록은 가능. 기존 텍스트 전용 기록에는 오디오가 없음 |
| 태그·검색 | 기록별 최대 12개 태그를 편집하고 제목/본문/태그로 검색 |
| 재전사 | 보관 오디오와 현재 문맥 힌트로 가능 |
| 언어/문맥 힌트 | 단일 선택/자동 감지 + 문맥 텍스트 힌트 |
| 화자 분리 | 자동 화자 분리 미구현 |
| 번역 | ML Kit 모델을 처음 다운로드한 후 전사 결과를 기기 내에서 번역. 실시간 통역 아님 |
| 요약/할 일 | 키워드·문장 기반 로컬 추출. 생성형 AI가 아님 |
| 클라우드 동기화·공개 링크·계정·유료 크레딧 | 미구현 |

## GitHub Actions 빌드

필요 패키지: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, CMake 3.22.1, NDK 27.0.12077973. Gradle/Android 의존성 및 `whisper.cpp` 소스를 다운로드하기 위해 첫 빌드에는 네트워크가 필요하다.

- 출력 artifact: `sorinote-free-whisper-debug-apk`
- ZIP 내부 workflow는 Android SDK의 deprecated `tools` 패키지를 요청하지 않는다.
- **저장소에 이미 존재하는 workflow는 ZIP 파일 업로드만으로 영구 교체되지 않는다.** 현재 저장소의 workflow가 실제로 실행에 사용되며, ZIP 내부 v4 workflow는 현재 run YAML을 바꾸지 않는다. 자세한 내용은 `GITHUB_ZIP_ONLY_UPLOAD.md`를 확인한다.
- 이 환경에서는 Android SDK/NDK를 사용한 `assembleDebug`나 실기기 설치 테스트를 실행하지 못했다. 실제 빌드 성공은 GitHub Actions 결과에서 확인해야 한다.

## 개인정보/저장 정책

- STT는 Android 온디바이스 엔진 또는 로컬 Whisper에서 수행하며 앱의 STT 코드가 음성/전사문을 STT 서버에 업로드하지 않는다.
- 큰 Whisper 모델은 기능 사용 시 다운로드한다. ML Kit 번역 모델도 처음 필요한 언어 조합에 대해 다운로드한다.
- 문맥 힌트와 텍스트 기록은 앱 내부 저장소/설정에 저장된다. 고정밀 오디오 파일도 앱 내부 저장소에 남아 기록 재생/재전사에 사용된다. 연결된 기록을 삭제하면 해당 파일도 삭제한다. 앱 데이터를 지우거나 앱을 제거하면 내부 데이터가 함께 삭제된다.

## 라이선스/참고

- `THIRD_PARTY_NOTICES.md`를 참조한다.
- Soniox help: https://app.soniox.com/help-center/mobile-app/usage/getting-started
- Soniox accuracy settings: https://app.soniox.com/help-center/mobile-app/usage/improving-accuracy
- Soniox record management: https://app.soniox.com/help-center/mobile-app/usage/managing
- whisper.cpp: https://github.com/ggml-org/whisper.cpp
- model size/checksum list: https://github.com/ggml-org/whisper.cpp/blob/master/models/README.md
- Android SpeechRecognizer: https://developer.android.com/reference/android/speech/SpeechRecognizer
- ML Kit translation: https://developers.google.com/ml-kit/language/translation/android
